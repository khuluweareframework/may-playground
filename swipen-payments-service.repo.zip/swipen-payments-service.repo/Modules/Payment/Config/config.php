<?php

/*
|-------------------------------------------
| API Version
|-------------------------------------------
|
| This value is the version of your api.
| It's used when there's no specified
| version on the routes, so it will take this
| as the default, or current.
*/

return [
    'name' => 'Payment',

    /*
    |--------------------------------------------------------------------------
    | Sagepay Configuration
    |--------------------------------------------------------------------------
    | Vendor Name:      The vendor name for the account
    | Key:              The vendor key for the account
    | Base Url:         The url for sagepay transactions
    | Secure Endpoint:  The 3d secure endpoint for sagepay transactions
    |
    */
    'vendor_name' => env('SAGEPAY_VENDOR', 'rematchtest'),
    'key' => env('SAGEPAY_KEY'),
    'base_url' => env('SAGEPAY_BASEURL', 'https://pi-test.sagepay.com/api/v1/'),
    'secure_endpoint' => env('SAGEPAY_SECURE_ENDPOINT', 'transactions/%s/3d-secure'),
    'secure_endpoint_v2' => env('SAGEPAY_SECURE_ENDPOINT_V2', 'transactions/%s/3d-secure-challenge'),
    'payment_channels' => ['sagepay', 'dna'],
    'payment_channel' => env('PAYMENT_CHANNEL', 'sagepay'),
    'dna' => [
        'auth' => [
            'client_id' => env('DNA_CLIENT_ID'),
            'client_secret' => env('DNA_CLIENT_SECRET'),
            'terminal' => env('DNA_TERMINAL_ID'),
            'grant_type' => 'client_credentials',
            'scope' => 'webapi',
            'currency' => 'GBP',
        ],
        'auth_url' => env('DNA_AUTHURL', 'https://test-oauth.dnapayments.com/'),
        'base_url' => env('DNA_BASEURL', 'https://test-api.dnapayments.com/'),
        'avsCvv' => [
            /*
            0:  Reject None (all results will be accepted)
            2:  Reject “Not Provided” Results
            4:  Reject “Not Checked” Results
            8:  Reject “Matched” Results
            16: Reject “Not Matched” Results
            32: Reject “Partial Match” Results
            For Force, 2+4+16 = 22
            For Disable, 0+0+0 = 0
            For Partial, 2+4+32 = 38
            */
            'Force' => [
                'avsPostCodeMatrix' => 22,
                'avsHouseMatrix' => 22,
                'cscMatrix' => 22,
            ],
            'Disable' => [
                'avsPostCodeMatrix' => 0,
                'avsHouseMatrix' => 0,
                'cscMatrix' => 0,
            ],
        ],
        'rsa_public_key' => env('DNA_RSA_PUBLIC_KEY'),
        '3dsecure' => [
            'accept_tx_status' => ['succeeded'],
        ],
    ],
    'sagepay' => [
        '3dsecure' => [
            'max_attempt' => 3,
            'accept_tx_status' => ['Ok', 'Authenticated', 'AttemptOnly'],
            'reattempt_tx_status' => ['NotAuthenticated', 'Rejected'],
            'retry_wait_time' => 2,
            'force' => 'Force',
            'disable' => 'Disable',
            // used in case of 3dsv2
            'credential_type' => [
                'deffered' => [
                    'cofUsage' => 'First',
                    'initiatedType' => 'CIT',
                    'mitType' => 'Unscheduled',
                ],
                'repeat' => [
                    'cofUsage' => 'Subsequent',
                    'initiatedType' => 'MIT',
                    'mitType' => 'Unscheduled',
                ],
                'payment' => [
                    'cofUsage' => 'Subsequent',
                    'initiatedType' => 'CIT',
                    'mitType' => 'Unscheduled',
                ],
            ],
        ],
        'avs_error_code' => '2001',
    ],
    '3ds_version' => env('THREE_DS_VERSION', 1),
    '3ds_notification_url' => env('THREE_DS_NOTIFICATION_URL'),
    '3ds_notification_url_path' => env('THREE_DS_NOTIFICATION_URL_PATH', 'sagePayRedirect.php'),
];
