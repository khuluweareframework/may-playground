<?php

namespace Modules\Payment\Console;

use Exception;
use Illuminate\Console\Command;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Gateway\Sagepay\AbortPayment;

class VoidOffDeferredTransactionCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $name = 'cron:void-off-deferred-transactions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command is used to void the deferred transaction made in the system.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $transactions = Transaction::whereDoesntHave('children', function ($query) {
            $query->where('transaction_type', 'Abort');
        })->where('transaction_type', 'Deferred')->where('transaction_amount', 1)->get();

        foreach ($transactions as $transaction) {
            if (! $transaction->getIsAbortedAttribute()) {
                try {
                    // Initiate abort trasaction
                    $abortPayment = new AbortPayment([], $transaction->transaction_id);

                    // Abort trasaction
                    $response = json_decode((string) $abortPayment->abortOrder()->getBody(), true);
                    
                    // Prepare child abort trasaction attributes
                    $attributes['customer_uuid'] = $transaction->customer_uuid;
                    $attributes['parent_uuid'] = $transaction->uuid;
                    $attributes['order_uuid'] = $transaction->order_uuid;
                    $attributes['transaction_id'] = $transaction->transaction_id;
                    $attributes['transaction_type'] = 'Abort';
                    $attributes['transaction_response'] = $response;
            
                    // Create child abort trasaction
                    $transaction = Transaction::abortWithAttributes($attributes);
                } catch (Exception $e) {
                    report($e);
                    continue;
                }
            }
        }
    }
}
