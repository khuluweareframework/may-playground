<?php

namespace Modules\Payment\Contracts;

use Modules\Payment\Exceptions\PaymentException;

interface AbortTransaction
{
    /**
     * @throws PaymentException
     */
    public function abortOrder();

    /**
     * @throws PaymentException
     *
     * @return void
     */
    public function validateResponse();
}
