<?php

namespace Modules\Payment\Contracts;

interface Address
{
    public function getAddress1(): string;

    public function getAddress2(): string;

    public function getCity(): string;

    public function getPostCode(): string;
}
