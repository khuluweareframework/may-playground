<?php

namespace Modules\Payment\Contracts;

use Carbon\Exceptions\InvalidDateException;

interface Card
{
    public function getCardHolderName(): string;

    public function getCardNumber(): string;

    /**
     * @throws InvalidDateException
     */
    public function getCardExpiryDate(): string;

    /**
     * This is a numerical value btwn 3-4 chars long, depending on the implementing contract.
     */
    public function getCardSecurityCode(): int;
}
