<?php

namespace Modules\Payment\Contracts;

interface Customer
{
    /**
     * Get the customer title required for processing card.
     */
    public function getTitle(): string;

    /**
     * Get customer first name.
     */
    public function getFirstName(): string;

    /**
     * Get Customer last name.
     */
    public function getLastName(): string;

    /**
     * Get the billing address linked to the customer Card.
     */
    public function getBillingAddress(): Address;

    /**
     * Get customer billing address from the customer object.
     */
    public function getShippingAddress(): Address;
}
