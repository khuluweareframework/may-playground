<?php

namespace Modules\Payment\Contracts;

use Modules\Payment\Exceptions\PaymentException;
use Psr\Http\Message\ResponseInterface;

interface Deferred
{
    /**
     * @throws PaymentException
     */
    public function processOrder();

    /**
     * @return mixed
     */
    public function createCardIdentifier();

    /**
     * Generate Merchant Session Key.
     *
     * @throws PaymentException
     *
     * @return ResponseInterface
     */
    public function getToken(): ResponseInterface;

    /**
     * @throws PaymentException
     */
    public function deferredOrder();

    /**
     * parse & format Response from third party
     */
    public function parseResponse($data);
}
