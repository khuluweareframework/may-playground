<?php

namespace Modules\Payment\Contracts;

use Psr\Http\Message\ResponseInterface;

interface PaymentGateway
{
    /**
     * Set required payload when PaymentGateway resolved
     *
     * @param   array  $payload
     * @return object
     */
    public function setPayload(array $payload);

    /**
     * Create card identifier
     * @return mixed
     */
    public function createCardIdentifier();

    /**
     * Generate Merchant Session Key.
     *
     * @return ResponseInterface
     */
    public function getToken(): ResponseInterface;

    /**
     * @return void
     */
    public function validateResponse();

    /**
     * @return array
     */
    public function getTransaction();
    
    /**
     * prepare payload, send client request and get response
     *
     * @return ResponseInterface
     */
    public function processOrder();
}
