<?php

namespace Modules\Payment\Contracts;

use Modules\Payment\Exceptions\PaymentException;
use Psr\Http\Message\ResponseInterface;

interface Refund
{
    /**
     * @throws PaymentException
     */
    public function refundOrder();

    /**
     * Generate Merchant Session Key.
     *
     * @throws PaymentException
     *
     * @return ResponseInterface
     */
    public function getToken(): ResponseInterface;

    /**
     * @throws PaymentException
     *
     * @return void
     */
    public function validateResponse();
}
