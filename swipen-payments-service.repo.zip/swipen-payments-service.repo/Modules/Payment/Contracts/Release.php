<?php

namespace Modules\Payment\Contracts;

use Modules\Payment\Exceptions\PaymentException;

interface Release
{
    /**
     * @throws PaymentException
     */
    public function releaseOrder();

    /**
     * @throws PaymentException
     *
     * @return void
     */
    public function validateResponse();
}
