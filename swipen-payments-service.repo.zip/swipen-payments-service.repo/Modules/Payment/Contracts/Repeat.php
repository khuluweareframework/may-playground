<?php

namespace Modules\Payment\Contracts;

use App\Contracts\ValidateTransactionExists;

interface Repeat
{
    /**
     * @return array
     */
    public function repeatOrder();
}
