<?php

namespace App\Contracts;

interface ValidateTransactionExists
{
    /**
     * Transaction in question identifier.
     */
    public function setTransactionId(): string;

    /**
     * @throws \Exception
     *
     * @return array object with transaction data
     */
    public function checkTransactionExists(): array;

    /**
     * This will be used for refund, and void optlions as we will need to check the amount being processed is not
     * greater than the total invoice amount.
     */
    public function getTransactionAmount(): float;
}
