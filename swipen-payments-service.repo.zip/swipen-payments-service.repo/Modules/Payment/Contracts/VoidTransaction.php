<?php

namespace Modules\Payment\Contracts;

use Modules\Payment\Exceptions\PaymentException;

interface VoidTransaction
{
    /**
     * @throws PaymentException
     */
    public function voidOrder();

    /**
     * @throws PaymentException
     *
     * @return void
     */
    public function validateResponse();
}
