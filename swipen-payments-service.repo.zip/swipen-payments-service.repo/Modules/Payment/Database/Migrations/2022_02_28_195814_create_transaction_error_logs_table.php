<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionErrorLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transaction_error_logs', function (Blueprint $table) {
            $table->integerIncrements('id');
            $table->uuid('uuid')->unique();
            $table->uuid('customer_uuid')->nullable();
            $table->uuid('order_uuid')->nullable();
            $table->uuid('payment_information_uuid')
                ->nullable()
                ->comment('the payment information from payment information');
            $table->unsignedInteger('transaction_amount')->nullable()->comment('Amount');
            $table->json('transaction_response')->nullable();
            $table->text('error_description')
                ->nullable()
                ->comment('Error Description');
            $table->string('transaction_id')->nullable();
            $table->string('transaction_type')->nullable();
            $table->uuid('account_type_uuid')
                ->nullable()
                ->comment('Holds payment account type table');
            $table->timestamps();
        });

        Schema::table('transaction_error_logs', function (Blueprint $table) {
            $table->index('customer_uuid');
            $table->index('order_uuid');
            $table->index('payment_information_uuid');
            $table->index('account_type_uuid');
            $table->index('transaction_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('transaction_error_logs', function (Blueprint $table) {
            $table->dropIndex('transaction_error_logs_customer_uuid_index');
            $table->dropIndex('transaction_error_logs_order_uuid_index');
            $table->dropIndex('transaction_error_logs_payment_information_uuid_index');
            $table->dropIndex('transaction_error_logs_account_type_uuid_index');
            $table->dropIndex('transaction_error_logs_transaction_id_index');
        });
        Schema::dropIfExists('transaction_error_logs');
    }
}
