<?php

namespace Modules\Payment\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Payment\Entities\AccountType;

class AccountTypesTableSeeder extends Seeder
{
    /** @var array */
    private $types = [
        [
            'uuid'          => 'c427c6c3-82c5-4d31-8152-b36507db3351',
            'name'          => 'Ecommerce Transactions',
            'code'          => 'E',
            'entry_method'  => 'Ecommerce',
            'description'   => 'Indicates transaction is made by customer',
        ],
        [
            'uuid'          => 'c427c6c3-82c5-4d31-8152-b36507db3352',
            'name'          => 'CCE Transaction',
            'code'          => 'M',
            'entry_method'  => 'TelephoneOrder',
            'description'   => 'Indicates transaction is done by cce',
        ],
        [
            'uuid'          => 'c427c6c3-82c5-4d31-8152-b36507db3353',
            'name'          => 'Repeat Transactions',
            'code'          => 'C',
            'entry_method'  => 'Ecommerce',
            'description'   => 'Indicates transaction is made by collection cron',
        ],
    ];

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        collect($this->types)
            ->each(function ($type) {
                AccountType::updateOrCreate([
                    'uuid' => $type['uuid'],
                    'code' => $type['code'],
                ], [
                    'name' => $type['name'],
                    'entry_method' => $type['entry_method'],
                    'description' => $type['description'],
                ]);
            });
    }
}
