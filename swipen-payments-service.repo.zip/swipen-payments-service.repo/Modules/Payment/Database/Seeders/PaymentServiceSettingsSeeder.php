<?php

namespace Modules\Payment\Database\Seeders;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Seeder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\App;
use Modules\Payment\Entities\Settings;

class PaymentServiceSettingsSeeder extends Seeder
{
    public function run()
    {
        $settings = [
            [
                'uuid'          =>  '64d64a49-5375-429f-a74b-595ef6421ce3',
                'key'           =>  'apply_avs_cvc_check',
                'value'         =>  'Disable',
                'active'        =>  0,
            ],
            [
                'uuid'          =>  '5a8e6f60-741c-48ef-a79c-58cbfe9b6cc4',
                'key'           =>  'apply_3d_secure',
                'value'         =>  'Disable',
                'active'        =>  0,
            ],
            [
                'uuid'          =>  '44e8e6a8-c9be-4976-8745-41e1162113ed',
                'key'           =>  'dna_postcode_override',
                'value'         =>  '10',
                'active'        =>  0,
            ],
            [
                'uuid'          =>  '1f2f6348-ce09-4686-9a3b-cd5f4b0b733d',
                'key'           =>  'dna_house_number_override',
                'value'         =>  '100',
                'active'        =>  0,
            ],
            [
                'uuid'          =>  '5ab59ac1-9db0-4ffc-a55a-bfd843806a88',
                'key'           =>  'dna_csc_override',
                'value'         =>  '111',
                'active'        =>  0,
            ],
            [
                'uuid'          =>  'db198b83-897d-454f-a734-dbd8bcebc420',
                'key'           =>  '3ds_version',
                'value'         =>  '1',
                'active'        =>  0,
            ],
            [
                'uuid'          =>  '1df7984d-053f-45dc-9c80-1d0233fe78fd',
                'key'           =>  'sagepay_postcode_override',
                'value'         =>  '412',
                'active'        =>  ! App::environment(['production']) ? 1: 0,
            ],
            [
                'uuid'          =>  '3dc3424c-d311-4579-b616-ed660b1263f0',
                'key'           =>  'sagepay_house_number_override',
                'value'         =>  '88',
                'active'        =>  ! App::environment(['production']) ? 1: 0,
            ],
            [
                'uuid'          =>  '204011c3-7810-494c-9291-40123e8e6509',
                'key'           =>  'sagepay_csc_override',
                'value'         =>  '123',
                'active'        =>  ! App::environment(['production']) ? 1: 0,
            ],
            [
                'uuid'          =>  '5dbde496-986a-4aef-8420-3332952270f9',
                'key'           =>  'skip_deferred',
                'value'         =>  'Enable',
                'active'        =>  0,
            ],
        ];

        Model::unguard();

        collect($settings)
            ->each(function ($setting) {
                if (Settings::where('key', $setting['key'])->exists()) {
                    return;
                }
                Settings::updateOrCreate([
                    'uuid'  => $setting['uuid'],
                    'key'   => $setting['key'],
                ], Arr::except($setting, ['uuid', 'key']));
            });

        Model::reguard();
    }
}
