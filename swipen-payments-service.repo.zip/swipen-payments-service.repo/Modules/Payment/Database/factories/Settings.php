<?php

use Faker\Generator as Faker;
use Modules\Payment\Entities\Settings;

$factory->define(Settings::class, function (Faker $faker) {
    return [
        'uuid' => $faker->uuid,
        'key' => $faker->text(10),
        'value' => $faker->text(20),
        'active' =>  $faker->randomElement([1,0]),
        'created_at' => $faker->dateTime()->format('Y-m-d H:i:s'),
        'updated_at' => $faker->dateTime()->format('Y-m-d H:i:s'),
    ];
});
