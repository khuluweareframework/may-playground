<?php

use Faker\Generator as Faker;
use Illuminate\Support\Str;
use Modules\Payment\Entities\Transaction;

$factory->define(Transaction::class, function (Faker $faker) {
    return [
        'uuid' => $faker->uuid,
        'customer_uuid' => $faker->uuid,
        'order_uuid' => $faker->uuid,
        'transaction_id' => (string) Str::orderedUuid(),
        'transaction_type' => $faker->randomElement(['Payment', 'Repeat', 'Deferred']),
        'transaction_amount' => $faker->numberBetween(1000, 10000),
        'transaction_response' => null,
        'created_at' => $faker->dateTime()->format('Y-m-d H:i:s'),
        'updated_at' => $faker->dateTime()->format('Y-m-d H:i:s'),
    ];
});

$factory->state(Transaction::class, 'authenticated', [
    'transaction_response' => ['status' => 'Authenticated'],
]);

$factory->state(Transaction::class, 'notAuthenticated', [
    'transaction_response' => ['status' => 'NotAuthenticated'],
]);
