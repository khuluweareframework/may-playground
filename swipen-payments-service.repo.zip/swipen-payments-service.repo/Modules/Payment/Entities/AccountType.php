<?php

namespace Modules\Payment\Entities;

use \Illuminate\Database\Eloquent\Model;

class AccountType extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'uuid',
        'name',
        'code',
        'entry_method',
        'description',
    ];

    const ECOMMERCE = 'c427c6c3-82c5-4d31-8152-b36507db3351';
    const CCE = 'c427c6c3-82c5-4d31-8152-b36507db3352';
    const REPEAT = 'c427c6c3-82c5-4d31-8152-b36507db3353';

    public static function uuid(string $uuid): ?AccountType
    {
        return static::where('uuid', $uuid)->first();
    }
}
