<?php

namespace Modules\Payment\Entities;

use \Illuminate\Database\Eloquent\Model;

class Settings extends Model
{
    protected $table = 'settings';
}
