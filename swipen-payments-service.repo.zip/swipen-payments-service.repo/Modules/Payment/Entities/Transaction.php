<?php

namespace Modules\Payment\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Modules\Payment\Events\AbortTransactionCreated;
use Modules\Payment\Events\BulkVoidTransactionsCreated;
use Modules\Payment\Events\DeferTransactionCreated;
use Modules\Payment\Events\PaymentTransactionCreated;
use Modules\Payment\Events\PaymentTransactionFinalised;
use Modules\Payment\Events\RefundTransactionCreated;
use Modules\Payment\Events\ReleaseTransactionCreated;
use Modules\Payment\Events\RepeatTransactionCreated;
use Modules\Payment\Events\TransactionReadList;
use Modules\Payment\Events\VoidTransactionCreated;
use Ramsey\Uuid\Uuid;

class Transaction extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'uuid',
        'parent_uuid',
        'customer_uuid',
        'order_uuid',
        'vendor_tx_code',
        'transaction_id',
        'transaction_type',
        'transaction_amount',
        'transaction_response',
        'payment_information_uuid',
        'account_type_uuid',
        'is_successful',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'transaction_response' => 'array',
        'is_successful' => 'boolean',
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = [
        'card_last_four_digits',
        'card_expiry_date',
        'is_voided',
        'is_aborted',
        'is_refunded',
        'refunded_amount',
    ];

    /**
     * Get the route key for the model.
     *
     * @return string
     */
    public function getRouteKeyName()
    {
        return 'uuid';
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function children()
    {
        return $this->hasMany(Transaction::class, 'parent_uuid', 'uuid');
    }

    /**
     * Get the transactions's card last 4 digits.
     *
     * @return string|null
     */
    public function getCardLastFourDigitsAttribute()
    {
        return data_get($this->transaction_response, 'paymentMethod.card.lastFourDigits');
    }

    /**
     * Get the transactions's card expiry date.
     *
     * @return string|null
     */
    public function getCardExpiryDateAttribute()
    {
        return data_get($this->transaction_response, 'paymentMethod.card.expiryDate');
    }

    /**
     * Is the transaction voided?
     *
     * @return bool
     */
    public function getIsVoidedAttribute()
    {
        return $this->children()->where('transaction_type', 'Void')->exists();
    }

    /**
     * Is the transaction aborted?
     *
     * @return bool
     */
    public function getIsAbortedAttribute()
    {
        return $this->children()->where('transaction_type', 'Abort')->exists();
    }

    /**
     * Is the transaction refunded?
     *
     * @return bool
     */
    public function getIsRefundedAttribute()
    {
        return $this->children()->where('transaction_type', 'Refund')->exists();
    }

    /**
     * Get the transaction's refunded amount.
     *
     * @return int
     */
    public function getRefundedAmountAttribute()
    {
        return $this->children()->where('transaction_type', 'Refund')->sum('transaction_amount');
    }

    /**
     * Checks if 3D secure transaction is authenticated.
     *
     * @return bool
     */
    public function getIsAuthenticatedAttribute(): bool
    {
        return Arr::get($this->transaction_response, 'status') === 'Authenticated';
    }

    public static function createWithAttributes($attributes, $finalise = false): self
    {
        $attributes['uuid'] = Uuid::uuid4()->toString();

        $finalise ? event(new PaymentTransactionFinalised($attributes)) : event(new PaymentTransactionCreated($attributes));

        return self::uuid($attributes['uuid']);
    }

    public static function deferWithAttributes($attributes)
    {
        $attributes['uuid'] = Uuid::uuid4()->toString();

        event(new DeferTransactionCreated($attributes));

        return self::uuid($attributes['uuid']);
    }

    public static function refundWithAttributes($attributes)
    {
        $attributes['uuid'] = Uuid::uuid4()->toString();

        event(new RefundTransactionCreated($attributes));

        return self::uuid($attributes['uuid']);
    }

    public static function repeatWithAttributes($attributes)
    {
        $attributes['uuid'] = Uuid::uuid4()->toString();

        event(new RepeatTransactionCreated($attributes));

        return self::uuid($attributes['uuid']);
    }

    public static function abortWithAttributes($attributes)
    {
        $attributes['uuid'] = (string) Uuid::uuid4();

        event(new AbortTransactionCreated($attributes));

        return self::uuid($attributes['uuid']);
    }

    public static function voidWithAttributes($attributes)
    {
        $attributes['uuid'] = Uuid::uuid4()->toString();

        event(new VoidTransactionCreated($attributes));

        return self::uuid($attributes['uuid']);
    }

    public static function releaseWithAttributes($attributes)
    {
        $attributes['uuid'] = Uuid::uuid4()->toString();

        event(new ReleaseTransactionCreated($attributes));

        return self::uuid($attributes['uuid']);
    }

    public static function uuid(string $uuid): ?self
    {
        return static::where('uuid', $uuid)->first();
    }

    public function retrieveList($options)
    {
        event(new TransactionReadList($options));

        $query = self::query();

        $order = $options['order'] ?? 'desc';
        $perPage = $options['per_page'] ?? 15;
        $filters = $options['filters'] ?? [];
        if (! empty($filters['order_uuid'])) {
            $query->where('order_uuid', $filters['order_uuid']);
        }

        if (! empty($filters['type'])) {
            $query->whereIn('transaction_type', $filters['type']);
        }

        $query->when($filters['created_at'] ?? false, function ($q, $date) {
            return $q->whereDate('created_at', $date);
        });

        if (isset($filters['parent_uuid'])) {
            $parentUuid = ($filters['parent_uuid'] === '' || $filters['parent_uuid'] === 0) ? null : $filters['parent_uuid'];
            $query->where('parent_uuid', $parentUuid);
        }

        if (isset($options['order_by']) && in_array(strtolower($order), ['asc', 'desc'])) {
            $query->orderBy($options['order_by'], $order);
        }

        // Show only Successful transactions
        $query->when($filters['is_successful'] ?? false, function ($q) {
            return $q->where('is_successful', true);
        });

        if ($perPage === '-1') {
            return $query->get();
        }

        return $query->paginate($perPage);
    }

    /**
     * @param array $voidTransactions
     * @return $this|null
     */
    public function voidAllWithAttributes(array $voidTransactions)
    {
        // add uuid to every single transaction to be voided
        array_walk($voidTransactions, function (&$val) {
            $val['uuid'] = Uuid::uuid4()->toString();
        });

        event(new BulkVoidTransactionsCreated($voidTransactions));

        return self::whereIn(
            'uuid',
            collect($voidTransactions)->pluck('uuid')->toArray()
        )->get();
    }
}
