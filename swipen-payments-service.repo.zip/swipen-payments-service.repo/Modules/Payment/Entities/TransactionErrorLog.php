<?php

namespace Modules\Payment\Entities;

use Illuminate\Database\Eloquent\Model;
use Modules\Payment\Events\TransactionErrorLogCreated;
use Ramsey\Uuid\Uuid;

class TransactionErrorLog extends Model
{
    protected $fillable = [
        'uuid',
        'customer_uuid',
        'order_uuid',
        'payment_information_uuid',
        'transaction_amount',
        'transaction_response',
        'error_description',
        'transaction_id',
        'transaction_type',
        'account_type_uuid',
        'payment_type_uuid',
        
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'transaction_response' => 'array',
    ];

    /**
     * Get the route key for the model.
     *
     * @return string
     */
    public function getRouteKeyName()
    {
        return 'uuid';
    }

    public static function uuid(string $uuid): ?self
    {
        return static::where('uuid', $uuid)->first();
    }

    /**
     * Create With Attributes
     *
     * @param array $attributes
     * @return self
     */
    public static function createWithAttributes(array $attributes): self
    {
        $attributes['uuid'] = Uuid::uuid4()->toString();

        event(new TransactionErrorLogCreated($attributes));

        return self::uuid($attributes['uuid']);
    }
}
