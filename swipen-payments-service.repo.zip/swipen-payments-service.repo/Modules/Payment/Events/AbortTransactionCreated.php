<?php

namespace Modules\Payment\Events;

use Spatie\EventSourcing\ShouldBeStored;

class AbortTransactionCreated implements ShouldBeStored
{
    /**
     * @var array
     */
    public $transactionAttributes;

    /**
     * Create a new event instance.
     *
     * PayTransaction constructor.
     */
    public function __construct(array $transactionAttributes)
    {
        $this->transactionAttributes = $transactionAttributes;
    }
}
