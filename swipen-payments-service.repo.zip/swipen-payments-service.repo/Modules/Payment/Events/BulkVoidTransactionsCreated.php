<?php

namespace Modules\Payment\Events;

use Spatie\EventSourcing\ShouldBeStored;

class BulkVoidTransactionsCreated implements ShouldBeStored
{
    /**
     * @var array
     */
    public $voidTransactions;

    /**
     * @param array $voidTransactions
     */
    public function __construct(array $voidTransactions)
    {
        $this->voidTransactions = $voidTransactions;
    }
}
