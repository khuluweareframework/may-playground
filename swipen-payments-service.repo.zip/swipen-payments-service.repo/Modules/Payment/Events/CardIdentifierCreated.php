<?php

namespace Modules\Payment\Events;

use Spatie\EventSourcing\ShouldBeStored;

class CardIdentifierCreated implements ShouldBeStored
{
    //
}
