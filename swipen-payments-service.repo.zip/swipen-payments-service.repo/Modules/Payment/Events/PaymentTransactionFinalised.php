<?php

namespace Modules\Payment\Events;

use Spatie\EventSourcing\ShouldBeStored;

class PaymentTransactionFinalised implements ShouldBeStored
{
    /**
     * @var array
     */
    public $transactionUuid;

    /**
     * @var array|object
     */
    public $transactionAttributes;

    /**
     * Create a new event instance.
     *
     * PayTransaction constructor.
     */
    public function __construct(array $transactionAttributes)
    {
        $this->transactionUuid = $transactionAttributes['uuid'];

        $this->transactionAttributes = $transactionAttributes;
    }
}
