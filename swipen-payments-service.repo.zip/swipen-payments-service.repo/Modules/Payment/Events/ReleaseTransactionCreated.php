<?php

namespace Modules\Payment\Events;

use Spatie\EventSourcing\ShouldBeStored;

class ReleaseTransactionCreated implements ShouldBeStored
{
    /**
     * @var array
     */
    public $transactionAttributes;

    /**
     * Create a new event instance.
     */
    public function __construct(array $transactionAttributes)
    {
        $this->transactionUuid = $transactionAttributes['uuid'];

        $this->transactionAttributes = $transactionAttributes;
    }
}
