<?php

namespace Modules\Payment\Events;

use Spatie\EventSourcing\ShouldBeStored;

class TransactionErrorLogCreated implements ShouldBeStored
{

    /**
     * Attributes
     *
     * @var array
     */
    public $attributes;

    /**
     * Create a new event instance
     *
     * @param array $attributes
     * @return void
     */
    public function __construct(array $attributes)
    {
        $this->attributes = $attributes;
    }
}
