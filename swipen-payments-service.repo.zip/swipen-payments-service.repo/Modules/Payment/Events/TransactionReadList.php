<?php

namespace Modules\Payment\Events;

use Spatie\EventSourcing\ShouldBeStored;

class TransactionReadList implements ShouldBeStored
{
    /** @var array */
    public $options;

    public function __construct(array $options)
    {
        $this->options = $options;
    }
}
