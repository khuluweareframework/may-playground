<?php

namespace Modules\Payment\Events;

use Spatie\EventSourcing\ShouldBeStored;

class TransactionReadSingle implements ShouldBeStored
{
    /**
     * @var int
     */
    public $transactionId;

    public function __construct(int $transactionId)
    {
        $this->transactionId = $transactionId;
    }
}
