<?php

namespace Modules\Payment\Exceptions;

use Exception;

class BlockCardException extends Exception
{
    public $data;

    public function __construct(string $message, array $data)
    {
        $this->data = $data;

        parent::__construct($message, 0, null);
    }
}
