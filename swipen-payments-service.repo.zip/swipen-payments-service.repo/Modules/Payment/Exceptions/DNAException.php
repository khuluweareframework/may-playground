<?php


namespace Modules\Payment\Exceptions;

use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use Illuminate\Validation\ValidationException;
use Psr\Http\Message\ResponseInterface;

class DNAException extends PaymentException
{
    /**
     * The status code to use for the response.
     *
     * @var int
     */
    public $statusCode = 502;

    /**
     * The response throwing the exception.
     *
     * @var ResponseInterface
     */
    public $response;

    /**
     * @param string $message
     * @param null $statusCode
     * @param ResponseInterface|null $response
     */
    public function __construct($message = 'An error occurred contacting DNA payments.', $statusCode = null, ResponseInterface $response = null)
    {
        parent::__construct($message, $statusCode, $response);

        if ($statusCode !== null) {
            $this->statusCode = $statusCode;
        }
        $this->response = $response;
    }

    /**
     * Render the exception into an HTTP response.
     *
     * @param $request
     * @return JsonResponse|Response
     * @throws ValidationException
     * @throws Exception
     */
    public function render($request)
    {
        if ($this->response === null) {
            return response()->json([
                'message' => $this->getMessage(),
            ], $this->statusCode);
        }

        $body = json_decode((string) $this->response->getBody(), true);

        if (! $body['success']) {
            throw ValidationException::withMessages(['message' => $body['message']]);
        }
    }
}
