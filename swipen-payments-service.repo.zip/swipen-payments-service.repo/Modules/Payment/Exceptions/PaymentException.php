<?php


namespace Modules\Payment\Exceptions;

use Exception;
use Psr\Http\Message\ResponseInterface;

class PaymentException extends Exception
{
    /**
     * The custom message for the response.
     *
     * @var int
     */
    public $customMessage = null;

    /**
     * The status code to use for the response.
     *
     * @var int
     */
    public $statusCode = 400;

    /**
     * The response throwing the exception.
     *
     * @var ResponseInterface
     */
    public $response;

    /**
     * @param $customMessage
     * @param null $statusCode
     * @param ResponseInterface|null $response
     */
    public function __construct($customMessage = null, $statusCode = null, ResponseInterface $response = null)
    {
        parent::__construct($customMessage);

        if ($statusCode !== null) {
            $this->statusCode = $statusCode;
        }

        if ($customMessage !== null) {
            $this->customMessage = $customMessage;
        }

        $this->response = $response;
        $this->render($response);
    }

    /**
     * @param $request
     * @throws DNAException
     * @throws SagepayException
     */
    public function render($request)
    {
        $paymentProvider = strtolower(config('payment.payment_channel'));

        $params = [$this->customMessage, $this->statusCode, $this->response];
        switch ($paymentProvider) {
            case 'dna':
                throw new DNAException(...$params);
            case 'sagepay':
                throw new SagepayException(...$params);
        }
    }
}
