<?php

namespace Modules\Payment\Exceptions;

use Illuminate\Http\Response;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Modules\Payment\Entities\TransactionErrorLog;
use Psr\Http\Message\ResponseInterface;

class SagepayException extends PaymentException
{
    /**
     * The status code to use for the response.
     *
     * @var int
     */
    public $statusCode = 502;

    /**
     * The response throwing the exception.
     *
     * @var ResponseInterface
     */
    public $response;

    /**
     * @param string $message
     * @param null $statusCode
     * @param ResponseInterface|null $response
     */
    public function __construct($message = 'An error occurred contacting sagepay.', $statusCode = null, ResponseInterface $response = null)
    {
        parent::__construct($message);

        if (! is_null($statusCode)) {
            $this->statusCode = $statusCode;
        }

        $this->response = $response;
    }

    /**
     * Render the exception into an HTTP response.
     *
     * @param $request
     * @return Response
     * @throws ValidationException
     */
    public function render($request)
    {
        if (is_null($this->response)) {
            return response()->json([
                'message' => $this->getMessage(),
            ], $this->statusCode);
        }

        // Add LOG in Kibana for request PARES and CRES
        if (! empty(request()->all()['pa_res']) || ! empty(request()->all()['cres'])) {
            Log::debug(' Sagepay Exception: PARES and CRES request', [
                'PARES' => request()->all()['pa_res'] ?? '',
                'CRES' => request()->all()['cres'] ?? '',
            ]);
        }

        $body = json_decode((string) $this->response->getBody(), true);

        $customerUuid = ! empty(request()->input('transaction'))
                        ? request()->input('transaction')->customer_uuid
                        : request()->get('customer_uuid');
        $orderUuid = ! empty(request()->input('transaction'))
                    ? request()->input('transaction')->order_uuid
                    : request()->get('order_uuid');
        $paymentInfoUuid = ! empty(request()->input('transaction'))
                    ? request()->input('transaction')->payment_information_uuid
                    : request()->get('payment_information_uuid');
        $accountTypeUuid = ! empty(request()->input('transaction'))
                    ? request()->input('transaction')->account_type_uuid
                    : request()->get('account_type_uuid');

        $errorAttributes = [
            'customer_uuid' => $customerUuid,
            'order_uuid' => $orderUuid,
            'payment_information_uuid' => $paymentInfoUuid,
            'transaction_amount' => request()->get('amount'),
            'transaction_response' => $body,
            'transaction_type' => request()->get('txType'),
            'transaction_id' => $body['transactionId'] ?? '' ,
            'account_type_uuid' => $accountTypeUuid,
        ];
        // Transform sagepay 422 errors into Laravel's validation exception
        if ($this->statusCode === 422) {
            if (Arr::has($body, 'errors.0.clientMessage')) {
                $errors = collect($body['errors'])
                    -> mapWithKeys(function ($error) {
                        return [Str::snake($error['property']) => $error['clientMessage']];
                    })
                    ->toArray();
                $errorAttributes['error_description'] = Arr::get($body, 'errors.0.clientMessage');
                TransactionErrorLog::createWithAttributes($errorAttributes);
                throw ValidationException::withMessages($errors);
            }

            if (Arr::has($body, 'errors.0.description')) {
                $errors = collect($body['errors'])
                    ->mapWithKeys(function ($error) {
                        return [Str::snake($error['property']) => $error['description']];
                    })
                    ->toArray();
                $errorAttributes['error_description'] = Arr::get($body, 'errors.0.description');
                TransactionErrorLog::createWithAttributes($errorAttributes);
                throw ValidationException::withMessages($errors);
            }

            if (Arr::has($body, 'status') && $body['status'] === 'Invalid') {
                $possibleErrorFields = ['VendorTxCode', 'Amount'];

                foreach ($possibleErrorFields as $field) {
                    if (Str::contains($body['statusDetail'], $field)) {
                        $errorAttributes['error_description'] = $body['statusDetail'];
                        TransactionErrorLog::createWithAttributes($errorAttributes);
                        throw ValidationException::withMessages([Str::snake($field) => $body['statusDetail']]);
                    }
                }

                if (preg_match("/The\s(.*)\svalue/", $body['statusDetail'], $matches)) {
                    $errorAttributes['error_description'] = $body['statusDetail'];
                    TransactionErrorLog::createWithAttributes($errorAttributes);
                    throw ValidationException::withMessages([Str::snake($matches[1]) => $body['statusDetail']]);
                }

                $errorAttributes['error_description'] = $body['statusDetail'];
                TransactionErrorLog::createWithAttributes($errorAttributes);
                throw ValidationException::withMessages(['field' => $body['statusDetail']]);
            }
        } elseif ($this->statusCode === 403) {
            // Transform specific 403 sagepay errors into Laravel's validation exception
            if (Arr::has($body, 'description')) {
                $errorAttributes['error_description'] = $body['description'];
                TransactionErrorLog::createWithAttributes($errorAttributes);
                $possibleErrorFields = [
                    'refund amount' => 'amount',
                    'release amount' => 'amount',
                ];

                foreach ($possibleErrorFields as $field => $key) {
                    if (Str::contains($body['description'], $field)) {
                        throw ValidationException::withMessages([$key => $body['description']]);
                    }
                }
            }
        } elseif ($this->statusCode === 404) {
            if (Arr::has($body, 'description')) {
                $errorAttributes['error_description'] = $body['description'];
                TransactionErrorLog::createWithAttributes($errorAttributes);
            }
        }

        return response()->json([
            'message' => $body['description'] ?? $this->getMessage(),
        ], $this->statusCode);
    }
}
