<?php

namespace Modules\Payment\Gateway\Dna;

use Modules\Payment\Contracts\Deferred as PaymentContractInterface;
use Modules\Payment\Exceptions\ManualValidationExceptionTrait;
use Modules\Payment\Exceptions\PaymentException;

class Deferred extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    public function __construct()
    {
        parent::__construct();
        $this->transactionType = 'VERIFICATION';
    }

    public function setPayload(array $payload)
    {
        // Set payload amount to zero for defer/verification transaction
        $payload['amount'] = 0;

        //Override AVS/CSC parameters if enabled
        $avsCscOveriride = $this->checkAvsCscMatrixOverride();
        if (! empty($avsCscOveriride)) {
            foreach ($avsCscOveriride as $aco) {
                if ($aco['key'] === 'dna_postcode_override' && ! empty($payload['billing_address']['postal_code'])) {
                    $payload['billing_address']['postal_code'] = $aco['value'];
                } elseif ($aco['key'] === 'dna_house_number_override' && ! empty($payload['billing_address']['address1'])) {
                    $payload['billing_address']['address1'] = $aco['value'];
                } elseif ($aco['key'] === 'dna_csc_override' && ! empty($payload['card_details']['security_code'])) {
                    $payload['card_details']['security_code'] = $aco['value'];
                }
            }
        }

        parent::setPayload($payload);

        return $this;
    }

    /**
     * @throws PaymentException
     */
    public function deferredOrder()
    {
        $response = $this->processOrder();

        return $this->parseResponse($response);
    }

    protected function preparePayload(): array
    {
        $cardDetails = [];
        $cardData = ['accountNumber' => $this->payload['card_details']['card_number'],
        'expirationMonth' => substr($this->payload['card_details']['expiry_date'], 0, 2),
        'expirationYear' => substr($this->payload['card_details']['expiry_date'], 2, 2),
        'csc'=> $this->payload['card_details']['security_code'],
        'cardholderName' => $this->payload['card_details']['cardholder_name'],
        ];
        $cardDetails['encryptedData'] = $this->getEncryptedCardData($cardData);

        // Get 3DS version from database or config
        $threeDSVersion = $this->get3dsVersion();
        
        $paymentSettings = [
            'terminalId' => config('payment.dna.auth.terminal'),
            'threeDSVersion' => $threeDSVersion,
        ];

        //Check for AVS and CVC
        if (! empty($this->payload['apply_avs_cvc_check'])) {
            $paymentSettings = $this->getAvsCvs($paymentSettings, $this->payload['apply_avs_cvc_check']);
        }

        $payload = [
            'invoiceId' => $this->payload['vendor_tx_code'],
            'description' => $this->payload['description'],
            'transactionType' => $this->transactionType,
            'amount' => pence_to_pound($this->payload['amount']),
            'currency' => $this->payload['currency'],
            'periodic' => [
                'periodicType' => 'ucof',
            ],
            'paymentSettings' => $paymentSettings,
            'customerDetails' => [
                'email' => $this->payload['customer_email'] ?? '',
                'firstName' => $this->payload['customer_first_name'],
                'lastName' => $this->payload['customer_last_name'],
                'billingAddress' => [
                    'firstName' => $this->payload['customer_first_name'],
                    'lastName' => $this->payload['customer_last_name'],
                    'addressLine1' =>  $this->payload['billing_address']['address1'],
                    'postalCode' => $this->payload['billing_address']['postal_code'],
                    'country' => $this->payload['billing_address']['country'],
                ],
                'browserDetails' => [
                    'screenWidth' => '1440',
                    'screenHeight' => '900',
                    'screenColorDepth' => '24',
                    'userAgent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
                    'timeZone' => '-60',
                    'language' => 'en-gb',
                    'javaEnabled' => false,
                    'challengeWindowSize' => '03',
                    'acceptHeader' => 'text/html',
                ],
            ],
            'cardDetails' =>$cardDetails,
        ];

        return  $payload;
    }

    public function parseResponse($data)
    {
        $customResponse = [];
        // Set common format paramaters
        $customResponse['payment_channel'] = parent::PAYMENT_CHANNEL;
        $customResponse['card_identifier'] = $data['cardTokenId'] ?? null;
        $customResponse['card_type'] = $data['cardSchemeName'] ?? null;
        $customResponse['amount'] = $data['amount'] ?? 0;
        $customResponse['transaction_id'] = $data['id'];
        $customResponse['transaction_type'] = $data['transactionType'];
        $customResponse['status'] = $data['status'] ?? '';
        $customResponse['success'] = $data['success'];
        $customResponse['status_details'] = $data['message'];
        // Set specific key based on transactionType
        $customResponse['can_abort'] = false; // we do defer transaction with zero amount so don't require to abort

        $customResponse['avs_cvc_error'] = $this->hasAvsCvcError($data);
        //make success true if avs/cvc error
        $customResponse['avs_cvc_error'] ? $customResponse['success'] = true : $this->throwExceptionIfRequestFails($data);

        $data['dvb_payment_response'] = $customResponse;

        return $data;
    }
}
