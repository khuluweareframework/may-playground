<?php

namespace Modules\Payment\Gateway\Dna;

use Illuminate\Support\Facades\Log;
use Modules\Payment\Contracts\Payment as PaymentContractInterface;
use Modules\Payment\Exceptions\PaymentException;

class Payment extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    public function __construct()
    {
        parent::__construct();
    }

    public function setPayload(array $payload)
    {
        parent::setPayload($payload);

        // Do custom logic
        $this->transactionType = (isset($payload['transactionType']) && $payload['transactionType'] != '') ? $payload['transactionType'] : 'SALE';

        if (empty($payload['card_details']['card_identifier'])) {
            // TODO to check for card tokenization in DNA payments
            $this->createCardIdentifier();
        }

        return $this;
    }

    /**
     * @throws PaymentException
     */
    public function paymentOrder()
    {
        $response = $this->processOrder();

        return $this->parseResponse($response);
    }

    protected function preparePayload(): array
    {
        $cardDetails = [];
        $cardData = [
            'cardTokenId' => $this->payload['card_details']['card_identifier'],
        ];
        $cardDetails['encryptedData'] = $this->getEncryptedCardData($cardData);

        // Get 3DS version from database or config
        $threeDSVersion = $this->get3dsVersion();

        $paymentSettings = [
            'terminalId' => config('payment.dna.auth.terminal'),
            'threeDSVersion' => $threeDSVersion,
            'notificationUrl' => $threeDSVersion === '2' ? config('payment.3ds_notification_url') : null,
        ];

        //Check for AVS and CVC
        if (! empty($this->payload['apply_avs_cvc_check'])) {
            $paymentSettings = $this->getAvsCvs($paymentSettings, $this->payload['apply_avs_cvc_check']);
        }

        $payload = [
            'invoiceId' => $this->payload['vendor_tx_code'],
            'description' => $this->payload['description'],
            'transactionType' => $this->transactionType,
            'amount' => pence_to_pound($this->payload['amount']),
            'currency' => $this->payload['currency'],
            'paymentSettings' => $paymentSettings,
            'customerDetails' => [
                'email' => $this->payload['customer_email'] ?? '',
                'firstName' => $this->payload['customer_first_name'],
                'lastName' => $this->payload['customer_last_name'],
                'billingAddress' => [
                    'firstName' => $this->payload['customer_first_name'],
                    'lastName' => $this->payload['customer_last_name'],
                    'addressLine1' =>  $this->payload['billing_address']['address1'],
                    'postalCode' => $this->payload['billing_address']['postal_code'],
                    'country' => $this->payload['billing_address']['country'],
                ],
                // TODO: Get Customer browser details
                'browserDetails' => [
                    'screenWidth' => '1440',
                    'screenHeight' => '900',
                    'screenColorDepth' => '24',
                    'userAgent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
                    'timeZone' => '-60',
                    'language' => 'en-gb',
                    'javaEnabled' => false,
                    'challengeWindowSize' => '03',
                    'acceptHeader' => 'text/html',
                ],
            ],
            'cardDetails' =>  $cardDetails,
        ];

        return $payload;
    }

    public function parseResponse($data)
    {
        $customResponse = [];
        // Set common format paramaters
        $customResponse['payment_channel'] = parent::PAYMENT_CHANNEL;
        $customResponse['card_identifier'] = $data['cardTokenId'] ?? null;
        $customResponse['card_type'] = $data['cardSchemeName'] ?? null;
        $customResponse['transaction_id'] = $data['id'];
        $customResponse['transaction_type'] = $data['transactionType'];
        $customResponse['status'] = $data['status'] ?? '';
        $customResponse['success'] = $data['success'];
        $customResponse['status_details'] = $data['message'];

        $customResponse['avs_cvc_error'] = $this->hasAvsCvcError($data);
        //make success true if avs/cvc error
        $customResponse['avs_cvc_error'] ? $customResponse['success'] = true : $this->throwExceptionIfRequestFails($data);

        //Check for 3DS payment, override transaction_type and return required parameters
        if ($customResponse['status'] === 'requires_action') {
            $customResponse['transaction_type'] = 'Payment-3dSecure';
            $customResponse = array_merge($customResponse, $this->get3DSecureResponseParameters($data));
        }

        //Return customer id and payment information id
        $customResponse['customer_uuid'] = $this->payload['customer_uuid'] ?? '';
        $customResponse['payment_information_uuid'] = $this->payload['payment_information_uuid'] ?? '';

        $data['dvb_payment_response'] = $customResponse;

        return $data;
    }
}
