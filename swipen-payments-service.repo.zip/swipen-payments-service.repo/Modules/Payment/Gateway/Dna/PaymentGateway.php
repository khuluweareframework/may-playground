<?php

namespace Modules\Payment\Gateway\Dna;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\Config;
use Illuminate\Validation\ValidationException;
use Modules\Payment\Contracts\PaymentGateway as ContractsPaymentGateway;
use Modules\Payment\Entities\Settings;
use Modules\Payment\Exceptions\BlockCardException;
use Modules\Payment\Exceptions\PaymentException;
use Modules\Payment\Gateway\Gateway;
use Modules\Payment\Http\Requests\ClientRequestHandler; // use phpseclib version 3
use phpseclib3\Crypt\PublicKeyLoader;
use Psr\Http\Message\ResponseInterface;

class PaymentGateway extends Gateway implements ContractsPaymentGateway
{
    protected $authAcesssObject;

    protected $cardIdentifierObject;

    protected $clientRequest;

    protected $transactionType;

    protected $payload = null;

    protected $headers = [];

    const PAYMENT_CHANNEL = 'dna';

    public function __construct()
    {
        $this->clientRequest = resolve(ClientRequestHandler::class);
    }

    public function setPayload(array $payload)
    {
        $this->payload = $payload;

        return $this;
    }

    /**
     * Generate access token Session Key.
     *
     * @return ResponseInterface
     * @throws PaymentException
     */
    public function getToken(): ResponseInterface
    {
        $postData = config('payment.dna.auth');

        // Bind invoice id and amount on token payload
        if (! empty($this->payload['vendor_tx_code'])) {
            $postData['invoiceId'] = $this->payload['vendor_tx_code'];
        }

        if (isset($this->payload['amount'])) {
            $postData['amount'] = pence_to_pound($this->payload['amount']);
        }

        $apiEndPoint = config('payment.dna.auth_url') . 'oauth2/token';

        $client = new Client();
        $response = $this->clientRequest->processRequest($apiEndPoint, 'post', $client, $postData, 'form_params');
        $this->authAcesssObject = json_decode((string) $response->getBody(), true);

        // Set header token
        $this->headers = [
            'Authorization' => 'Bearer ' . $this->authAcesssObject['access_token'],
        ];

        return $response;
    }

    public function getEncryptedCardData($cardData)
    {
        $rsa = PublicKeyLoader::load(config('payment.dna.rsa_public_key'))
        ->withHash('sha256')
        ->withMGFHash('sha256')
        ->withLabel($this->authAcesssObject['access_token']);
        $result = $rsa->encrypt(json_encode($cardData));

        return base64_encode($result);
    }

    /**
     * @throws BlockCardException
     * @throws PaymentException
     */
    public function validateResponse(): void
    {
    }

    /**
     * @return mixed|ResponseInterface
     * @throws PaymentException
     */
    public function processOrder()
    {
        // Call get access token
        $this->getToken();

        $postData = $this->preparePayload();

        if (! empty($postData['customerDetails']) && ! empty($this->payload['billing_address'] && ! empty($this->payload['billing_address']['address2']))) {
            $postData['customerDetails']['billingAddress']['addressLine2'] = $this->payload['billing_address']['address2'];
        }

        $apiEndPoint = config('payment.dna.base_url') . 'v2/payments';

        $response = $this->clientRequest->makeRequest($apiEndPoint, 'post', $postData, $this->headers);
        $statusCode = $response->getStatusCode();

        $response = json_decode((string) $response->getBody(), true);
        $response['response']['statusCode'] = $statusCode;
        // Set Transaction Type
        $response['transactionType'] = $postData['transactionType'];

        return $response;
    }

    /**
     * @return mixed|ResponseInterface
     * @throws PaymentException
     */
    public function processRepeatTransaction()
    {
        // Call get access token
        $this->getToken();

        $postData = $this->preparePayload();

        $apiEndPoint = config('payment.dna.base_url') . 'transaction/operation/recurring';

        $response = $this->clientRequest->makeRequest($apiEndPoint, 'post', $postData, $this->headers);
        $statusCode = $response->getStatusCode();
        $response = json_decode((string) $response->getBody(), true);

        $response['response']['statusCode'] = $statusCode;
        // Set Transaction Type
        $response['transactionType'] = $postData['transactionType'];

        return $response;
    }

    /**
     * @return ResponseInterface
     * @throws PaymentException
     */
    public function processSecure()
    {
        //Override authenticcation scope and get access token
        Config::set('payment.dna.auth.scope', 'payment integration_api');
        $this->getToken();

        $postData = $this->preparePayload();

        $apiEndPoint = config('payment.dna.base_url') . 'v2/transactions/' . $this->transactionId . '/confirmation';

        $response = $this->clientRequest->makeRequest($apiEndPoint, 'post', $postData, $this->headers);
        $statusCode = $response->getStatusCode();
        
        $response = json_decode((string) $response->getBody(), true);
        $response['response']['statusCode'] = $statusCode;

        return $response;
    }

    public function getTransaction()
    {
    }

    /**
     * @return ResponseInterface
     */
    public function createCardIdentifier(): ResponseInterface
    {
        return new ResponseInterface();
    }

    /**
     * Pass AVS and CVS parameters to payment settings
     *
     * @param   array  $paymentSettings
     * @param   string  $value
     * @return  array
     */
    protected function getAvsCvs(array $paymentSettings, string $value): array
    {
        $overrideAvsCvcCheck = $this->checkAvsCvcOverride();
        $avsCvcValue = $overrideAvsCvcCheck ? $overrideAvsCvcCheck->value : $value;
        if (! empty(config('payment.dna.avsCvv')[$avsCvcValue])) {
            $paymentSettings = array_merge($paymentSettings, config('payment.dna.avsCvv')[$avsCvcValue]);
        }

        return $paymentSettings;
    }

    /**
     * Get AVS and CVC error flag
     *
     * @param   array  $data  Response payload
     *
     * @return  bool
     */
    protected function hasAvsCvcError(array $data): bool
    {
        if (! $data['success'] && ! empty($this->payload['apply_avs_cvc_check']) && $this->payload['apply_avs_cvc_check'] === 'Force') {
            if ($data['avsHouseNumberResult'] !== 'Matched' || $data['avsPostcodeResult'] !== 'Matched' || $data['cscResult'] !== 'Matched') {
                return true;
            }
        }

        return false;
    }

    /**
     * @param $data
     * @return void
     * @throws ValidationException
     */
    protected function throwExceptionIfRequestFails($data)
    {
        if (isset($data['success']) && ! $data['success']) {
            throw ValidationException::withMessages(['message' => $data['message']]);
        }
    }

    /**
     * Set custom response for secure payment (3DS v1/v2)
     *
     * @param   array  $data
     *
     * @return  array
     */
    protected function get3DSecureResponseParameters($data)
    {
        $response = [];
        $response['is_3ds_initiated'] = true;
        $response['3d_secure']['version'] = $data['threeDS']['version'];
        $response['3d_secure']['acs_url'] = $data['threeDS']['acsUrl'];
        switch ($response['3d_secure']['version']) {
            case '2':
                $response['3d_secure']['creq'] = $data['threeDS']['creq'];
                $response['3d_secure']['threeDS_session_data'] = $data['threeDS']['threeDSSessionData'];
                break;
            
            default:
                $response['3d_secure']['pa_req'] = $data['threeDS']['pareq'];
                $response['3d_secure']['term_url'] = $data['threeDS']['termUrl'];
                $response['3d_secure']['md'] = $data['threeDS']['md'];
                break;
        }

        return $response;
    }

    /**
     * Check default setting for postcode, house number and csc values
     * @return  mixed
     */
    protected function checkAvsCscMatrixOverride()
    {
        if (empty($this->paymentsettings)) {
            $this->setPaymentSettings();
        }

        return $this->paymentsettings
            ->whereIn('key', ['dna_postcode_override', 'dna_house_number_override', 'dna_csc_override'])
            ->all();
    }
}
