<?php

namespace Modules\Payment\Gateway\Dna;

use Illuminate\Support\Facades\Log;
use Modules\Payment\Contracts\Repeat as PaymentContractInterface;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Exceptions\PaymentException;

class Repeat extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    protected $parentTransactionId;

    protected $parentTransaction;

    public function __construct()
    {
        parent::__construct();
        $this->transactionType = 'SALE';
    }

    public function setPayload(array $payload)
    {
        parent::setPayload($payload);
        // Set transaction Id of VERIFICATION entry
        $this->parentTransaction = Transaction::where('payment_information_uuid', $payload['transaction']['payment_information_uuid'])->where('transaction_type', 'VERIFICATION')->first();

        $this->parentTransactionId = $this->parentTransaction->transaction_id;

        return $this;
    }

    /**
     * @throws PaymentException
     */
    public function repeatOrder()
    {
        $response = $this->processRepeatTransaction();

        return $this->parseResponse($response);
    }

    protected function preparePayload(): array
    {
        return [
            'parentTransactionId' => $this->parentTransactionId,
            'transactionType' => $this->transactionType,
            'amount' => pence_to_pound($this->payload['amount']),
            'sequenceType' => 'recurring',
            'periodicType' => 'ucof',
            'invoiceId' => $this->payload['vendor_tx_code'],
        ];
    }

    public function parseResponse($data)
    {
        $this->throwExceptionIfRequestFails($data);

        // Set common format paramaters
        $customResponse = [];
        $customResponse['transaction_id'] = $data['id'];
        $customResponse['transaction_type'] = $data['transactionType'];
        $customResponse['success'] = $data['success'];
        $customResponse['parent_uuid'] = $this->parentTransaction->uuid ?? null;

        $data['dvb_payment_response'] = $customResponse;

        return $data;
    }
}
