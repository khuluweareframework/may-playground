<?php

namespace Modules\Payment\Gateway\Dna;

use Modules\Payment\Contracts\SecurePayment as SecurePaymentInterface;
use Modules\Payment\Exceptions\PaymentException;

class SecurePayment extends PaymentGateway implements SecurePaymentInterface
{
    protected $transactionType;

    protected $transactionId;

    public function __construct()
    {
        parent::__construct();
    }

    public function setPayload(array $payload)
    {
        parent::setPayload($payload);

        return $this;
    }

    /**
     * @throws PaymentException
     */
    public function secureOrder($transactionId)
    {
        $this->transactionId = $transactionId;

        $response = $this->processSecure();

        return $this->parseResponse($response);
    }

    protected function preparePayload(): array
    {
        return ! empty($this->payload['pa_res']) ? [ 'paRes' => $this->payload['pa_res'] ] : [ 'cres' => $this->payload['cres'] ];
    }

    public function parseResponse($data)
    {
        $customResponse = [];
        $customResponse['payment_channel'] = parent::PAYMENT_CHANNEL;
        $customResponse['status'] = $data['status'] ?? '';
        $customResponse['is_3ds_completed'] = false;
        if ($data['success'] && in_array($customResponse['status'], config('payment.dna.3dsecure.accept_tx_status'))) {
            $customResponse['is_3ds_completed'] = true;
        }
        $customResponse['status_details'] = $data['message'] ?? '';

        $customResponse['avs_cvc_error'] = $this->hasAvsCvcError($data);

        //Return customer id and payment information id
        $customResponse['customer_uuid'] = $this->payload['customer_uuid'] ?? '';
        $customResponse['payment_information_uuid'] = $this->payload['transaction'] ? $this->payload['transaction']['payment_information_uuid'] : '';
        //Return card identifier
        $customResponse['card_identifier'] = $data['cardTokenId'] ?? '';
        $customResponse['card_type'] = $data['cardSchemeName'] ?? '';

        $data['dvb_payment_response'] = $customResponse;

        return $data;
    }
}
