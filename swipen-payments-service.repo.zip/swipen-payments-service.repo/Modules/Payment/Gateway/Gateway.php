<?php

namespace Modules\Payment\Gateway;

use Modules\Payment\Entities\Settings;
use Modules\Payment\Entities\TransactionErrorLog;

class Gateway
{
    /**
     * Coolection of all required payment settings
     */
    protected $paymentsettings;

    /**
     * Get collection of required setings key
     *
     * @return mixed
     */
    protected function setPaymentSettings()
    {
        $this->paymentsettings = Settings::where('active', 1)->get();
    }

    /**
     * Check default settings for AVS and CVC from database
     *
     * @return mixed
     */
    protected function checkAvsCvcOverride()
    {
        if (empty($this->paymentsettings)) {
            $this->setPaymentSettings();
        }

        return $this->paymentsettings
            ->where('key', 'apply_avs_cvc_check')
            ->first();
    }

    /**
     * Check 3D secure version from database
     *
     * @return mixed
     */
    protected function check3dsVersion()
    {
        if (empty($this->paymentsettings)) {
            $this->setPaymentSettings();
        }

        return $this->paymentsettings
            ->where('key', '3ds_version')
            ->first();
    }

    /**
     * Get 3DS version
     *
     * @return string
     */
    protected function get3dsVersion()
    {
        $check3dsVersion = $this->check3dsVersion();

        return $check3dsVersion->value ?? (string) config('payment.3ds_version');
    }

    /**
     * Check default settings for 3ds from database
     *
     * @return mixed
     */
    protected function check3dsOverride()
    {
        if (empty($this->paymentsettings)) {
            $this->setPaymentSettings();
        }

        return $this->paymentsettings
            ->where('key', 'apply_3d_secure')
            ->first();
    }

    /**
     * Save transaction error log
     *
     * @param array $attributes
     * @return void
     */
    protected function saveTransactionErrorLog($attributes)
    {
        $attributes = array_merge($attributes, [
            'customer_uuid' => request()->get('customer_uuid'),
            'order_uuid' => request()->input('transaction')->order_uuid
                            ?? request()->get('order_uuid'),
            'account_type_uuid' => request()->input('transaction')->account_type_uuid
                            ?? request()->get('account_type_uuid'),
            'transaction_amount' => request()->get('amount'),
        ]);
        TransactionErrorLog::createWithAttributes($attributes);
    }

    /**
     * Check default settings for skip defer
     *
     * @return mixed
     */
    public function checkSkipDeferred()
    {
        if (empty($this->paymentsettings)) {
            $this->setPaymentSettings();
        }

        return $this->paymentsettings
            ->where('key', 'skip_deferred')
            ->first();
    }
}
