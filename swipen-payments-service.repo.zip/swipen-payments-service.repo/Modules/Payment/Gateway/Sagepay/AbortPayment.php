<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Contracts\AbortTransaction as AbortTransactionContract;
use Modules\Payment\Exceptions\PaymentException;

class AbortPayment extends PaymentGateway implements AbortTransactionContract
{
    protected $transactionType;

    protected $transactionId;

    public function __construct(array $payload, string $transactionId)
    {
        parent::__construct();

        $this->transactionType = 'abort';

        $this->transactionId = $transactionId;
        parent::setPayload($payload);
    }

    /**
     * @throws PaymentException
     */
    public function abortOrder()
    {
        return $this->processAbortOrder();
    }

    protected function preparePayload(): array
    {
        return [
            'instructionType' => $this->transactionType,
        ];
    }
}
