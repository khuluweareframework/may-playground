<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Contracts\Deferred as PaymentContractInterface;
use Modules\Payment\Entities\AccountType;
use Modules\Payment\Exceptions\PaymentException;

class Deferred extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    public function __construct()
    {
        parent::__construct();

        $this->transactionType = 'Deferred';
    }

    public function setPayload(array $payload)
    {
        parent::setPayload($payload);

        // Do custom logic
        if (empty($payload['card_details']['card_identifier'])) {
            $this->createCardIdentifier();
        }

        return $this;
    }

    /**
     * @throws PaymentException
     */
    public function deferredOrder()
    {
        $response = $this->processOrder();

        return $this->parseResponse($response);
    }

    protected function preparePayload(): array
    {
        //Set AVS and 3DS values from database if enabled
        $this->setAvsCscOverride();
        // Forcing to apply sagepay settings rule
        if ($this->payload['apply_avs_cvc_check'] === 'Force' && $this->checkSkipDeferred()) {
            $this->payload['apply_avs_cvc_check'] = 'UseMSPSetting';
        }

        if ($this->payload['apply_avs_cvc_check'] === 'Force' || $this->payload['apply_avs_cvc_check'] === 'UseMSPSetting') {
            $this->setAvsCscMatrixOverride();
            $this->setLinkCardIdentifier();
        }
        $this->set3dsOverride();

        if (isset($this->payload['card_details']['card_identifier']) && ! empty($this->payload['card_details']['card_identifier'])) {
            $card['cardIdentifier'] = $this->payload['card_details']['card_identifier'];
            $card['reusable'] = true;
        } else {
            $card['merchantSessionKey'] = $this->merchantSessionKeyObject['merchantSessionKey'];
            $card['cardIdentifier'] = $this->cardIdentifierObject['cardIdentifier'];
            $card['save'] = true;
        }

        $payload = [
            'transactionType' => $this->transactionType,
            'paymentMethod' => [
                'card' => $card,
            ],
            'vendorTxCode' => $this->payload['vendor_tx_code'],
            'amount' => $this->payload['amount'],
            'currency' => $this->payload['currency'],
            'description' => $this->payload['description'],
            'apply3DSecure' => $this->payload['apply_3d_secure'],
            'applyAvsCvcCheck' => $this->payload['apply_avs_cvc_check'],
            'customerFirstName' => $this->payload['customer_first_name'],
            'customerLastName' => $this->payload['customer_last_name'],
            'customerEmail' => $this->payload['customer_email'] ?? '',
            'entryMethod' => $this->getEntryMethod(),
            'billingAddress' => [
                'address1' => $this->payload['billing_address']['address1'],
                'city' => $this->payload['billing_address']['city'],
                'postalCode' => $this->payload['billing_address']['postal_code'],
                'country' => $this->payload['billing_address']['country'],
            ],
        ];

        if ($this->get3dsVersion() === '2') {
            //add new parameter strongCustomerAuthentication and credentialType
            $payload['strongCustomerAuthentication'] = $this->getStrongCustomerAuthentication();
            $payload['credentialType'] = $this->getCredentialTypeData();

            if (request()->get('customer_uuid')) {
                $payload['strongCustomerAuthentication']['acctID'] = request()->get('customer_uuid');
            }

            if (! empty($this->payload['custom_user_settings']['browser_ip'])) {
                $payload['strongCustomerAuthentication']['browserIP'] = $this->payload['custom_user_settings']['browser_ip'];
            }

            if (! empty($this->payload['custom_user_settings']['website'])) {
                $this->payload['custom_user_settings']['website'] = $website = str_replace('_dividebuy_co_uk', '', $this->payload['custom_user_settings']['website']);
                $payload['strongCustomerAuthentication']['website'] = $website;

                $notificationUrl = substr($website, -1) == '/'
                                   ? $this->payload['custom_user_settings']['website'] . config('payment.3ds_notification_url_path')
                                   : $this->payload['custom_user_settings']['website'] . '/' . config('payment.3ds_notification_url_path');
                $payload['strongCustomerAuthentication']['notificationURL'] = $notificationUrl;
            }
        }

        return $payload;
    }

    private function getEntryMethod(): string
    {
        if (! empty($this->payload['account_type_uuid'])) {
            return AccountType::uuid($this->payload['account_type_uuid'])->entry_method;
        }

        return 'Ecommerce';
    }

    public function parseResponse($data)
    {
        // Set common format paramaters
        $customResponse = [];
        $customResponse['payment_channel'] = parent::PAYMENT_CHANNEL;
        $customResponse['card_identifier'] = data_get($data, 'paymentMethod.card.cardIdentifier');
        $customResponse['card_type'] = data_get($data, 'paymentMethod.card.cardType');
        $customResponse['amount'] = data_get($data, 'amount.totalAmount') ?? $this->payload['amount'];
        $customResponse['transaction_id'] = $data['transactionId'];
        $customResponse['transaction_type'] = $data['transactionType'] ?? $this->transactionType;
        $customResponse['status'] = $data['status'];
        $customResponse['success'] = in_array($data['status'], ['Ok', '3DAuth'])? true : false;
        $customResponse['status_details'] = $data['statusDetail'];
        // Set specific key based on transactionType
        $customResponse['can_abort'] = true;
        $customResponse['is_3ds_initiated'] = false;
        $customResponse['skip_deferred'] = false;

        $customResponse['avs_cvc_error'] = $this->hasAvsCvcError($data);

        //Check for 3DS payment, override transaction_type and return required parameters
        if (isset($data['paReq']) || isset($data['cReq'])) {
            $customResponse['transaction_type'] = 'Deferred-3dSecure';
            $customResponse = array_merge($customResponse, $this->get3DSecureResponseParameters($data));
        }

        $data['dvb_payment_response'] = $customResponse;

        if (! $customResponse['success'] || $customResponse['avs_cvc_error']) {
            $customResponse['transaction_response'] = $data;
            $customResponse['error_description'] = $customResponse['status_details'];
            $this->saveTransactionErrorLog($customResponse);
        }

        return $data;
    }
}
