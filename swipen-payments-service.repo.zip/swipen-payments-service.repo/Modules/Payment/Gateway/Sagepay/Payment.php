<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Contracts\Payment as PaymentContractInterface;
use Modules\Payment\Entities\AccountType;
use Modules\Payment\Exceptions\PaymentException;

class Payment extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    public function __construct()
    {
        parent::__construct();
    }

    public function setPayload(array $payload)
    {
        parent::setPayload($payload);

        // Do custom logic
        $this->transactionType = (isset($payload['transactionType']) && $payload['transactionType'] != '') ?$payload['transactionType'] : 'Payment';

        if (empty($payload['card_details']['card_identifier'])) {
            $this->createCardIdentifier();
        }

        return $this;
    }

    /**
     * @throws PaymentException
     */
    public function paymentOrder()
    {
        $response = $this->processOrder();

        return $this->parseResponse($response);
    }

    protected function preparePayload(): array
    {
        //Set AVS and 3DS values from database if enabled
        $this->setAvsCscOverride();
        // Forcing to apply sagepay settings rule
        if ($this->payload['apply_avs_cvc_check'] === 'Force' && $this->checkSkipDeferred()) {
            $this->payload['apply_avs_cvc_check'] = 'UseMSPSetting';
        }

        if ($this->payload['apply_avs_cvc_check'] === 'Force' || $this->payload['apply_avs_cvc_check'] === 'UseMSPSetting') {
            $this->setAvsCscMatrixOverride();
            $this->setLinkCardIdentifier();
        }
        $this->set3dsOverride();

        $payload = [
            'transactionType' => $this->transactionType,
            'paymentMethod' => [
                'card' => [
                    'cardIdentifier' => $this->cardIdentifierObject['cardIdentifier'] ?? $this->payload['card_details']['card_identifier'],
                ],
            ],
            'vendorTxCode' => $this->payload['vendor_tx_code'],
            'amount' => $this->payload['amount'],
            'currency' => $this->payload['currency'],
            'description' => $this->payload['description'],
            'apply3DSecure' => $this->payload['apply_3d_secure'],
            'applyAvsCvcCheck' => $this->payload['apply_avs_cvc_check'],
            'customerFirstName' => $this->payload['customer_first_name'],
            'customerLastName' => $this->payload['customer_last_name'],
            'customerEmail' => $this->payload['customer_email'] ?? '',
            'customerPhone' => $this->payload['customer_phone'] ?? '',
            'entryMethod' => $this->getEntryMethod(),
            'billingAddress' => [
                'address1' => $this->payload['billing_address']['address1'],
                'city' => $this->payload['billing_address']['city'],
                'postalCode' => $this->payload['billing_address']['postal_code'],
                'country' => $this->payload['billing_address']['country'],
            ],
        ];

        if ($this->get3dsVersion() === '2') {
            //add new parameter strongCustomerAuthentication and credentialType
            $payload['strongCustomerAuthentication'] = $this->getStrongCustomerAuthentication();
            $payload['credentialType'] = $this->getCredentialTypeData();

            if (request()->get('customer_uuid')) {
                $payload['strongCustomerAuthentication']['acctID'] = request()->get('customer_uuid');
            }

            if (! empty($this->payload['custom_user_settings']['browser_ip'])) {
                $payload['strongCustomerAuthentication']['browserIP'] = $this->payload['custom_user_settings']['browser_ip'];
            }

            if (! empty($this->payload['custom_user_settings']['website'])) {
                $this->payload['custom_user_settings']['website'] = $website = str_replace('_dividebuy_co_uk', '', $this->payload['custom_user_settings']['website']);
                $payload['strongCustomerAuthentication']['website'] = $website;

                $notificationUrl = substr($website, -1) == '/'
                                   ? $this->payload['custom_user_settings']['website'] . config('payment.3ds_notification_url_path')
                                   : $this->payload['custom_user_settings']['website'] . '/' . config('payment.3ds_notification_url_path');
                $payload['strongCustomerAuthentication']['notificationURL'] = $notificationUrl;
            }

            // Overwrite notification url if supplied
            if (! empty($this->payload['custom_user_settings']['notification_url'])) {
                $payload['strongCustomerAuthentication']['notificationURL'] = $this->payload['custom_user_settings']['notification_url'] ;
            }
        }

        if (empty($this->payload['card_details']['card_identifier'])) {
            $payload['paymentMethod']['card']['merchantSessionKey'] = $this->merchantSessionKeyObject['merchantSessionKey'];
            $payload['paymentMethod']['card']['save'] = true;
            if (isset($payload['credentialType'])) {
                $payload['credentialType']['cofUsage'] = 'First';
            }
        } else {
            $payload['paymentMethod']['card']['reusable'] = true;
            if ($this->isRepeatFromCron()) {
                $payload['credentialType']['initiatedType'] = 'MIT';
                $payload['entryMethod'] = 'TelephoneOrder';
            }
        }
        \Log::info('preparePayload', $payload);

        return $payload;
    }

    private function getEntryMethod(): string
    {
        if (! empty($this->payload['account_type_uuid'])) {
            return AccountType::uuid($this->payload['account_type_uuid'])->entry_method;
        }

        return $this->payload['entry_method'] ?? 'Ecommerce';
    }

    private function isRepeatFromCron()
    {
        if (! empty($this->payload['account_type_uuid']) && $this->payload['account_type_uuid'] === AccountType::REPEAT) {
            return true;
        }

        return false;
    }

    public function parseResponse($data)
    {
        // Set common format paramaters
        $customResponse = [];
        $customResponse['payment_channel'] = parent::PAYMENT_CHANNEL;
        $customResponse['card_identifier'] = data_get($data, 'paymentMethod.card.cardIdentifier');
        $customResponse['card_type'] = data_get($data, 'paymentMethod.card.cardType');
        $customResponse['transaction_id'] = $data['transactionId'];
        $customResponse['transaction_type'] = $data['transactionType'] ?? $this->transactionType;
        $customResponse['status'] = $data['status'];
        $customResponse['success'] = in_array($data['status'], ['Ok', '3DAuth'])? true : false;
        $customResponse['status_details'] = $data['statusDetail'];
        $customResponse['is_3ds_initiated'] = false;

        $customResponse['avs_cvc_error'] = $this->hasAvsCvcError($data);

        //Check for 3DS payment, override transaction_type and return required parameters
        if (isset($data['paReq']) || isset($data['cReq'])) {
            $customResponse['transaction_type'] = 'Payment-3dSecure';
            $customResponse = array_merge($customResponse, $this->get3DSecureResponseParameters($data));
        }

        //Return customer id and payment information id
        $customResponse['customer_uuid'] = $this->payload['customer_uuid'] ?? '';
        $customResponse['payment_information_uuid'] = $this->payload['payment_information_uuid'] ?? '';
        //Return skip_deferred flag
        $customResponse['skip_deferred'] = $this->checkSkipDeferred() ? true : false;

        $data['dvb_payment_response'] = $customResponse;
        // if error then save to transaction logs
        if (! $customResponse['success'] || $customResponse['avs_cvc_error']) {
            $customResponse['transaction_response'] = $data;
            $customResponse['error_description'] = $customResponse['avs_cvc_error']
                                                    ? $customResponse['status_details'] . ' But AVS check failed.'
                                                    : $customResponse['status_details'];
            $this->saveTransactionErrorLog($customResponse);
        }

        return $data;
    }
}
