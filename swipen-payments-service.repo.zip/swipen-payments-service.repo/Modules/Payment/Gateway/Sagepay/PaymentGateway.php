<?php

namespace Modules\Payment\Gateway\Sagepay;

use GuzzleHttp\Client;
use GuzzleHttp\RequestOptions;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Modules\Payment\Contracts\PaymentGateway as ContractsPaymentGateway;
use Modules\Payment\Entities\AccountType;
use Modules\Payment\Exceptions\BlockCardException;
use Modules\Payment\Exceptions\PaymentException;
use Modules\Payment\Gateway\Gateway;
use Modules\Payment\Http\Requests\ClientRequestHandler;
use Psr\Http\Message\ResponseInterface;
use SettingServiceClient;

class PaymentGateway extends Gateway implements ContractsPaymentGateway
{
    protected $merchantSessionKeyObject;

    protected $cardIdentifierObject;

    protected $clientRequest;

    protected $transactionType;

    protected $payload;

    const PAYMENT_CHANNEL = 'sagepay';

    public function __construct()
    {
        $this->clientRequest = resolve(ClientRequestHandler::class);
    }

    public function setPayload(array $payload)
    {
        $this->payload = $payload;

        if (! empty($this->transactionType)) {
            request()->merge([
                'txType' => ucwords($this->transactionType),
            ]);
        }

        return $this;
    }

    /**
     * Generate Merchant Session Key.
     *
     * @return ResponseInterface
     */
    public function getToken(): ResponseInterface
    {
        $apiEndPoint = config('payment.base_url') . 'merchant-session-keys';

        $response = $this->clientRequest->makeRequest($apiEndPoint, 'post');

        $this->merchantSessionKeyObject = json_decode((string) $response->getBody(), true);

        return $response;
    }

    /**
     * @return mixed
     * @throws BlockCardException
     * @throws PaymentException
     */
    public function createCardIdentifier()
    {
        $cardNumber = $this->payload['card_details']['card_number'];
        $unauthorisedCard = SettingServiceClient::getSettings([], [
            'key' => 'blocked_card_bin',
            'search' => substr($cardNumber, 0, 6),
            'is_enabled' => 1,
        ])->getData();
        if (count($unauthorisedCard['data']) !== 0) {
            throw new BlockCardException('Card is not allowed', []);
        }

        $apiEndPoint = config('payment.base_url') . 'card-identifiers';

        $this->getToken();

        $client = new Client([
            RequestOptions::HEADERS => [
                'Authorization' => 'Bearer ' . $this->merchantSessionKeyObject['merchantSessionKey'],
            ],
        ]);

        $response = $this->clientRequest->processRequest($apiEndPoint, 'post', $client, $this->prepareCardPayload());

        $this->cardIdentifierObject = json_decode((string) $response->getBody(), true);

        //Parse custom response for card identifier api
        if (request()->route() && request()->route()->getName() === 'payments.card-identifier') {
            return $this->processCardIdentifierResponse($response);
        }

        return $response;
    }

    /**
     * @throws BlockCardException
     * @throws PaymentException
     */
    public function validateResponse(): void
    {
        $this->createCardIdentifier();
    }

    /**
     * @return mixed
     * @throws PaymentException
     */
    public function getTransaction()
    {
        $apiEndPoint = config('payment.base_url') . 'transactions/' . $this->transactionId;

        $response = $this->clientRequest->makeRequest($apiEndPoint, 'get');

        return json_decode((string) $response->getBody(), true);
    }

    /**
     * @return mixed
     * @throws PaymentException
     */
    public function processOrder()
    {
        $postData = $this->preparePayload();

        if (! empty($postData['billingAddress']) && ! empty($this->payload['billing_address'] && ! empty($this->payload['billing_address']['address2']))) {
            $postData['billingAddress']['address2'] = $this->payload['billing_address']['address2'];
        }

        Log::info('processOrderPayload', ['postdata' => $postData]);

        $apiEndPoint = config('payment.base_url') . 'transactions';

        $response = $this->clientRequest->makeRequest($apiEndPoint, 'post', $postData);
        $statusCode = $response->getStatusCode();

        $response = json_decode((string) $response->getBody(), true);
        $response['response']['statusCode'] = $statusCode;

        if (! empty($response['avsCvcCheck']) && ! empty($postData['applyAvsCvcCheck'])) {
            $response['avsCvcCheck']['apply'] = $postData['applyAvsCvcCheck'];
        }

        return $response;
    }

    /**
     * @return ResponseInterface
     * @throws PaymentException
     */
    public function processAbortOrder()
    {
        $postData = $this->preparePayload();

        $apiEndPoint = config('payment.base_url') . 'transactions/' . $this->transactionId . '/instructions';

        return $this->clientRequest->makeRequest($apiEndPoint, 'post', $postData);
    }

    /**
     * @return ResponseInterface
     * @throws PaymentException
     */
    public function processVoidOrder()
    {
        $postData = $this->preparePayload();

        $apiEndPoint = config('payment.base_url') . 'transactions/' . $this->transactionId . '/instructions';

        return $this->clientRequest->makeRequest($apiEndPoint, 'post', $postData);
    }

    /**
     * @return ResponseInterface
     * @throws PaymentException
     */
    public function processReleaseOrder()
    {
        $postData = $this->preparePayload();

        $apiEndPoint = config('payment.base_url') . 'transactions/' . $this->transactionId . '/instructions';

        return $this->clientRequest->makeRequest($apiEndPoint, 'post', $postData);
    }

    /**
     * @return ResponseInterface
     * @throws PaymentException
     */
    public function processSecure()
    {
        $postData = $this->preparePayload();

        
        $apiEndPoint = ! empty($postData['paRes'])
                        ? config('payment.base_url') . sprintf(config('payment.secure_endpoint'), $this->transactionId)
                        : config('payment.base_url') . sprintf(config('payment.secure_endpoint_v2'), $this->transactionId);

        $response = $this->clientRequest->makeRequest($apiEndPoint, 'post', $postData);
        $statusCode = $response->getStatusCode();
        
        $response = json_decode((string) $response->getBody(), true);
        $response['response']['statusCode'] = $statusCode;

        return $response;
    }

    /**
     * @return array
     */
    protected function prepareCardPayload()
    {
        return [
            'cardDetails' => [
                'cardholderName' => $this->payload['card_details']['cardholder_name'],
                'cardNumber' => $this->payload['card_details']['card_number'],
                'expiryDate' => $this->payload['card_details']['expiry_date'],
                'securityCode' => $this->payload['card_details']['security_code'],
            ],
        ];
    }

    /**
     * Get AVS and CVC error flag
     *
     * @param   array  $data  Response payload
     *
     * @return  bool
     */
    protected function hasAvsCvcError(array $data): bool
    {
        if (! empty($data['avsCvcCheck']) && $data['avsCvcCheck']['status'] === 'NotChecked') {
            return false;
        }

        if (! empty($data['statusCode']) && $data['statusCode'] == config('payment.sagepay.avs_error_code')) {
            return true;
        }

        if (! empty($data['avsCvcCheck']) && $data['avsCvcCheck']['status'] !== 'AllMatched' && $data['avsCvcCheck']['address'] !== 'NotChecked') {
            return true;
        }

        return false;
    }

    /**
     * Set custom response for secure payment (3DS v1)
     *
     * @param   array  $data
     *
     * @return  array
     */
    protected function get3DSecureResponseParameters($data)
    {
        $response = [];
        $response['is_3ds_initiated'] = true;
        $response['3d_secure']['version'] = isset($data['paReq']) ? '1' : '2';
        $response['3d_secure']['acs_url'] = $data['acsUrl'];

        switch ($response['3d_secure']['version']) {
            case '2':
                $response['3d_secure']['creq'] = $data['cReq'];
                $response['3d_secure']['threeDS_session_data'] = base64_encode($data['transactionId']);
                break;
            
            default:
                $response['3d_secure']['pa_req'] = $data['paReq'];
                $response['3d_secure']['md'] = $data['transactionId'];
                break;
        }

        return $response;
    }

    /**
     * get strong customer authetication for secure payment (3DS v2)
     *
     * @param   array  $data
     *
     * @return  array
     */
    protected function getStrongCustomerAuthentication()
    {
        return [
            'notificationURL' => config('payment.3ds_notification_url'),
            'browserIP' => request()->ip(),
            'browserAcceptHeader' => 'application/json',
            'browserJavascriptEnabled' => false,
            'browserJavaEnabled' => false,
            'browserLanguage' => 'en-GB',
            'browserColorDepth' => '16',
            'browserScreenHeight' => '768',
            'browserScreenWidth' => '1200',
            'browserTZ' => '-60',
            'browserUserAgent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:67.0) Gecko/20100101 Firefox/67.0',
            'challengeWindowSize' => 'Medium',
            'transType' => 'GoodsAndServicePurchase',
            'website' => request()->getSchemeAndHttpHost(),
        ];
    }

    /**
     * Function to return credentialType data.
     *
     * @param string $transactionType
     *
     * @return array
     */
    protected function getCredentialTypeData()
    {
        $credentialType = config('payment.sagepay.3dsecure.credential_type.payment');

        if ($this->transactionType == 'Deferred') {
            $credentialType['cofUsage'] = 'First';
        }
        if ($this->transactionType == 'Repeat') {
            $credentialType = [
                'cofUsage' => 'Subsequent',
                'initiatedType' => 'MIT',
                'mitType' => 'Unscheduled',
            ];
        }

        return $credentialType;
    }

    public function processCardIdentifierResponse($data)
    {
        $response = json_decode((string) $data->getBody(), true);
        $response['transaction_response']['dvb_payment_response'] = [
            'payment_channel' => self::PAYMENT_CHANNEL,
            'success' => true,
            'card_identifier' => $response['cardIdentifier'] ?? '',
            'card_type' => $response['cardType'] ?? '',
            'merchant_session_key' => $this->merchantSessionKeyObject['merchantSessionKey'] ?? '',
            //convert expiry to the UTC time
            'merchant_session_expiry' => Carbon::parse($this->merchantSessionKeyObject['expiry'])
                                        ->setTimezone(config('app.timezone'))->format('Y-m-d H:i:s') ?? '',
            'skip_deferred' => $this->checkSkipDeferred() ? true : false,
         ];

        return $response;
    }

    /**
     * Function to link card identifier to cvv for AVS check.
     *
     * @param string $transactionType
     *
     * @return array
     */
    protected function linkCardIdentifier($cardidentifier, $cvv)
    {
        $apiEndPoint = config('payment.base_url') . 'card-identifiers' . '/' . $cardidentifier . '/security-code';

        if (empty($this->merchantSessionKeyObject['merchantSessionKey'])) {
            $this->getToken();
        }
        
        $postData = [
            'securityCode' => $cvv,
        ];

        $client = new Client([
            RequestOptions::HEADERS => [
                'Authorization' => 'Bearer ' . $this->merchantSessionKeyObject['merchantSessionKey'],
            ],
        ]);

        $response = $this->clientRequest->processRequest($apiEndPoint, 'post', $client, $postData);
        $statusCode = $response->getStatusCode();

        return $statusCode == '204' ? true : false;
    }

    protected function setAvsCscMatrixOverride()
    {
        //Override AVS/CSC parameters if enabled
        if (empty($this->paymentsettings)) {
            $this->setPaymentSettings();
        }
        $avsCscOveriride = $this->paymentsettings->whereIn('key', ['sagepay_postcode_override', 'sagepay_house_number_override', 'sagepay_csc_override'])->all();
        foreach ($avsCscOveriride as $aco) {
            if ($aco['key'] === 'sagepay_postcode_override' && ! empty($this->payload['billing_address']['postal_code'])) {
                $this->payload['billing_address']['postal_code'] = $aco['value'];
            } elseif ($aco['key'] === 'sagepay_house_number_override' && ! empty($this->payload['billing_address']['address1'])) {
                $this->payload['billing_address']['address1'] = $aco['value'];
            } elseif ($aco['key'] === 'sagepay_csc_override' && ! empty($this->payload['card_details']['security_code'])) {
                $this->payload['card_details']['security_code'] = $aco['value'];
            }
        }
    }

    protected function set3dsOverride()
    {
        //Check if 3ds override from database or not
        $check3dsOverride = $this->check3dsOverride();
        if ($check3dsOverride) {
            $this->payload['apply_3d_secure'] = $check3dsOverride->value;
        }
    }

    protected function setAvsCscOverride()
    {
        $overrideAvsCvcCheck = $this->checkAvsCvcOverride();
        if ($overrideAvsCvcCheck) {
            $this->payload['apply_avs_cvc_check'] = $overrideAvsCvcCheck->value;
        } elseif ($this->checkSkipDeferred() && ! empty($this->payload['card_details']['card_number'])) {
            $this->payload['apply_avs_cvc_check'] = 'Force';
        }
    }

    protected function setLinkCardIdentifier()
    {
        //Link the card if avs enable and card identifier/cvv passed
        if (! empty($this->payload['card_details']['security_code']) && ! empty($this->payload['card_details']['card_identifier'])) {
            $statusCode = $this->linkCardIdentifier($this->payload['card_details']['card_identifier'], $this->payload['card_details']['security_code']);
            Log::info('Link card identifier with status code:' . $statusCode);
        }
    }
}
