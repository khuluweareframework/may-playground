<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Contracts\Refund as PaymentContractInterface;
use Modules\Payment\Exceptions\PaymentException;

class Refund extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    protected $transactionId;

    public function __construct(array $payload, string $transactionId)
    {
        parent::__construct();
        parent::setPayload($payload);

        $this->transactionType = 'Refund';

        $this->transactionId = $transactionId;
    }

    /**
     * @throws PaymentException
     */
    public function refundOrder()
    {
        return $this->processOrder();
    }

    protected function preparePayload(): array
    {
        return [
            'transactionType' => $this->transactionType,
            'referenceTransactionId' => $this->transactionId,
            'vendorTxCode' => $this->payload['vendor_tx_code'],
            'amount' => $this->payload['amount'],
            'description' => $this->payload['description'],
        ];
    }
}
