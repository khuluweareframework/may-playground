<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Contracts\Release as PaymentContractInterface;
use Modules\Payment\Exceptions\PaymentException;

class Release extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    protected $transactionId;

    public function __construct(array $payload, string $transactionId)
    {
        parent::__construct();
        parent::setPayload($payload);

        $this->transactionType = 'release';

        $this->transactionId = $transactionId;
    }

    /**
     * @throws PaymentException
     */
    public function releaseOrder()
    {
        return $this->processReleaseOrder();
    }

    protected function preparePayload(): array
    {
        return [
            'instructionType' => $this->transactionType,
            'amount' => $this->payload['amount'],
        ];
    }
}
