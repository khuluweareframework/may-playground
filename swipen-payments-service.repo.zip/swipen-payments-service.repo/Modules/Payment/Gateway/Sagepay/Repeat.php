<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Contracts\Repeat as PaymentContractInterface;
use Modules\Payment\Exceptions\PaymentException;

class Repeat extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    protected $transactionId;

    public function __construct()
    {
        parent::__construct();

        $this->transactionType = 'Repeat';
    }

    public function setPayload(array $payload)
    {
        parent::setPayload($payload);
        // Set transaction Id
        $this->transactionId = $payload['transaction']['transaction_id'];

        return $this;
    }

    /**
     * @throws PaymentException
     */
    public function repeatOrder()
    {
        $response = $this->processOrder();

        return $this->parseResponse($response);
    }

    protected function preparePayload(): array
    {
        return [
            'transactionType' => $this->transactionType,
            'referenceTransactionId' => $this->transactionId,
            'vendorTxCode' => $this->payload['vendor_tx_code'],
            'amount' => $this->payload['amount'],
            'currency' => $this->payload['currency'],
            'description' => $this->payload['description'],
            'shippingDetails' => [
                'recipientFirstName' => $this->payload['shipping_address']['recipient_first_name'],
                'recipientLastName' => $this->payload['shipping_address']['recipient_last_name'],
                'shippingAddress1' => $this->payload['shipping_address']['address1'],
                'shippingCity' => $this->payload['shipping_address']['city'],
                'shippingPostalCode' => $this->payload['shipping_address']['postal_code'],
                'shippingCountry' => $this->payload['shipping_address']['country'],
            ],
            'credentialType' => $this->getCredentialTypeData(),
        ];
    }

    public function parseResponse($data)
    {
        // Set common format paramaters
        $customResponse = [];
        $customResponse['transaction_id'] = $data['transactionId'];
        $customResponse['transaction_type'] = $data['transactionType'] ?? $this->transactionType;
        $customResponse['status'] = $data['status'];
        $customResponse['success'] = in_array($data['status'], ['Ok', '3DAuth'])? true : false;
        $customResponse['status_details'] = $data['statusDetail'] ?? '';

        $data['dvb_payment_response'] = $customResponse;

        // if error then save to transaction logs
        if (! $customResponse['success']) {
            $customResponse['error_description'] = $customResponse['status_details'];
            $this->saveTransactionErrorLog($customResponse);
        }

        return $data;
    }
}
