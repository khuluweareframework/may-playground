<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Contracts\SecurePayment as SecurePaymentInterface;
use Modules\Payment\Exceptions\PaymentException;

class SecurePayment extends PaymentGateway implements SecurePaymentInterface
{
    protected $transactionType;

    protected $transactionId;

    public function __construct()
    {
        parent::__construct();
        if (! empty($this->payload['transaction'])) {
            $this->transactionType = $this->payload['transaction']['transaction_type'] === 'Deferred-3dSecure'
            ? 'Deferred-Complete'
            : 'Payment-Complete';
        }
    }

    public function setPayload(array $payload)
    {
        parent::setPayload($payload);

        return $this;
    }

    /**
     * @throws PaymentException
     */
    public function secureOrder($transactionId)
    {
        $this->transactionId = $transactionId;

        $response = $this->processSecure();

        return $this->parseResponse($response);
    }

    protected function preparePayload(): array
    {
        return ! empty($this->payload['pa_res']) ? [ 'paRes' => $this->payload['pa_res'] ] : [ 'cRes' => $this->payload['cres'] ];
    }

    public function parseResponse($data)
    {
        $customResponse = [];
        $customResponse['payment_channel'] = parent::PAYMENT_CHANNEL;
        $customResponse['is_3ds_completed'] = false;
        if (! empty($data['status'])
            && in_array($data['status'], config('payment.sagepay.3dsecure.accept_tx_status'))) {
            $customResponse['is_3ds_completed'] = true;
        }

        $customResponse['status'] = $data['status'] ?? '';
        $customResponse['status_details'] = $data['statusDetail'] ?? '';
        // Flag will be used for abort defer transactions
        $customResponse['can_abort'] = true;
        $customResponse['avs_cvc_error'] = $this->hasAvsCvcError($data);

        //Return customer id and payment information id
        $customResponse['customer_uuid'] = $this->payload['customer_uuid'] ?? '';
        $customResponse['payment_information_uuid'] = $this->payload['transaction'] ? $this->payload['transaction']['payment_information_uuid'] : '';
        //Return card identifier
        $customResponse['card_identifier'] = $data['paymentMethod']['card']['cardIdentifier'] ?? '';
        $customResponse['card_type'] = $data['paymentMethod']['card']['cardType'] ?? '';
        $customResponse['transaction_id'] = $data['transactionId'] ?? '';
        //Return skip_deferred flag
        $customResponse['skip_deferred'] = $this->checkSkipDeferred() ? true : false;

       
        $data['dvb_payment_response'] = $customResponse;
        // if error then save to transaction logs
        if (! $customResponse['is_3ds_completed'] || $customResponse['avs_cvc_error']) {
            $customResponse['transaction_type'] = $this->payload['transaction']['transaction_type'] === 'Deferred-3dSecure' ? 'Deferred-Complete' : 'Payment-Complete';
            $customResponse['transaction_response'] = $data;
            $customResponse['error_description'] = $customResponse['avs_cvc_error']
                                                    ? $customResponse['status_details'] . ' But AVS check failed.'
                                                    : $customResponse['status_details'];
            $this->saveTransactionErrorLog($customResponse);
        }

        return $data;
    }
}
