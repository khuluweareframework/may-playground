<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Events\TransactionReadSingle;
use Modules\Payment\Exceptions\PaymentException;

class Transaction extends PaymentGateway
{
    protected $transactionId;

    protected $id;

    public function __construct(array $payload, string $transactionId, int $id)
    {
        parent::__construct();
        parent::setPayload($payload);

        $this->transactionId = $transactionId;
        $this->id = $id;
    }

    /**
     * @throws PaymentException
     *
     * @return array
     */
    public function retrieveTransaction()
    {
        event(new TransactionReadSingle($this->id));

        return $this->getTransaction();
    }
}
