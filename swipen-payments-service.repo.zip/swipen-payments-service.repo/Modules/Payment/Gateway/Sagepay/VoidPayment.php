<?php

namespace Modules\Payment\Gateway\Sagepay;

use Modules\Payment\Contracts\VoidTransaction as PaymentContractInterface;
use Modules\Payment\Exceptions\PaymentException;

class VoidPayment extends PaymentGateway implements PaymentContractInterface
{
    protected $transactionType;

    protected $transactionId;

    public function __construct(array $payload, string $transactionId)
    {
        parent::__construct();

        $this->transactionType = 'void';

        $this->transactionId = $transactionId;
        parent::setPayload($payload);
    }

    /**
     * @throws PaymentException
     */
    public function voidOrder()
    {
        return $this->processVoidOrder();
    }

    protected function preparePayload(): array
    {
        return [
            'instructionType' => $this->transactionType,
        ];
    }
}
