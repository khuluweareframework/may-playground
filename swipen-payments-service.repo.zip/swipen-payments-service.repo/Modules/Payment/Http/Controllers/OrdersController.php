<?php

namespace Modules\Payment\Http\Controllers;

use Illuminate\Routing\Controller;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Gateway\Sagepay\VoidPayment;
use Modules\Payment\Http\Requests\VoidOrderTransactionsRequest;
use Modules\Payment\Transformers\TransactionCollection;

class OrdersController extends Controller
{
    protected $transaction;

    public function __construct(Transaction $transaction)
    {
        $this->transaction = $transaction;
    }

    /**
     * @param VoidOrderTransactionsRequest $request
     * @param Transaction $transaction
     *
     * @return TransactionCollection
     */
    public function voidTransactions(VoidOrderTransactionsRequest $request, Transaction $transaction)
    {
        $orderTransactions = $transaction->retrieveList([
            'filters' => [
                'order_uuid' => $request->order_uuid,
                'type' => [
                    'Payment',
                    'Repeat',
                    'Payment-Complete',
                ],
                'created_at' => now(),
            ],
            'per_page' => '-1',
        ]);

        $orderTransactions = $orderTransactions->filter(function ($transaction) {
            // Filter voided transactions.
            if ($transaction->is_voided) {
                return false;
            }
            // Filter refunded transactions.
            if ($transaction->is_refunded) {
                return false;
            }

            // Filter 3D secure not authenticated transactions.
            if (($transaction->transaction_type === 'Payment-Complete') && ! $transaction->is_authenticated) {
                return false;
            }

            return true;
        });

        $voidTransactions = [];
        foreach ($orderTransactions as $orderTransaction) {
            $isSuccess = $orderTransaction->transaction_response['dvb_payment_response']['success'] ?? false;
            if (! $isSuccess) {
                continue;
            }
            //no payload is required to void a payment, we only need the transaction id
            $payment = (new VoidPayment([], $orderTransaction->transaction_id))->voidOrder();
            $response = json_decode((string) $payment->getBody(), true);

            $voidTransaction = [];
            $voidTransaction['customer_uuid'] = $orderTransaction->customer_uuid;
            $voidTransaction['parent_uuid'] = $orderTransaction->uuid;
            $voidTransaction['order_uuid'] = $orderTransaction->order_uuid;
            $voidTransaction['transaction_id'] = $orderTransaction->transaction_id;
            $voidTransaction['transaction_type'] = isset($response['instructionType']) ? ucfirst($response['instructionType']) : 'Void';
            $voidTransaction['transaction_response'] = $response;

            $voidTransactions[] = $voidTransaction;
        }

        $voidedTransactions = [];
        if (! empty($voidTransactions)) {
            $voidedTransactions = $transaction->voidAllWithAttributes($voidTransactions);
        }

        return (new TransactionCollection($voidedTransactions))
            ->response()
            ->setStatusCode(200);
    }
}
