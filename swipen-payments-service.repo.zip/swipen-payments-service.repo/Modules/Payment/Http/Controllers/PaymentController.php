<?php

namespace Modules\Payment\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Arr;
use Illuminate\Validation\ValidationException;
use Modules\Payment\Contracts\Deferred;
use Modules\Payment\Contracts\Payment;
use Modules\Payment\Contracts\Repeat;
use Modules\Payment\Contracts\SecurePayment;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Entities\TransactionErrorLog;
use Modules\Payment\Events\CardIdentifierCreated;
use Modules\Payment\Exceptions\BlockCardException;
use Modules\Payment\Exceptions\PaymentException;
use Modules\Payment\Gateway\Gateway;
use Modules\Payment\Gateway\Sagepay\AbortPayment;
use Modules\Payment\Gateway\Sagepay\PaymentGateway;
use Modules\Payment\Gateway\Sagepay\Refund;
use Modules\Payment\Gateway\Sagepay\Release;
use Modules\Payment\Gateway\Sagepay\Transaction as SagepayTransaction;
use Modules\Payment\Gateway\Sagepay\VoidPayment;
use Modules\Payment\Http\Requests\AbortFormatRequest;
use Modules\Payment\Http\Requests\CardFormatRequest;
use Modules\Payment\Http\Requests\PaymentFormatRequest;
use Modules\Payment\Http\Requests\RefundFormatRequest;
use Modules\Payment\Http\Requests\ReleaseFormatRequest;
use Modules\Payment\Http\Requests\RepeatFormatRequest;
use Modules\Payment\Http\Requests\SecureFormatRequest;
use Modules\Payment\Http\Requests\VoidFormatRequest;
use Modules\Payment\Transformers\Sagepay as SagepayResource;
use Modules\Payment\Transformers\Transaction as TransactionResource;

class PaymentController extends Controller
{
    protected $transaction;

    public function __construct(Transaction $transaction)
    {
        $this->transaction = $transaction;
    }

    /**
     * @param Request $request
     * @param Transaction $transaction
     *
     * @return JsonResponse
     * @throws PaymentException
     */
    public function retrieveTransaction(Request $request, Transaction $transaction)
    {
        $sagepayTransaction = (new SagepayTransaction(
            $request->all(),
            $request->route('transaction')->transaction_id,
            $request->route('transaction')->id
        ))->retrieveTransaction();

        $transaction->sagepay_transaction = $sagepayTransaction;

        return new TransactionResource($transaction);
    }

    /**
     * @param PaymentFormatRequest $request
     *
     * @return JsonResponse
     */
    public function payment(PaymentFormatRequest $request)
    {
        $response = resolve(Payment::class, ['payment_channel' => request()->card_details['payment_channel'] ?? null])->setPayload($request->all())->paymentOrder();

        $customResponse = $response['dvb_payment_response'];

        $attributes = [];
        $attributes['customer_uuid'] = $request->input('customer_uuid');
        $attributes['order_uuid'] = $request->input('order_uuid');
        $attributes['vendor_tx_code'] = $request->input('vendor_tx_code');
        $attributes['transaction_id'] = $customResponse['transaction_id'] ?? null;
        $attributes['transaction_type'] = $customResponse['transaction_type'];
        $attributes['transaction_amount'] = $request->input('amount');
        $attributes['transaction_response'] = $response;
        $attributes['payment_information_uuid'] = $request->input('payment_information_uuid');
        $attributes['account_type_uuid'] = $request->input('account_type_uuid');
        $attributes['is_successful'] = ($customResponse['avs_cvc_error'] || ! $customResponse['success']) ? false : true;
        $transaction = Transaction::createWithAttributes($attributes);

        return (new TransactionResource($transaction))
            ->response()
            ->setStatusCode($response['response']['statusCode']);
    }

    /**
     * @param SecureFormatRequest $request
     *
     * @return JsonResponse
     * @throws PaymentException
     */
    public function finaliseSecurePayment(SecureFormatRequest $request)
    {
        $response = resolve(SecurePayment::class)->setPayload($request->all())->secureOrder($request->input('transaction')->transaction_id);
        $customResponse = $response['dvb_payment_response'];
        $attributes = [];
        $attributes['customer_uuid'] = $request->input('customer_uuid');
        $attributes['parent_uuid'] = $request->input('transaction')->uuid;
        $attributes['transaction_id'] = $request->input('transaction')->transaction_id;
        $attributes['payment_information_uuid'] = $request->input('transaction')->payment_information_uuid;
        $attributes['account_type_uuid'] = $request->input('transaction')->account_type_uuid;
        $attributes['order_uuid'] = $request->input('transaction')->order_uuid;
        $attributes['vendor_tx_code'] = $request->input('transaction')->vendor_tx_code;
        $attributes['transaction_type'] = $request->input('transaction')->transaction_type === 'Deferred-3dSecure' ? 'Deferred-Complete' : 'Payment-Complete';
        $attributes['transaction_amount'] = $request->input('transaction')->transaction_amount;
        $attributes['transaction_response'] = $response;
        $attributes['is_successful'] = ($customResponse['avs_cvc_error'] || ! $customResponse['is_3ds_completed']) ? 0 : 1;
        $transaction = Transaction::createWithAttributes($attributes, true);

        return (new TransactionResource($transaction))
            ->response()
            ->setStatusCode($response['response']['statusCode']);
    }

    /**
     * @param RepeatFormatRequest $request
     *
     * @return JsonResponse
     * @throws PaymentException
     */
    public function repeat(RepeatFormatRequest $request)
    {
        $response = resolve(Repeat::class, ['payment_channel' => $request->input('payment_channel') ?? null])->setPayload($request->all())->repeatOrder();
        $customResponse = $response['dvb_payment_response'];

        $attributes = [];
        $attributes['customer_uuid'] = $request->customer_uuid;
        $attributes['parent_uuid'] = $customResponse['parent_uuid'] ?? $request->input('transaction')->uuid;
        $attributes['order_uuid'] = $request->input('order_uuid') ?? $request->input('transaction')->order_uuid;
        $attributes['vendor_tx_code'] = $request->input('vendor_tx_code');
        $attributes['transaction_id'] = $customResponse['transaction_id'] ?? $request->input('transaction')->transaction_id;
        $attributes['transaction_type'] = $customResponse['transaction_type'] ?? null;
        $attributes['transaction_amount'] = $request->input('amount');
        $attributes['transaction_response'] = $response;
        $attributes['payment_information_uuid'] = $request->input('transaction')->payment_information_uuid;
        $attributes['account_type_uuid'] = $request->input('account_type_uuid');
        $attributes['is_successful'] = $customResponse['success'];
        
        $transaction = Transaction::repeatWithAttributes($attributes);

        return (new TransactionResource($transaction))
            ->response()
            ->setStatusCode($response['response']['statusCode']);
    }

    /**
     * @param RefundFormatRequest $request
     *
     * @return JsonResponse
     * @throws PaymentException
     */
    public function refund(RefundFormatRequest $request)
    {
        $response = (new Refund(
            $request->all(),
            $request->input('transaction')->transaction_id
        ))->refundOrder();

        $attributes = [];
        $attributes['customer_uuid'] = $request->customer_uuid;
        $attributes['parent_uuid'] = $request->input('transaction')->uuid;
        $attributes['order_uuid'] = $request->input('transaction')->order_uuid;
        $attributes['vendor_tx_code'] = $request->input('vendor_tx_code');
        $attributes['transaction_id'] = $response['transactionId'] ?? $request->input('transaction')->transaction_id;
        $attributes['transaction_type'] = $response['transactionType'] ?? null;
        $attributes['transaction_amount'] = $request->input('amount');
        $attributes['transaction_response'] = $response;
        $attributes['is_successful'] = $response['status'] == 'Ok' ? true : false;

        $transaction = Transaction::refundWithAttributes($attributes);

        return (new TransactionResource($transaction))
            ->response()
            ->setStatusCode($response['response']['statusCode']);
    }

    /**
     * @param AbortFormatRequest $request
     *
     * @return JsonResponse
     * @throws PaymentException
     */
    public function abort(AbortFormatRequest $request)
    {
        $payment = (new AbortPayment(
            $request->validated(),
            $request->input('transaction')->transaction_id
        ))->abortOrder();

        $response = json_decode((string) $payment->getBody(), true);

        $attributes = [];
        $attributes['customer_uuid'] = $request->input('customer_uuid');
        $attributes['parent_uuid'] = $request->input('transaction')->uuid;
        $attributes['order_uuid'] = $request->input('transaction')->order_uuid;
        $attributes['transaction_id'] = $request->input('transaction')->transaction_id;
        $attributes['transaction_type'] = isset($response['instructionType']) ? ucfirst($response['instructionType']) : 'Abort';
        $attributes['transaction_response'] = $response;
        $attributes['is_successful'] = isset($response['instructionType']) && isset($response['date']) ? true : false;

        $transaction = Transaction::abortWithAttributes($attributes);

        return (new TransactionResource($transaction))
            ->response()
            ->setStatusCode($payment->getStatusCode());
    }

    /**
     * @param VoidFormatRequest $request
     *
     * @return JsonResponse
     * @throws PaymentException
     */
    public function void(VoidFormatRequest $request)
    {
        $payment = (new VoidPayment(
            $request->all(),
            $request->input('transaction')->transaction_id
        )
        )->voidOrder();

        $response = json_decode((string) $payment->getBody(), true);

        $attributes = [];
        $attributes['customer_uuid'] = $request->input('customer_uuid');
        $attributes['parent_uuid'] = $request->input('transaction')->uuid;
        $attributes['order_uuid'] = $request->input('transaction')->order_uuid;
        $attributes['transaction_id'] = $request->input('transaction')->transaction_id;
        $attributes['transaction_amount'] = $request->input('transaction')->transaction_amount;
        $attributes['transaction_type'] = isset($response['instructionType']) ? ucfirst($response['instructionType']) : 'Void';
        $attributes['transaction_response'] = $response;
        $attributes['is_successful'] = isset($response['instructionType']) && isset($response['date']) ? true : false;

        $transaction = Transaction::voidWithAttributes($attributes);

        return (new TransactionResource($transaction))
            ->response()
            ->setStatusCode($payment->getStatusCode());
    }

    /**
     * @param ReleaseFormatRequest $request
     *
     * @return JsonResponse
     * @throws PaymentException
     */
    public function release(ReleaseFormatRequest $request)
    {
        $payment = (new Release(
            $request->all(),
            $request->input('transaction')->transaction_id
        ))->releaseOrder();

        $response = json_decode((string) $payment->getBody(), true);

        $attributes = [];
        $attributes['customer_uuid'] = $request->input('customer_uuid');
        $attributes['parent_uuid'] = $request->input('transaction')->uuid;
        $attributes['order_uuid'] = $request->input('transaction')->order_uuid;
        $attributes['transaction_id'] = $request->input('transaction')->transaction_id;
        $attributes['transaction_type'] = isset($response['instructionType']) ? ucfirst($response['instructionType']) : 'Release';
        $attributes['transaction_amount'] = $request->input('amount');
        $attributes['transaction_response'] = $response;
        $attributes['is_successful'] = isset($response['instructionType']) && isset($response['date']) ? true : false;

        $transaction = Transaction::releaseWithAttributes($attributes);

        return (new TransactionResource($transaction))
            ->response()
            ->setStatusCode($payment->getStatusCode());
    }

    /**
     * @param PaymentFormatRequest $request
     *
     * @return JsonResponse
     */
    public function defer(PaymentFormatRequest $request)
    {
        try {
            if ($request->order_uuid) {
                //return card_identifier for skip defer
                $skipDeferred = (new Gateway)->checkSkipDeferred();
                $customUserSettings = $request->has('custom_user_settings')
                                    ? $request->get('custom_user_settings')
                                    : [];
                if ($skipDeferred && empty($customUserSettings['is_force_deferred'])) {
                    $request->route()->action['as'] = '';
                    $request->route()->name('payments.card-identifier');

                    return $this->cardAuthorization($request);
                }
            }

            $response = resolve(Deferred::class, ['payment_channel' => request()->card_details['payment_channel'] ?? null])->setPayload($request->all())->deferredOrder();
            $customResponse = $response['dvb_payment_response'];
            $attributes = [];
            $attributes['customer_uuid'] = $request->customer_uuid;
            $attributes['order_uuid'] = $request->input('order_uuid');
            $attributes['vendor_tx_code'] = $request->input('vendor_tx_code');
            $attributes['transaction_id'] = $customResponse['transaction_id'] ?? null;
            $attributes['transaction_type'] = $customResponse['transaction_type'];
            $attributes['transaction_amount'] = $customResponse['amount'];
            $attributes['transaction_response'] = $response;
            $attributes['payment_information_uuid'] = ($customResponse['avs_cvc_error'] || ! $customResponse['success'])
                                                    ? null
                                                    : $request->input('payment_information_uuid');
            $attributes['account_type_uuid'] = $request->input('account_type_uuid');
            $attributes['is_successful'] = ($customResponse['avs_cvc_error'] || ! $customResponse['success']) ? 0 : 1;
            $transaction = Transaction::deferWithAttributes($attributes);

            return (new TransactionResource($transaction))
                ->response()
                ->setStatusCode($response['response']['statusCode']);
        } catch (BlockCardException $e) {
            report($e);
            $statusCode = Response::HTTP_UNPROCESSABLE_ENTITY;

            return response()->json(
                [
                    'message' => $e->getMessage(),
                    'status_code' => $statusCode,

                ],
                $statusCode
            );
        }
    }

    /**
     * @param Request $request
     *
     * @return JsonResponse
     */
    public function sessionToken(Request $request)
    {
        $token = (new PaymentGateway())->setPayload($request->all())->getToken();

        $response = json_decode((string) $token->getBody(), true);

        return (new SagepayResource($response))
            ->additional(['links' => [
                'self' => route('payments.session-token'),
            ]])
            ->response()
            ->setStatusCode(201);
    }

    /**
     * @param CardFormatRequest $request
     *
     * @return JsonResponse
     * @throws BlockCardException
     * @throws PaymentException
     */
    public function cardAuthorization(CardFormatRequest $request)
    {
        try {
            $response = (new PaymentGateway())->setPayload($request->all())->createCardIdentifier();
            event(new CardIdentifierCreated);

            return (new TransactionResource($response))
                ->response()
                ->setStatusCode(Response::HTTP_CREATED);
        } catch (ValidationException | PaymentException $e) {
            report($e);

            return response()->json(
                [
                    'message' => 'The given data was invalid.',
                    'errors' => $e->getMessage(),
                    'status_code' => Response::HTTP_UNPROCESSABLE_ENTITY,

                ],
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
