<?php

namespace Modules\Payment\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Modules\Payment\Entities\Transaction;

class AbortFormatRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'customer_uuid' => ['required', 'uuid'],
            'transaction_uuid' => ['required', 'uuid', 'exists:transactions,uuid'],
        ];
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     */
    protected function prepareForValidation()
    {
        if ($this->transaction_uuid) {
            $this->merge([
                'transaction' => Transaction::uuid($this->transaction_uuid),
            ]);
        }
    }
}
