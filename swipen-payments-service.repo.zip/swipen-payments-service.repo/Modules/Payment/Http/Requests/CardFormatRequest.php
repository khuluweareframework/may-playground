<?php

namespace Modules\Payment\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Payment\Rules\ValidateExpDate;

class CardFormatRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if (! isset(request()->card_details['cardholder_name'])) {
            return [
                'card_details.card_identifier' => ['required'],
                'card_details.payment_channel' => [
                    'nullable',
                    Rule::in(config('payment.payment_channels')),
                ],
            ];
        }

        return [
            'card_details.cardholder_name' => ['required', 'max:45'],
            'card_details.card_number' => ['required', 'max:16'],
            'card_details.expiry_date' => ['required', 'size:4', new ValidateExpDate()],
            'card_details.security_code' => ['required', 'size:3'],
        ];
    }
}
