<?php

namespace Modules\Payment\Http\Requests;

use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ServerException;
use GuzzleHttp\RequestOptions;
use Illuminate\Http\Response;
use Modules\Payment\Exceptions\PaymentException;
use Psr\Http\Message\ResponseInterface;

class ClientRequestHandler
{
    /**
     * @param string $apiEndPoint
     * @param string $method
     * @param array $data
     * @param array $headers
     *
     * @return ResponseInterface
     * @throws PaymentException
     */
    public function makeRequest(string $apiEndPoint, string $method = 'post', array $data = [], $headers = [])
    {
        $postData = array_merge([
            'vendorName' => config('payment.vendor_name'),
        ], $data);


        $client = new Client([
            RequestOptions::HEADERS => array_merge([
                'Authorization' => 'Basic ' . config('payment.key'),
            ], $headers),
        ]);

        return $this->processRequest($apiEndPoint, $method, $client, $postData);
    }

    /**
     * @param string $apiEndPoint
     * @param string $method
     * @param Client $client
     * @param array $postData
     * @param string $type
     * @return ResponseInterface
     * @throws PaymentException
     */
    public function processRequest(string $apiEndPoint, string $method, Client $client, array $postData, $type = 'json')
    {
        try {
            return $client->{$method}($apiEndPoint, [$type => $postData]);
        } catch (ClientException | ServerException $exception) {
            report($exception);

            throw new PaymentException($exception->getResponse()->getReasonPhrase(), $exception->getResponse()->getStatusCode(), $exception->getResponse());
        } catch (Exception $exception) {
            report($exception);

            $statusCode = array_key_exists($exception->getCode(), Response::$statusTexts)
                ? $exception->getCode()
                : Response::HTTP_INTERNAL_SERVER_ERROR;

            throw new PaymentException($exception->getMessage(), $statusCode, $exception->getResponse());
        }
    }
}
