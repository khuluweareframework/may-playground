<?php

namespace Modules\Payment\Http\Requests;

use Illuminate\Validation\Rule;

class PaymentFormatRequest extends CardFormatRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return array_merge([
            'customer_uuid' => ['required', 'uuid'],
            'order_uuid' => ['uuid', 'nullable'],
            'payment_information_uuid'  => ['uuid', 'nullable'],
            'account_type_uuid'  => ['uuid', 'nullable', 'exists:account_types,uuid'],
            'vendor_tx_code' => ['required', 'max:40'],
            'amount' => ['required', 'numeric'],
            'currency' => ['required'],
            'description' => ['required','max:100'],
            'customer_first_name' => ['required','max:20'],
            'customer_last_name' => ['required','max:20'],
            'customer_email' => ['nullable','max:80'],
            'customer_phone' => ['nullable','max:19'],
            'entry_method' => ['nullable'],
            'billing_address.address1' => ['required'],
            'billing_address.city' => ['required','max:40'],
            'billing_address.postal_code' => ['required'],
            'billing_address.country' => ['required'],
            'apply_3d_secure' => [
                'required',
                Rule::in(['UseMSPSetting', 'Force', 'Disable', 'ForceIgnoringRules']),
            ],
            'apply_avs_cvc_check' => [
                'required',
                Rule::in(['UseMSPSetting', 'Force', 'Disable', 'ForceIgnoringRules']),
            ],
        ], parent::rules());
    }

    public function prepareForValidation()
    {
        if (! empty($this['billing_address']['address1']) && strlen($this['billing_address']['address1']) > 50) {
            $address1 = $this['billing_address']['address1'];
            $address2 = '';
            while (strlen($address1) > 50) {
                $address1 = explode(',', $address1);
                $address2 = $address1[count($address1) - 1] . ',' . $address2;
                array_pop($address1);
                $address1 = implode(',', $address1);
            }
            $data = $this->toArray();
            data_set($data, 'billing_address.address1', $address1);
            data_set($data, 'billing_address.address2', trim(rtrim($address2, ',')));
            $this->merge($data);
        }
    }
}
