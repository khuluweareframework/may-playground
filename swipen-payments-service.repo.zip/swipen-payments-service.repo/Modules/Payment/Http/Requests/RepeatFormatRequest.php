<?php

namespace Modules\Payment\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Modules\Payment\Entities\Transaction;

class RepeatFormatRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'customer_uuid' => ['required', 'uuid'],
            'order_uuid' => ['uuid', 'nullable'],
            'reference_transaction_uuid' => ['required', 'uuid', 'exists:transactions,uuid'],
            'payment_channel' => [
                'nullable',
                Rule::in(config('payment.payment_channels')),
            ],
            'account_type_uuid'  => ['uuid', 'nullable', 'exists:account_types,uuid'],
            'vendor_tx_code' => ['required', 'max:40'],
            'amount' => ['required', 'numeric'],
            'currency' => ['required'],
            'description' => ['required'],
            'shipping_address.recipient_first_name' => ['required'],
            'shipping_address.recipient_last_name' => ['required'],
            'shipping_address.address1' => ['required'],
            'shipping_address.city' => ['required'],
            'shipping_address.postal_code' => ['required'],
            'shipping_address.country' => ['required'],
        ];
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     */
    protected function prepareForValidation()
    {
        if ($this->reference_transaction_uuid) {
            $this->merge([
                'transaction' => Transaction::uuid($this->reference_transaction_uuid),
            ]);
        }
    }
}
