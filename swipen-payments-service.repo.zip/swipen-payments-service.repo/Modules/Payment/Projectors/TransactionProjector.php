<?php

namespace Modules\Payment\Projectors;

use Modules\Payment\Entities\Transaction;
use Modules\Payment\Entities\TransactionErrorLog;
use Modules\Payment\Events\AbortTransactionCreated;
use Modules\Payment\Events\BulkVoidTransactionsCreated;
use Modules\Payment\Events\DeferTransactionCreated;
use Modules\Payment\Events\PaymentTransactionCreated;
use Modules\Payment\Events\PaymentTransactionFinalised;
use Modules\Payment\Events\RefundTransactionCreated;
use Modules\Payment\Events\ReleaseTransactionCreated;
use Modules\Payment\Events\RepeatTransactionCreated;
use Modules\Payment\Events\TransactionErrorLogCreated;
use Modules\Payment\Events\VoidTransactionCreated;
use Spatie\EventSourcing\Projectors\Projector;
use Spatie\EventSourcing\Projectors\ProjectsEvents;

final class TransactionProjector implements Projector
{
    use ProjectsEvents;

    /**
     * @param DeferTransactionCreated $event
     */
    public function onDeferTransactionCreated(DeferTransactionCreated $event): void
    {
        Transaction::create($event->transactionAttributes);
    }

    /**
     * @param PaymentTransactionCreated $event
     */
    public function onPaymentTransactionCreated(PaymentTransactionCreated $event): void
    {
        Transaction::create($event->transactionAttributes);
    }

    /**
     * @param PaymentTransactionFinalised $event
     */
    public function onPaymentTransactionFinalised(PaymentTransactionFinalised $event): void
    {
        Transaction::create($event->transactionAttributes);
    }

    /**
     * @param RefundTransactionCreated $event
     */
    public function onRefundTransactionCreated(RefundTransactionCreated $event): void
    {
        Transaction::create($event->transactionAttributes);
    }

    /**
     * @param ReleaseTransactionCreated $event
     */
    public function onReleaseTransactionCreated(ReleaseTransactionCreated $event): void
    {
        Transaction::create($event->transactionAttributes);
    }

    /**
     * @param RepeatTransactionCreated $event
     */
    public function onRepeatTransactionCreated(RepeatTransactionCreated $event): void
    {
        Transaction::create($event->transactionAttributes);
    }

    /**
     * @param VoidTransactionCreated $event
     */
    public function onVoidTransactionCreated(VoidTransactionCreated $event): void
    {
        Transaction::create($event->transactionAttributes);
    }

    public function onAbortTransactionCreated(AbortTransactionCreated $event): void
    {
        Transaction::create($event->transactionAttributes);
    }

    /**
     * @param BulkVoidTransactionsCreated $event
     */
    public function onBulkVoidTransactionCreated(BulkVoidTransactionsCreated $event): void
    {
        foreach ($event->voidTransactions as $voidTransaction) {
            Transaction::create($voidTransaction);
        }
    }

    /**
     * @param TransactionErrorLogCreated $event
     */
    public function onTransactionErrorLogCreated(TransactionErrorLogCreated $event): void
    {
        TransactionErrorLog::create($event->attributes);
    }
}
