<?php

namespace Modules\Payment\Providers;

use Illuminate\Database\Eloquent\Factory;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\ServiceProvider;
use Modules\Payment\Contracts\Deferred;
use Modules\Payment\Contracts\Payment;
use Modules\Payment\Contracts\Repeat;
use Modules\Payment\Contracts\SecurePayment;

class PaymentServiceProvider extends ServiceProvider
{
    /**
     * Boot the application events.
     */
    public function boot(): void
    {
        $this->registerTranslations();
        $this->registerConfig();
        $this->registerViews();
        $this->registerFactories();
        $this->loadMigrationsFrom(module_path('Payment', 'Database/Migrations'));
    }

    /**
     * Register the service provider.
     */
    public function register(): void
    {
        $this->app->register(RouteServiceProvider::class);

        // Payment Interface binding
        $this->app->bind(Payment::class, function ($app, $parameters) {
            if (isset($parameters['payment_channel'])) {
                Config::set('payment.payment_channel', $parameters['payment_channel']);
            }
            $paymentClass = "\Modules\Payment\Gateway\\" . ucfirst(config('payment.payment_channel')) . "\Payment";

            return $app->make($paymentClass);
        });

        // Deffered Interface binding
        $this->app->bind(Deferred::class, function ($app, $parameters) {
            if (isset($parameters['payment_channel'])) {
                Config::set('payment.payment_channel', $parameters['payment_channel']);
            }
            $deferredClass = "\Modules\Payment\Gateway\\" . ucfirst(config('payment.payment_channel')) . "\Deferred";

            return $app->make($deferredClass);
        });

        // Repeat Interface binding
        $this->app->bind(Repeat::class, function ($app, $parameters) {
            if (isset($parameters['payment_channel'])) {
                Config::set('payment.payment_channel', $parameters['payment_channel']);
            }
            $paymentClass = "\Modules\Payment\Gateway\\" . ucfirst(config('payment.payment_channel')) . "\Repeat";

            return $app->make($paymentClass);
        });

        // SecurePayment Interface binding
        $this->app->bind(SecurePayment::class, function ($app) {
            $paymentClass = "\Modules\Payment\Gateway\\" . ucfirst(config('payment.payment_channel')) . "\SecurePayment";

            return $app->make($paymentClass);
        });
    }

    /**
     * Register views.
     */
    public function registerViews(): void
    {
        $viewPath = resource_path('views/modules/payment');

        $sourcePath = module_path('Payment', 'Resources/views');

        $this->publishes([
            $sourcePath => $viewPath,
        ], 'views');

        $this->loadViewsFrom(array_merge(array_map(function ($path) {
            return $path . '/modules/payment';
        }, Config::get('view.paths')), [$sourcePath]), 'payment');
    }

    /**
     * Register translations.
     */
    public function registerTranslations(): void
    {
        $langPath = resource_path('lang/modules/payment');

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, 'payment');
        } else {
            $this->loadTranslationsFrom(module_path('Payment', 'Resources/lang'), 'payment');
        }
    }

    /**
     * Register an additional directory of factories.
     */
    public function registerFactories(): void
    {
        if (! app()->environment('production') && $this->app->runningInConsole()) {
            app(Factory::class)->load(module_path('Payment', 'Database/factories'));
        }
    }

    /**
     * Register config.
     */
    protected function registerConfig(): void
    {
        $this->publishes([
            module_path('Payment', 'Config/config.php') => config_path('payment.php'),
        ], 'config');
        $this->mergeConfigFrom(
            module_path('Payment', 'Config/config.php'),
            'payment'
        );
    }
}
