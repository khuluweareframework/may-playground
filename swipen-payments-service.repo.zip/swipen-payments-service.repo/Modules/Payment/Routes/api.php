<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('payments')->group(function (): void {
    Route::post('/abort', 'PaymentController@abort')->name('payments.abort');
    Route::post('/pay', 'PaymentController@payment')->name('payments.pay');
    Route::post('/repeat', 'PaymentController@repeat')->name('payments.repeat');
    Route::post('/refund', 'PaymentController@refund')->name('payments.refund');
    Route::post('/defer', 'PaymentController@defer')->name('payments.defer');
    Route::post('/void', 'PaymentController@void')->name('payments.void');
    Route::post('/release', 'PaymentController@release')->name('payments.release');
    Route::post('/secure-payment', 'PaymentController@finaliseSecurePayment')->name('payments.secure-payment');
    Route::post('/card-identifier', 'PaymentController@cardAuthorization')->name('payments.card-identifier');
    Route::post('/session-token', 'PaymentController@sessionToken')->name('payments.session-token');
});

Route::get('/transactions', 'TransactionController@index')->name('transactions.index');
Route::get('/transactions/{transaction}', 'PaymentController@retrieveTransaction')->name('transactions.show');

Route::post('/orders/{orderUuid}/void-transactions', 'OrdersController@voidTransactions')->name('orders.void-transactions');
