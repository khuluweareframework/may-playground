<?php

namespace Modules\Payment\Rules;

use Illuminate\Contracts\Validation\Rule;

class ValidateExpDate implements Rule
{
    /**
     * Determine if the validation rule passes.
     *
     * @param string $attribute
     *
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $expires = (int) substr($value, 2, 2) . substr($value, 0, 2);
        $now = (int) date('ym');

        return $expires >= $now;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'The :attribute must be in the future.';
    }
}
