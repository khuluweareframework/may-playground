<?php

if (! function_exists('pence_to_pound')) {
    /**
     * Covert amount from pence to pound.
     *
     * @param  int    $amount
     * @return string
     */
    function pence_to_pound($amount)
    {
        return (float) number_format((($amount) / 100), 2, '.', '');
    }
}
