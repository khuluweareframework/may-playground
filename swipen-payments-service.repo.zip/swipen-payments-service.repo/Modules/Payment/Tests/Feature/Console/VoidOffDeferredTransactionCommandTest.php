<?php

namespace Modules\Payment\Tests\Feature\Console;

use Exception;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Artisan;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Http\Requests\ClientRequestHandler;
use Modules\Payment\Tests\Unit\PaymentPayload;
use Tests\TestCase;

class VoidOffDeferredTransactionCommandTest extends TestCase
{
    use RefreshDatabase, WithFaker, PaymentPayload;

    public function testCron()
    {
        $transaction = factory(Transaction::class)->create([
            'transaction_type' => 'Deferred',
            'transaction_amount' => 1,
        ]);

        $this->mock(ClientRequestHandler::class, function ($mock) use ($transaction) {
            $mock
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions/' . $transaction->transaction_id . '/instructions',
                    'post',
                    [
                        'instructionType' => 'abort',
                    ]
                )
                ->andReturn(new Response(201, [], '{"instructionType":"void","date":"2021-04-19T16:55"}'));
        });
        
        Artisan::call('cron:void-off-deferred-transactions');

        $this->assertDatabaseHas('transactions', [
            'transaction_type'       => 'Abort',
        ]);
    }

    public function testCronWithException()
    {
        $transaction = factory(Transaction::class)->create([
            'transaction_type' => 'Deferred',
            'transaction_amount' => 1,
        ]);

        $this->mock(ClientRequestHandler::class, function ($mock) use ($transaction) {
            $mock
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions/' . $transaction->transaction_id . '/instructions',
                    'post',
                    [
                        'instructionType' => 'abort',
                    ]
                )
                ->andThrows(new Exception('Invalid transaction'));
        });
        
        Artisan::call('cron:void-off-deferred-transactions');
    }
}
