<?php

namespace Modules\Payment\Tests\Feature;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class OrdersControllerTest extends TestCase
{
    use RefreshDatabase, WithFaker, PaymentPayload;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function testOrderVoidTransactions(): void
    {
        $this->mockGetSettings();
        // Payment with another order_uuid to ensure only 1 is voided
        $payload = $this->payloadPaymentForTelePhoneOrder();
        $payload['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();
        $this->postJson(
            route('orders.void-transactions', $result['data']['order_uuid'])
        )
            ->assertOk()
            ->assertJsonCount(1, 'data')
            ->assertJsonStructure([
                'data' => [[
                    'id',
                    'uuid',
                    'customer_uuid',
                    'order_uuid',
                    'parent_uuid',
                    'transaction_id',
                    'transaction_type',
                    'transaction_amount',
                    'transaction_response' => [
                        'date',
                        'instructionType',
                    ],
                    'created_at',
                    'updated_at',
                    'card_last_four_digits',
                    'card_expiry_date',
                    'is_voided',
                    'is_refunded',
                    'is_successful',
                    'refunded_amount',
                ]],
            ]);
    }

    public function testOrderVoidedTransactions(): void
    {
        $this->mockGetSettings();
        $transaction1 = factory(Transaction::class)->create(['transaction_type' => 'Payment', 'created_at' => now()]);
        $transaction2 = factory(Transaction::class)->create([
            'parent_uuid' => $transaction1->uuid,
            'transaction_type' => 'Void',
            'created_at' => now(),
        ]);
        $transaction3 = factory(Transaction::class)->create(['transaction_type' => 'Payment', 'created_at' => now()]);
        $response = $this->postJson(
            route('orders.void-transactions', $transaction1['order_uuid'])
        );
        // Sagepay throwing either a 403 or 404 :(
        $this->assertFalse($response->isClientError());
    }

    public function testOrderVoidRefundTransactions(): void
    {
        $this->mockGetSettings();
        $transaction1 = factory(Transaction::class)->create(['transaction_type' => 'Payment', 'created_at' => now()]);
        $transaction2 = factory(Transaction::class)->create([
            'parent_uuid' => $transaction1->uuid,
            'transaction_type' => 'Refund',
            'transaction_amount' => 500,
            'created_at' => now(),
        ]);
        $transaction3 = factory(Transaction::class)->create(['transaction_type' => 'Payment', 'created_at' => now()]);
        $response = $this->postJson(
            route('orders.void-transactions', $transaction1['order_uuid'])
        );

        // Sagepay throwing either a 403 or 404 :(
        $this->assertFalse($response->isClientError());
    }

    public function testOrderTransactionsPaymentComplete(): void
    {
        $this->mockGetSettings();
        $transaction1 = factory(Transaction::class)->create(['transaction_type' => 'Payment', 'created_at' => now()]);
        $transaction2 = factory(Transaction::class)->create([
            'parent_uuid' => $transaction1->uuid,
            'transaction_type' => 'Payment-Complete',
            'transaction_response' => ['status' => 'NotAuthenticated'],
            'created_at' => now(),
        ]);
        $transaction3 = factory(Transaction::class)->create(['transaction_type' => 'Payment', 'created_at' => now()]);
        $response = $this->postJson(
            route('orders.void-transactions', $transaction2['order_uuid'])
        );
        // Sagepay throwing either a 403 or 404 :(
        $this->assertFalse($response->isClientError());
    }

    public function testOrderInvalidUuid()
    {
        $this->postJson(
            route('orders.void-transactions', 'this-does-not-exist')
        )->assertNotFound();
    }

    public function testOrderNotExists()
    {
        $this->postJson(
            route('orders.void-transactions', $this->faker->uuid)
        )->assertNotFound();
    }

    public function testDoesNotVoidOldTransactions()
    {
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/pay', $this->payloadPaymentForTelePhoneOrder());

        $json = $response->json();

        DB::table('transactions')->where('uuid', $json['data']['uuid'])->update(['created_at' => now()->subDay()]);

        $response = $this->postJson(route('orders.void-transactions', $json['data']['order_uuid']));

        $response
            ->assertOk()
            ->assertJsonCount(0, 'data');
    }

    public function testOrderVoidWithRejectedTransaction(): void
    {
        $this->mockGetSettings();
        // Payment with another order_uuid to ensure only 1 is voided
        $payload = $this->payloadPaymentForTelePhoneOrder();
        $payload['apply_avs_cvc_check'] = 'UseMSPSetting';
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();
        $this->postJson(
            route('orders.void-transactions', $result['data']['order_uuid'])
        )
        ->assertOk()
        ->assertJsonCount(0, 'data')
        ->assertJsonStructure([
            'data' => [],
        ]);
    }

    public function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
