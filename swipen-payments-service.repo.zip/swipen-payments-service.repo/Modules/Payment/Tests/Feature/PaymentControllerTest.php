<?php

namespace Modules\Payment\Tests\Feature;

use App\User;
use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Http\Response as HttpResponse;
use Illuminate\Support\Facades\Config;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Tests\Unit\DnaPaymentMockers;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class PaymentControllerTest extends TestCase
{
    use RefreshDatabase, WithFaker, PaymentPayload, DnaPaymentMockers;

    /**
     * Invoice ID
     *
     * @var string
     */
    protected $invoiceId;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function testCardAuthorization(): void
    {
        $this->withoutMiddleware();
        $data = $this->payloadPayment();
        $this->mockGetSettings();

        $this->postJson('/api/payments/card-identifier', $data)
            ->assertStatus(201)
            ->assertJsonStructure([
                'data' => [
                    'cardIdentifier',
                    'expiry',
                    'cardType',
                    'transaction_response' => [
                        'dvb_payment_response' => [
                            'payment_channel',
                            'success',
                            'card_identifier',
                            'card_type',
                        ],
                    ],
                ],
                'links' => [
                    'self',
                ],
            ]);
    }

    public function testExpireCardAuthorization(): void
    {
        $data = $this->cardDetails();
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/card-identifier', $data)
        ->assertStatus(HttpResponse::HTTP_UNPROCESSABLE_ENTITY);
    }

    public function cardDetails()
    {
        $data = ['card_details' => [
            'card_number' => '5168575105105100',
            'expiry_date' => '1222',
            'cardholder_name' => 'John Doe',
            'security_code' => '123',
        ]];

        return $data;
    }

    private function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }

    private function mockGetSettingsWithData()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[{
            "id": 117,
            "uuid": "238b358b-5c2f-4c02-958f-12a3db0ec292",
            "key": "blocked_card_bin",
            "value": "555898",
            "is_enabled": 1,
            "created_at": "-000001-11-30T00:00:00.000000Z",
            "updated_at": "2021-09-10T10:20:37.000000Z"
        }]}', true), new Response));
    }

    public function testDefer(): void
    {
        $this->withoutMiddleware();
        $this->mockGetSettings();
        $data = $this->payloadDeferForTelePhoneOrder();
        $data['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/defer', $data);
        $result = $response->decodeResponseJson();
  
        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('is_successful', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertArrayHasKey('transactionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);
        $this->assertEquals('Deferred', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals('The Authorisation was Successful.', $result['data']['transaction_response']['statusDetail']);
        $this->assertEquals($data['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($data['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertEquals($data['amount'], $result['data']['transaction_amount']);
        $this->assertEquals($result['data']['is_successful'], true);
    }

    public function testDeferWithCardIdentifireData(): void
    {
        $this->withoutMiddleware();
        $this->mockGetSettings();
        $data = $this->payloadPaymentByCardIdentifier();
        $response = $this->postJson('/api/payments/defer', $data);
        $result = $response->decodeResponseJson();
        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
    }

    public function testDeferInvalidData(): void
    {
        $this->withoutMiddleware();
        $this->mockGetSettings();
        $payload = array_replace_recursive(
            $this->payloadDefer(),
            ['card_details' => ['security_code' => '12x']]
        );

        $response = $this->postJson('/api/payments/defer', $payload);

        $result = $response->decodeResponseJson();
        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('card_details.security_code', $result['errors']);
        $this->assertContains('The security code must contain only digits', $result['errors']['card_details.security_code']);
    }

    public function testDeferException(): void
    {
        $this->withoutMiddleware();
        $this->mockGetSettingsWithData();
        $payload = $this->payloadDeferBlockCard();
        $response = $this->postJson('/api/payments/defer', $payload);
        $result = $response->decodeResponseJson();
        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
    }

    public function testDeferWithDNA(): void
    {
        $this->withoutMiddleware();
       
        $this->mockSuccessPreAuthRequest();

        $this->mockGetSettings();
        $data = $this->payloadDeferDna();

        $data = array_replace_recursive(
            $data,
            ['card_details' => [
                'payment_channel' => 'dna',
            ]]
        );
        
        $response = $this->postJson('/api/payments/defer', $data);
        $result = $response->decodeResponseJson();

        $response->assertStatus(200);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertArrayHasKey('transaction_type', $result['data']);
        $this->assertEquals($result['data']['transaction_type'], 'VERIFICATION');
        $this->assertEquals($data['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($data['vendor_tx_code'], $result['data']['vendor_tx_code']);
        // We are doing defer transaction with zero amount with DNA
        $this->assertEquals($result['data']['transaction_amount'], 0);
    }

    public function testPayWithDNA(): void
    {
        $this->invoiceId = "DNA-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '";
        $this->withoutMiddleware();
       
        $this->mockMakePaymentRequest($this->invoiceId);

        $this->mockGetSettings();
        $data = $this->payloadPayment();

        $data = array_replace_recursive(
            $data,
            ['card_details' => [
                'card_identifier' => '71ab5d9a-a100-474e-bff5-56baa26eb2e4',
                'payment_channel' => 'dna',
            ]]
        );
        $response = $this->postJson('/api/payments/pay', $data);
        $result = $response->decodeResponseJson();
        
        $response->assertStatus(200);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertArrayHasKey('transaction_type', $result['data']);
        $this->assertEquals($result['data']['transaction_type'], 'SALE');
        $this->assertEquals($data['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($data['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('payment_channel', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertEquals('dna', $result['data']['transaction_response']['dvb_payment_response']['payment_channel']);
    }

    public function test_should_be_able_to_make_repeat_payment_with_dna(): void
    {
        $deferResult = $this->callDeferredTransaction();
        $payResult = $this->callPaymentTransaction();
    
        $payload = array_merge($this->getRepeatPayload(), [
            'reference_transaction_uuid' => $payResult['data']['uuid'],
            'payment_channel' => 'dna',
        ]);
        
        $response = $this->postJson('/api/payments/repeat', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(200);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('parent_uuid', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertArrayHasKey('account_type_uuid', $result['data']);
        $this->assertEquals($deferResult['data']['uuid'], $result['data']['parent_uuid']);
        $this->assertEquals('SALE', $result['data']['transaction_type']);
        $this->assertEquals($payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertEquals($payload['account_type_uuid'], $result['data']['account_type_uuid']);
    }

    public function callDeferredTransaction()
    {
        $this->withoutMiddleware();
        $this->mockGetSettings();
        $this->mockSuccessPreAuthRequest();
        
        $payload = array_merge($this->payloadDeferDna(), [
            'payment_information_uuid' => '6cb07b9a-60b2-4793-be76-611c506b0d0e',
        ]);
        $payload = array_replace_recursive(
            $payload,
            ['card_details' => [
                'payment_channel' => 'dna',
            ]]
        );
        
        $response = $this->postJson('/api/payments/defer', $payload);
        $result = $response->decodeResponseJson();

        $response->assertStatus(HttpResponse::HTTP_OK);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);

        return $result;
    }

    public function callPaymentTransaction()
    {
        $invoiceId = 'DNA-' . time() . '-ORDER-SALE' . mt_rand(1000, 9999);
        $this->withoutMiddleware();
        $this->mockGetSettings();
        $this->mockMakePaymentRequest($invoiceId);
        $data = $this->payloadPayment();

        $data = array_replace_recursive(
            $data,
            ['card_details' => [
                'card_identifier' => '71ab5d9a-a100-474e-bff5-56baa26eb2e4',
                'payment_channel' => 'dna',
            ],
            'payment_information_uuid' => '6cb07b9a-60b2-4793-be76-611c506b0d0e',
            'vendor_tx_code' => $invoiceId, ]
        );
    
        $response = $this->postJson('/api/payments/pay', $data);
        $result = $response->decodeResponseJson();

        $response->assertStatus(HttpResponse::HTTP_OK);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('is_successful', $result['data']);

        return $result;
    }

    public function testDeferLongAddress1ForDNA(): void
    {
        $this->withoutMiddleware();
       
        $this->mockSuccessPreAuthRequest();

        $this->mockGetSettings();
        $data = $this->payloadDeferDna();

        $data = array_replace_recursive(
            $data,
            ['card_details' => [
                'payment_channel' => 'dna',
            ]],
            ['billing_address' => [
                'address1' => 'FLAT 20 Donegal House, Cambridge Heath Road, LONDON, GREATER LONDON',
            ]]
        );
        
        $response = $this->postJson('/api/payments/defer', $data);
        $result = $response->decodeResponseJson();

        $response->assertStatus(200);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertArrayHasKey('transaction_type', $result['data']);
        $this->assertEquals($result['data']['transaction_type'], 'VERIFICATION');
        $this->assertEquals($data['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($data['vendor_tx_code'], $result['data']['vendor_tx_code']);
        // We are doing defer transaction with zero amount with DNA
        $this->assertEquals($result['data']['transaction_amount'], 0);
    }
}
