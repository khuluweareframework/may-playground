<?php

namespace Modules\Payment\Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Str;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Events\TransactionReadList;
use Tests\TestCase;

class TransactionControllerTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    public function testIndex()
    {
        factory(Transaction::class, 10)->create();

        $response = $this->getJson(route('transactions.index'));

        $response
            ->assertOk()
            ->assertJsonStructure([
                'data' => [
                    '*' => [
                        'uuid',
                        'customer_uuid',
                        'order_uuid',
                        'parent_uuid',
                        'transaction_id',
                        'transaction_type',
                        'transaction_amount',
                        'transaction_response',
                        'card_last_four_digits',
                        'card_expiry_date',
                        'is_voided',
                        'is_refunded',
                        'refunded_amount',
                    ],
                ],
            ]);

        $this->assertDatabaseHas('stored_events', [
            'event_class' => TransactionReadList::class,
        ]);
    }

    public function testIndexFilterByOrderUuid()
    {
        $transactions = factory(Transaction::class, 10)->create();

        $response = $this->getJson(route('transactions.index', ['filters' => ['order_uuid' => $transactions->first()->order_uuid]]));

        $response
            ->assertOk()
            ->assertJsonCount(1, 'data')
            ->assertJson([
                'data' => [
                    [
                        'uuid' => $transactions->first()->uuid,
                        'order_uuid' => $transactions->first()->order_uuid,
                    ],
                ],
            ]);
    }

    public function testIndexFilterByParentUuid()
    {
        $uuid = (string) Str::uuid();
        $transactions = factory(Transaction::class, 10)->create(
            [
                'parent_uuid' => $uuid,
            ]
        );
        $response = $this->getJson(route('transactions.index', ['filters' => ['parent_uuid' => $uuid]]));
        $response
            ->assertOk()
            ->assertJsonCount(10, 'data')
            ->assertJson([
                'data' => [
                    [
                        'parent_uuid' => $uuid,
                    ],
                ],
            ]);
    }

    public function testIndexFilterByTypes()
    {
        $transaction1 = factory(Transaction::class)->create(['transaction_type' => 'Payment']);
        factory(Transaction::class)->create(['transaction_type' => 'Deferred']);

        $response = $this->getJson(route('transactions.index', ['filters' => ['type' => ['Payment']]]));

        $response
            ->assertOk()
            ->assertJsonCount(1, 'data')
            ->assertJson([
                'data' => [
                    [
                        'uuid' => $transaction1->uuid,
                        'order_uuid' => $transaction1->order_uuid,
                    ],
                ],
            ]);
    }

    public function testIndexFilterByTypesAndSuccessful()
    {
        $transaction1 = factory(Transaction::class)->create(['transaction_type' => 'Payment', 'is_successful' => true]);
        factory(Transaction::class)->create(['transaction_type' => 'Deferred']);
        factory(Transaction::class)->create(['transaction_type' => 'Payment']);

        $response = $this->getJson(route('transactions.index', ['filters' => ['type' => ['Payment'], 'is_successful' => true]]));

        $response
            ->assertOk()
            ->assertJsonCount(1, 'data')
            ->assertJson([
                'data' => [
                    [
                        'uuid' => $transaction1->uuid,
                        'order_uuid' => $transaction1->order_uuid,
                    ],
                ],
            ]);

        $this->assertEquals(3, Transaction::all()->count());
    }

    public function testIndexPerPageAll()
    {
        factory(Transaction::class, 20)->create();

        $response = $this->getJson(route('transactions.index', ['per_page' => -1]));

        $response
            ->assertOk()
            ->assertJsonCount(20, 'data');
    }

    public function testIndexOrderByOrderUuid()
    {
        $transactions = factory(Transaction::class, 10)->create();
        $response = $this->getJson(route('transactions.index', ['order_by' => 'transaction_amount', 'order' => 'asc']));

        $transactions = $transactions->filter(function ($item) {
            return ! is_null($item->transaction_amount);
        });
        
        $response
            ->assertOk()
            ->assertJsonCount(10, 'data')
            ->assertJson([
                'data' => [
                    [
                        'transaction_amount' => $transactions->min('transaction_amount'),
                    ],
                ],
            ]);
    }
}
