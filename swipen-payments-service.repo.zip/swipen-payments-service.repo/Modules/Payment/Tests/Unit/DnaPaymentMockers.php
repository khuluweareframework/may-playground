<?php

namespace Modules\Payment\Tests\Unit;

use GuzzleHttp\Psr7\Response;
use Mockery;
use Modules\Payment\Exceptions\PaymentException;
use Modules\Payment\Http\Requests\ClientRequestHandler;

trait DnaPaymentMockers
{
    protected function mockSuccessPreAuthRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->andReturn(new Response(200, [], '{
                    "accountId": "ACN_123",
                    "amount": 0,
                    "authCode": "634047",
                    "authDateTimeUTC": "2021-11-26T13:40:48.108867148Z",
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Partial Match",
                    "cardExpiryDate": "11/22",
                    "cardIssuingCountry": "BRA",
                    "cardPanStarred": "***************9909",
                    "cardTokenId": "48412197-0633-4939-b1b0-6f756906338c",
                    "cardholderName": "John Doe",
                    "cscResult": "Matched",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "048a8d66-c0f6-435e-bb35-1f581ff0e384",
                    "invoiceId": "INV_123",
                    "message": "Frictionless Flow - Authorized",
                    "payerAuthenticationResult": "Y/A",
                    "responseCode": "00",
                    "rrn": "767f9f70-f58e-4f11-a41b-809fc1f20d03",
                    "schemeReferenceData": "   033014",
                    "status": "succeeded",
                    "success": true,
                    "threeDS": {
                        "acsTransactionId": "39a86e8f-acb7-44b4-940e-dda709093194",
                        "cardholderAuthenticationStatus": "A",
                        "cardholderAuthenticationValue": "kEOMrf6cAACqmBK0gmFtI4EZHr8C",
                        "dsTransactionId": "39a86e8f-acb7-44b4-940e-dda709093194",
                        "eci": "01",
                        "mpiTransactionId": "cc7de5ad-74ec-405d-b2d6-6aaeaeb7c45d",
                        "threeDSSessionData": "eyJ0aWQiOiIwNDhhOGQ2Ni1jMGY2LTQzNWUtYmIzNS0xZjU4MWZmMGUzODQiLCJ0b2tlbiI6IjRvU3U9YlJJZU5BOGMyUGViVj13emJiPXFHWGlGbURtdjRIeWlmLmJ3eTBZIVpqUEdacyp4Klc1Y0VEPXhNazEifQ==",
                        "version": "2"
                    }
                }'));
        }));
    }

    protected function mockErrorPreAuthRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->andReturn(new Response(200, [], '{
                    "amount": 0,
                    "authCode": "XXXXXX",
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Not Matched",
                    "cardExpiryDate": "12\/21",
                    "cardPanStarred": "***************9909",
                    "cardholderName": "John Doe",
                    "cscResult": "Not Set",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "38cba41f-ffe3-4e0d-8fb2-19c1b8dba333",
                    "invoiceId": "SPRINGBEE-1638884822-ORDER-CANDACE2886",
                    "message": "Frictionless Flow - Transaction Declined - Card issuer temporarily not reachable",
                    "payerAuthenticationResult": "Y\/A",
                    "responseCode": "91",
                    "rrn": "55e0198e-6d9b-4f3e-a125-60e5c8b57dff",
                    "settled": false,
                    "success": false,
                    "threeDS": {
                        "acsTransactionId": "36126627-42b4-4677-a768-24978dd41841",
                        "cardholderAuthenticationStatus": "A",
                        "cardholderAuthenticationValue": "kEPrb0qyAACqmBK0gmENxlU1nYbN",
                        "dsTransactionId": "36126627-42b4-4677-a768-24978dd41841",
                        "eci": "01",
                        "mpiTransactionId": "eecd7b39-2b02-4b8a-b80d-303e7ee99ead",
                        "threeDSSessionData": "eyJ0aWQiOiIzOGNiYTQxZi1mZmUzLTRlMGQtOGZiMi0xOWMxYjhkYmEzMzMiLCJ0b2tlbiI6IjQyenNvMG9Iay5GWW5JZW9aQzFORklSWVhFb0wwN2oyb0VCdXRzR0N1MiRtY0N5IWFocHlTcENQT25XeEEwTG4ifQ==",
                        "version": "2"
                    }
                }'));
        }));
    }

    protected function mockSuccessPayment()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->andReturn(new Response(200, [], '{
            "amount": 0.01,
            "avsHouseNumberResult": "Not Checked",
            "avsPostcodeResult": "Not Matched",
            "cardExpiryDate": "12\/21",
            "cardIssuingCountry": "USA",
            "cardPanStarred": "***************1111",
            "cardSchemeId": 11,
            "cardSchemeName": "VISA",
            "cardTokenId": "71ab5d9a-a100-474e-bff5-56baa26eb2e4",
            "cardholderName": "TEST",
            "cscResult": "Not Checked",
            "currency": "GBP",
            "errorCode": 0,
            "id": "5905f216-e3d4-49c8-9ea3-f73a5a55dfa1",
            "invoiceId": "DNA-1638885559-ORDER-CANDACE6540",
            "message": "The cardholder is enrolled in payer authentication. Please authenticate before proceeding with authorization.",
            "payerAuthenticationResult": "C\/-",
            "rrn": "af38577e-9644-4fca-9408-199b0c017a79",
            "status": "requires_action",
            "success": true,
            "threeDS": {
                "acsTransactionId": "ddeb9041-0473-4937-a866-c1e4728ec783",
                "acsUrl": "https:\/\/www.threedsecurempi.com\/EMVTDS\/AUT?Action=ProcessCReq",
                "cardholderAuthenticationStatus": "C",
                "creq": "eyJhY3NUcmFuc0lEIjoiZGRlYjkwNDEtMDQ3My00OTM3LWE4NjYtYzFlNDcyOGVjNzgzIiwidGhyZWVEU1NlcnZlclRyYW5zSUQiOiI3ZmRlNmQ5Ny1mNDg2LTRhOWItYjUyMS02YmJiZjE4NGVmNTQiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDQiLCJtZXNzYWdlVHlwZSI6IkNSZXEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0=",
                "dsTransactionId": "a6f3768a-1334-4f2d-85a8-e4dc46708ad5",
                "mpiTransactionId": "7fde6d97-f486-4a9b-b521-6bbbf184ef54",
                "threeDSSessionData": "eyJ0aWQiOiI1OTA1ZjIxNi1lM2Q0LTQ5YzgtOWVhMy1mNzNhNWE1NWRmYTEiLCJ0b2tlbiI6Inh2eGhHKkk9UXp0UDd2OGVaMXpydmJwaTEwel96SHVzYUNJeDlBMW5nKlVnM2ckTi15UUtlNGFrSXNpZ1dZcEsifQ==",
                "type": "Dynamic",
                "version": "2"
            }
        }'));
        }));
    }

    protected function mockMakePaymentRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->andReturn(new Response(200, [], '{
                    "accountId": "ACN_123",
                    "amount": 0,
                    "authCode": "634047",
                    "authDateTimeUTC": "2021-11-26T13:40:48.108867148Z",
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Partial Match",
                    "cardExpiryDate": "11/22",
                    "cardIssuingCountry": "BRA",
                    "cardSchemeName": "VISA",
                    "cardPanStarred": "***************9909",
                    "cardTokenId": "71ab5d9a-a100-474e-bff5-56baa26eb2e4",
                    "cardholderName": "John Doe",
                    "cscResult": "Matched",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "048a8d66-c0f6-435e-bb35-1f581ff0e384",
                    "invoiceId": "' . $this->invoiceId . '",
                    "message": "Frictionless Flow - Authorized",
                    "payerAuthenticationResult": "Y/A",
                    "responseCode": "00",
                    "rrn": "767f9f70-f58e-4f11-a41b-809fc1f20d03",
                    "schemeReferenceData": "   033014",
                    "status": "succeeded",
                    "success": true,
                    "threeDS": {
                        "acsTransactionId": "39a86e8f-acb7-44b4-940e-dda709093194",
                        "cardholderAuthenticationStatus": "A",
                        "cardholderAuthenticationValue": "kEOMrf6cAACqmBK0gmFtI4EZHr8C",
                        "dsTransactionId": "39a86e8f-acb7-44b4-940e-dda709093194",
                        "eci": "01",
                        "mpiTransactionId": "cc7de5ad-74ec-405d-b2d6-6aaeaeb7c45d",
                        "threeDSSessionData": "eyJ0aWQiOiIwNDhhOGQ2Ni1jMGY2LTQzNWUtYmIzNS0xZjU4MWZmMGUzODQiLCJ0b2tlbiI6IjRvU3U9YlJJZU5BOGMyUGViVj13emJiPXFHWGlGbURtdjRIeWlmLmJ3eTBZIVpqUEdacyp4Klc1Y0VEPXhNazEifQ==",
                        "version": "2"
                    }
                }'));
        }));
    }

    protected function mockInvalidCardToken()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->andReturn(new Response(200, [], '{
                    "accountId": "ACN_123",
                    "amount": 0,
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Not Checked",
                    "cardExpiryDate": "12/20",
                    "cardPanStarred": "***********6039",
                    "cardholderName": "John Doe",
                    "cscResult": "Not Checked",
                    "currency": "GBP",
                    "errorCode": 3554,
                    "id": "2b7dce5b-a377-4328-adde-93786a9471b6",
                    "invoiceId": "' . $this->invoiceId . '",
                    "message": "Card token not found",
                    "payerAuthenticationResult": "-/-",
                    "success": false
                }'));
        }));
    }

    protected function mockInvalidPayloadRequest()
    {
        $mockResponse = new Response(200, [], '{
                "accountId": "ACN_123",
                "amount": 0,
                "avsHouseNumberResult": "Not Checked",
                "avsPostcodeResult": "Not Checked",
                "cardExpiryDate": "12/20",
                "cardPanStarred": "***********6039",
                "cardholderName": "John Doe",
                "cscResult": "Not Checked",
                "currency": "GBP",
                "errorCode": 3554,
                "id": "2b7dce5b-a377-4328-adde-93786a9471b6",
                "invoiceId": "' . $this->invoiceId . '",
                "message": "The value of \'customerDetails -> billingAddress -> firstName\' (string, max 32 chars) is invalid or empty",
                "payerAuthenticationResult": "-/-",
                "success": false
            }');

        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) use ($mockResponse) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn($mockResponse)->andThrows(new PaymentException('Dna Error', 200, $mockResponse));
            ;
        }));
    }

    private function mockInvalidRepeatPaymentRequestWithExeption()
    {
        $mockResponse = new Response(200, [], '{
                "parentTransactionId": "foo",
                "errorCode": 2067,
                "success": false,
                "message": "Incorrect state of the parent transaction to perform the operation. Please check input"
                }');

        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) use ($mockResponse) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->andThrows(new PaymentException('Dna Error', 200, $mockResponse));
        }));
    }

    private function mockInvalidRepeatPaymentRequest()
    {
        $mockResponse = new Response(200, [], '{
                "parentTransactionId": "foo",
                "errorCode": 2067,
                "success": false,
                "message": "Incorrect state of the parent transaction to perform the operation. Please check input"
                }');

        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) use ($mockResponse) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->andReturns($mockResponse);
        }));
    }

    protected function mockAvsFailRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "accountId": "ACN_123",
                    "amount": 0,
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Partial Match",
                    "cardExpiryDate": "12/21",
                    "cardPanStarred": "***************1111",
                    "cardholderName": "John Doe",
                    "cscResult": "Not Checked",
                    "currency": "GBP",
                    "errorCode": 3010,
                    "id": "68a262c2-e271-4427-bc79-89229bb0aa9f",
                    "invoiceId": "INV_123",
                    "message": "Transaction Rejected due to AVS",
                    "payerAuthenticationResult": "-/-",
                    "settled": false,
                    "success": false
                }'));
        }));
    }

    protected function mockAvsSuccessRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "amount": 0,
                    "authCode": "306138",
                    "authDateTimeUTC": "2021-12-13T14:35:38.936225024Z",
                    "avsHouseNumberResult": "Matched",
                    "avsPostcodeResult": "Matched",
                    "cardExpiryDate": "12/21",
                    "cardIssuingCountry": "BRA",
                    "cardPanStarred": "***************9909",
                    "cardSchemeId": 8,
                    "cardSchemeName": "MasterCard",
                    "cardTokenId": "Te+q8PDfCk/ZuhiZrwUKd3HJT4L3jRS1bE83LvgAjO8fMQ==",
                    "cardholderName": "John Doe",
                    "cscResult": "Matched",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "3c54fec3-34fb-44ae-9201-1eb091cc0fbd",
                    "invoiceId": "SPRINGBEE-1639406128-ORDER-CANDACE7147",
                    "message": "Frictionless Flow - Authorized",
                    "payerAuthenticationResult": "Y/A",
                    "responseCode": "00",
                    "rrn": "ba1d5d78-6078-4f77-9fda-fe6422de3fb1",
                    "schemeReferenceData": "   165030",
                    "settled": false,
                    "status": "succeeded",
                    "success": true,
                    "threeDS": {
                        "acsTransactionId": "0ba1ddb5-65b5-4e01-a5f7-13d5b8f2323c",
                        "cardholderAuthenticationStatus": "A",
                        "cardholderAuthenticationValue": "kEOio/rFAACqmBK0gmEx8ix/eSf3",
                        "dsTransactionId": "0ba1ddb5-65b5-4e01-a5f7-13d5b8f2323c",
                        "eci": "01",
                        "mpiTransactionId": "f2f9de8d-e908-4cd7-bc04-c5f79b904e4f",
                        "threeDSSessionData": "eyJ0aWQiOiIzYzU0ZmVjMy0zNGZiLTQ0YWUtOTIwMS0xZWIwOTFjYzBmYmQiLCJ0b2tlbiI6IlYxQU90VUlnXyp3ZzhadVhlZ0F4N19mWTU5PXV5YiQ3ZTBqd0FEeVlOWTQ3Q3VPTWFqNz1kRipqc0tReGRUWXgifQ==",
                        "version": "2"
                    }
                }'));
        }));
    }

    private function mockAuthRequest($mock)
    {
        $mock->shouldReceive('processRequest')
            ->andReturn(new Response(200, [], '{
               "access_token": "M7=iuWkz0WaGuN0TX2YHW*.MkECgdgWEY*!x_4h*h2FsNvNs9ybVx*G4mYrQf0cI",
               "expires_in": 7200,
               "refresh_token": "eZp5tFtQUGG1hmC=hzcnSiE*=ENld=9Yd.OgQ.U!a$e7R26g7$JZaLHpmqqePkWV",
               "scope": "webapi",
               "token_type": "Bearer"
           }'));
    }

    private function mockValidRepeatPaymentResponse()
    {
        $mockResponse = new Response(200, [], '{
            "id": "2303047a-1aa2-48b3-a03a-2ba76b1d2844",
            "rrn": "e70a198b-836a-4f79-96fd-af7477aa630a",
            "amount": 43.79,
            "message": "Completed successfully",
            "settled": true,
            "success": true,
            "authCode": "551545",
            "currency": "GBP",
            "response": {
                "statusCode": 200
            },
            "errorCode": 0,
            "invoiceId": "' . $this->invoiceId . '",
            "responseCode": "00",
            "authDateTimeUTC": "2021-12-15T06:59:05.711190414Z",
            "transactionType": "SALE",
            "parentTransactionId": "ef796ef1-8df4-4ae3-aead-2dd108149894",
            "dvb_payment_response": {
                "success": true,
                "parent_uuid": "6cb07b9a-60b2-4793-be76-611c506b0d0e",
                "transaction_id": "2303047a-1aa2-48b3-a03a-2ba76b1d2844",
                "transaction_type": "SALE"
            },
            "payerAuthenticationResult": "-/-"
        }');

        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) use ($mockResponse) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturns($mockResponse);
        }));
    }

    protected function mockSecureV1DeferRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "amount": 0,
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Not Checked",
                    "cardExpiryDate": "12/21",
                    "cardPanStarred": "***************1111",
                    "cardSchemeId": 11,
                    "cardSchemeName": "VISA",
                    "cardTokenId": "rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==",
                    "cardholderName": "John Doe",
                    "cscResult": "Not Checked",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "00c66f35-674f-49fd-9fbd-bfe253749840",
                    "invoiceId": "SPRINGBEE-1640863322-ORDER-CANDACE7673",
                    "message": "Cardholder enrolled in payer authentication",
                    "payerAuthenticationResult": "Y/-",
                    "rrn": "8048b5f5-ff2d-4f0b-a371-49980e3705e5",
                    "status": "requires_action",
                    "success": true,
                    "threeDS": {
                      "acsUrl": "https://www.3dsecurempi.com/TDS/AUT?Action=Authenticate",
                      "cardholderAuthenticationStatus": "Y",
                      "md": "00c66f35-674f-49fd-9fbd-bfe253749840",
                      "pareq": "eJxdUk1TwjAQvTPjf+j0DmlCxcKEMCB+cABRcRy9xXQpEfph2jrw700KhdRcmvf2bfdld+loH++cX1C5TJOhizue60Ai0lAm0dB9W923A3fErlp0tVEA01cQpQLWchw6hzznETgyHLqQRd0e4Tj0gvZX1xdtf439dp9ryKEf+sF6fQPBl2sSdepy/AI/x7tGp+JM1+4QimpYh+egxIYnRU1oioufyWzB/KDb619TdIKXeAxqNmW45xGvOhQdmbPCoQmPgS35IU0pqu5WTKRlUqgDwyazBla8VDu2KYosHyCU8UMChRR5J5SRLPiOIhOuzaP/7umyNETeKLiXIZt/77ZP0xf5GT9ff7zfeYvpljytIvIRz4YUGYWVEPICGPEIxqTrORgPCB74AUUVb+l4bNyzh8nS8TrmNSfCkmTGz/hIa4EN7ZaUSum1OLCA9HRPamQpYJ+lCegsPcLz3bYMuWDaoflc6HOf/reF3j42HiJEoQfo4+Yxs68CTSNSz8v0pnIiL8OjqP6rLljvoJlRtcmsRVFjy69af45U1Hw=",
                      "termUrl": "https://test-api.dnapayments.com/v2/payments/operation/confirm?Access=2s5fl_ln5TZKwuIM=Ox$3HyXCQAvnZjSu!r19up4Ej_H.ff.40ZJQRPsvD4=YqWi",
                      "threeDSSessionData": "00c66f35-674f-49fd-9fbd-bfe253749840",
                      "version": "1",
                      "xid": "MjlkODRiZmQ5YWE0NDk2OTg2YmI="
                    }
                }'));
        }));
    }

    protected function mockSecureV2DeferRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "amount": 0,
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Not Checked",
                    "cardExpiryDate": "12/21",
                    "cardPanStarred": "***************1111",
                    "cardSchemeId": 11,
                    "cardSchemeName": "VISA",
                    "cardTokenId": "rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==",
                    "cardholderName": "John Doe",
                    "cscResult": "Not Checked",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "09a7dbe4-01dc-44db-8335-8fbc997e8501",
                    "invoiceId": "SPRINGBEE-1640875421-ORDER-CANDACE9472",
                    "message": "The cardholder is enrolled in payer authentication. Please authenticate before proceeding with authorization.",
                    "payerAuthenticationResult": "C/-",
                    "rrn": "71ca1042-c7a7-4f49-ae5f-c843b7b61aa1",
                    "status": "requires_action",
                    "success": true,
                    "threeDS": {
                      "acsTransactionId": "c350d906-dc61-4229-a874-ffba7266d1dc",
                      "acsUrl": "https://www.threedsecurempi.com/EMVTDS/AUT?Action=ProcessCReq",
                      "cardholderAuthenticationStatus": "C",
                      "creq": "eyJhY3NUcmFuc0lEIjoiYzM1MGQ5MDYtZGM2MS00MjI5LWE4NzQtZmZiYTcyNjZkMWRjIiwidGhyZWVEU1NlcnZlclRyYW5zSUQiOiJiZDBkOTMyOS1iYzhkLTRiZDEtOTcwNS01OGY3ZDI4YjM5Y2EiLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDQiLCJtZXNzYWdlVHlwZSI6IkNSZXEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0=",
                      "dsTransactionId": "bbf77d88-214c-4078-9b28-c57211077e6b",
                      "mpiTransactionId": "bd0d9329-bc8d-4bd1-9705-58f7d28b39ca",
                      "threeDSSessionData": "eyJ0aWQiOiIwOWE3ZGJlNC0wMWRjLTQ0ZGItODMzNS04ZmJjOTk3ZTg1MDEiLCJ0b2tlbiI6Ik9fJGM3dVZyXzMyV2UzR3BQYzQqJFBYdnMqaTVldXZtIWJqZUpNV3VFWUt2NmpnQ2F5MFVDU0c2LmNlNmltZk8ifQ==",
                      "type": "Dynamic",
                      "version": "2"
                    }
                }'));
        }));
    }

    protected function mockSecureV1PayemntRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "amount": 0.01,
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Not Matched",
                    "cardExpiryDate": "12/22",
                    "cardPanStarred": "***************1111",
                    "cardSchemeId": 11,
                    "cardSchemeName": "VISA",
                    "cardTokenId": "rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==",
                    "cardholderName": "Ben Stokes",
                    "cscResult": "Not Checked",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "7dfa9901-f042-4a4d-b4fe-83ea1ab23a43",
                    "invoiceId": "DNA-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "message": "Cardholder enrolled in payer authentication",
                    "payerAuthenticationResult": "Y/-",
                    "rrn": "5e2ef71e-b2ed-4ff9-922b-2e6018b9f142",
                    "status": "requires_action",
                    "success": true,
                    "threeDS": {
                      "acsUrl": "https://www.3dsecurempi.com/TDS/AUT?Action=Authenticate",
                      "cardholderAuthenticationStatus": "Y",
                      "md": "7dfa9901-f042-4a4d-b4fe-83ea1ab23a43",
                      "pareq": "eJxdUstyozAQvLsq/0Bxx3qAbdklK5Wsd7M5QHk3ziFHWShYW+YRAVsmXx8JG1tEF9Q9PZpmZuj9KT96/6WuVVmsfTSFvicLUaaqyNb+6+5XQPx7djehu4OWcvMiRaslm3gejWVd80x6Kl37ssrmnMwWBEYB2e8XQUQIDpb72TJ4x7MIhYQIuHj3baJJ3T78lR/nu0GX4szUnmIKBjiEY6nFgRfNQBiKi4/H54RFJJwvZxRc4C2eS/28YWgOMewPBWfmqvBowXPJtrwrSwr6uxMTZVs0umPIZg7Aibf6yA5NU9UrACreFbJRop6mKlMNP1Jgw4N58N093baWqEcFTyplydPPzySPu7ddHCW7P12yycL4M4vif69rCqzCSUh5IxmGGCEcQg+hVRiuIkRBzzs6nlv37Olx68EpNIIL4Ugq6+fhTBuBC92WtFqbtegYwXPTkwE5CnmqykKaLDPC6921LGvBjEP7udHXPn1vC/3xe/QjQjRmgBEaHzv7PjA2osy8MEZnJ+o2PAqGV03BYQftjPpNZhMKRlt+N/kCFpHTsw==",
                      "termUrl": "https://test-api.dnapayments.com/v2/payments/operation/confirm?Access=lfmfY58w*oghB-hi4s9SXv_bfKdPN5a1Tr$Gc3m8G8lvI4cRX7XSWerV-goRYItq",
                      "threeDSSessionData": "7dfa9901-f042-4a4d-b4fe-83ea1ab23a43",
                      "version": "1",
                      "xid": "NGEzNmMyYTM4NTQyNDg3Mzg4MjU="
                    }
                }'));
        }));
    }

    protected function mockSecureV2PayemntRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "amount": 0.01,
                    "avsHouseNumberResult": "Not Checked",
                    "avsPostcodeResult": "Not Matched",
                    "cardExpiryDate": "01/22",
                    "cardPanStarred": "***************1111",
                    "cardSchemeId": 11,
                    "cardSchemeName": "VISA",
                    "cardTokenId": "rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==",
                    "cardholderName": "Kaivan",
                    "cscResult": "Not Checked",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "fce9f466-4b6a-4cc1-b029-fc0d5a3d1d08",
                    "invoiceId": "DNA-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "message": "The cardholder is enrolled in payer authentication. Please authenticate before proceeding with authorization.",
                    "payerAuthenticationResult": "C/-",
                    "rrn": "59cdbfb4-2397-4fa1-b7e6-73479aecddf5",
                    "status": "requires_action",
                    "success": true,
                    "threeDS": {
                      "acsTransactionId": "aff7c524-0388-4c73-8712-9040a898747e",
                      "acsUrl": "https://www.threedsecurempi.com/EMVTDS/AUT?Action=ProcessCReq",
                      "cardholderAuthenticationStatus": "C",
                      "creq": "eyJhY3NUcmFuc0lEIjoiYWZmN2M1MjQtMDM4OC00YzczLTg3MTItOTA0MGE4OTg3NDdlIiwidGhyZWVEU1NlcnZlclRyYW5zSUQiOiI0MDQwYzUyNi1hNWZhLTQ2ZTMtYTIwMy01OGQ5OTE3NGMzOTciLCJjaGFsbGVuZ2VXaW5kb3dTaXplIjoiMDQiLCJtZXNzYWdlVHlwZSI6IkNSZXEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIn0=",
                      "dsTransactionId": "85f3fbd5-b04d-473e-8a37-da7cc49c075e",
                      "mpiTransactionId": "4040c526-a5fa-46e3-a203-58d99174c397",
                      "threeDSSessionData": "eyJ0aWQiOiJmY2U5ZjQ2Ni00YjZhLTRjYzEtYjAyOS1mYzBkNWEzZDFkMDgiLCJ0b2tlbiI6InVmMHhGN0dqIXBmWVI0WCFXMF9QVVYkSU9BLnpJS2g4ITdQcW1YbFBSdGEtdiEzRC5Ycy1hUkhzJEdCLjNJN3cifQ==",
                      "type": "Dynamic",
                      "version": "2"
                    }
                  }'));
        }));
    }

    protected function mockSecureV1PaymentConfirmationRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "amount": 1,
                    "authCode": "132064",
                    "avsHouseNumberResult": "Matched",
                    "avsPostcodeResult": "Matched",
                    "cardExpiryDate": "12/21",
                    "cardPanStarred": "***************1111",
                    "cardSchemeId": 11,
                    "cardSchemeName": "VISA",
                    "cardTokenId": "rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==",
                    "cardholderName": "James Bond",
                    "cscResult": "Matched",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "c0a74361-1e78-4ce6-9ade-d98ce2433138",
                    "invoiceId": "INV_00025",
                    "message": "Completed successfully",
                    "payerAuthenticationResult": "Y/Y",
                    "responseCode": "00",
                    "rrn": "e60ed2cc-4976-4f3d-937d-7dc4cd663dfc",
                    "schemeReferenceData": "000001068208212",
                    "settled": true,
                    "status": "succeeded",
                    "success": true,
                    "threeDS": {
                        "cardholderAuthenticationStatus": "Y",
                        "cardholderAuthenticationValue": "AAACCScHkCExEgYABQeQAAAAAAA=",
                        "eci": "05",
                        "version": "1",
                        "xid": "ZDM1MGEyZTc3NDZhNDI3Zjg0OTQ="
                    }
                }'));
        }));
    }

    protected function mockSecureV2PaymentConfirmationRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "amount": 1,
                    "authCode": "132064",
                    "avsHouseNumberResult": "Matched",
                    "avsPostcodeResult": "Matched",
                    "cardExpiryDate": "12/21",
                    "cardPanStarred": "***************1111",
                    "cardSchemeId": 11,
                    "cardSchemeName": "VISA",
                    "cardTokenId": "rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==",
                    "cardholderName": "James Bond",
                    "cscResult": "Matched",
                    "currency": "GBP",
                    "errorCode": 0,
                    "id": "c0a74361-1e78-4ce6-9ade-d98ce2433138",
                    "invoiceId": "INV_00025",
                    "message": "Completed successfully",
                    "payerAuthenticationResult": "Y/Y",
                    "responseCode": "00",
                    "rrn": "e60ed2cc-4976-4f3d-937d-7dc4cd663dfc",
                    "schemeReferenceData": "000001068208212",
                    "settled": true,
                    "status": "succeeded",
                    "success": true,
                    "threeDS": {
                        "acsTransactionId": "fa50bffe-d579-4a1e-b24a-db2c7903c03c",
                        "cardholderAuthenticationStatus": "Y",
                        "cardholderAuthenticationValue": "AJkCCR34cEQFcQBZkiAAAAAAA=",
                        "dsTransactionId": "80ca035d-f39b-4238-aefa-19a9b49e18ba",
                        "eci": "05",
                        "mpiTransactionId": "a811f5cd-143e-47fc-92de-b4829263774b",
                        "type": "Dynamic",
                        "version": "2"
                    }
                }'));
        }));
    }

    protected function mockSecureInvalidaTransactionRequest()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->andReturn(new Response(200, [], '{
                    "amount": 1,
                    "errorCode": 2037,
                    "invoiceId": "",
                    "message": "Cannot find the transaction",
                    "success": false
                }'));
        }));
    }
}
