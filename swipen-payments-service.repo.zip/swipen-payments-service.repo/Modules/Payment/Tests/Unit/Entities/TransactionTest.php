<?php

namespace Modules\Payment\Tests\Unit\Entities;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Modules\Payment\Entities\Transaction;
use Tests\TestCase;

class TransactionTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    public function testGetCardLastFourDigitsAttribute()
    {
        $transaction1 = factory(Transaction::class)->create([
            'transaction_type' => 'Payment',
            'transaction_response' => [
                'paymentMethod' => [
                    'card' => [
                        'lastFourDigits' => '1234',
                    ],
                ],
            ],
        ]);

        $this->assertEquals('1234', $transaction1->card_last_four_digits);
    }

    public function testGetCardExpiryDateAttribute()
    {
        $transaction1 = factory(Transaction::class)->create([
            'transaction_type' => 'Payment',
            'transaction_response' => [
                'paymentMethod' => [
                    'card' => [
                        'expiryDate' => '0121',
                    ],
                ],
            ],
        ]);

        $this->assertEquals('0121', $transaction1->card_expiry_date);
    }

    public function testGetIsVoidedAttribute()
    {
        $transaction1 = factory(Transaction::class)->create(['transaction_type' => 'Payment']);
        $transaction2 = factory(Transaction::class)->create([
            'parent_uuid' => $transaction1->uuid,
            'transaction_type' => 'Void',
        ]);
        $transaction3 = factory(Transaction::class)->create(['transaction_type' => 'Payment']);

        $this->assertTrue($transaction1->is_voided);
        $this->assertFalse($transaction3->is_voided);
    }

    public function testGetIsAbortedAttribute()
    {
        $transaction1 = factory(Transaction::class)->create(['transaction_type' => 'Deferred']);
        $transaction2 = factory(Transaction::class)->create([
            'parent_uuid' => $transaction1->uuid,
            'transaction_type' => 'Abort',
        ]);
        $transaction3 = factory(Transaction::class)->create(['transaction_type' => 'Deferred']);

        $this->assertTrue($transaction1->is_aborted);
        $this->assertFalse($transaction3->is_aborted);
    }

    public function testGetIsRefundedAttribute()
    {
        $transaction1 = factory(Transaction::class)->create(['transaction_type' => 'Payment']);
        $transaction2 = factory(Transaction::class)->create([
            'parent_uuid' => $transaction1->uuid,
            'transaction_type' => 'Refund',
            'transaction_amount' => 500,
        ]);
        $transaction3 = factory(Transaction::class)->create(['transaction_type' => 'Payment']);

        $this->assertTrue($transaction1->is_refunded);
        $this->assertEquals(500, $transaction1->refunded_amount);
        $this->assertFalse($transaction3->is_refunded);
    }

    public function testIsAuthenticatedAttribute()
    {
        // Create an authenticated transaction.
        $authTransaction = factory(Transaction::class)->state('authenticated')->make();

        // Create a not authenticated transaction.
        $notAuthTransaction = factory(Transaction::class)->state('notAuthenticated')->make();

        $this->assertTrue($authTransaction->is_authenticated);
        $this->assertFalse($notAuthTransaction->is_authenticated);
    }
}
