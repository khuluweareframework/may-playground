<?php

namespace Modules\Payment\Tests\Unit\Gateway\Dna;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Response as HttpResponse;
use Illuminate\Support\Facades\Config;
use Illuminate\Validation\ValidationException;
use Modules\Payment\Entities\Settings;
use Modules\Payment\Gateway\Dna\Deferred;
use Modules\Payment\Tests\Unit\DnaPaymentMockers;
use Modules\Payment\Tests\Unit\PaymentPayload;
use Tests\TestCase;

class DeferredTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, DnaPaymentMockers;

    /**
     * Payload for payment request
     *
     * @var array
     */
    protected $payload;

    /**
     * Setup payment payload
     *
     * @return  void
     */
    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'dna');
        $this->payload = $this->payloadDeferDna();
    }

    public function testSuccessDeferredOrder(): void
    {
        $this->mockSuccessPreAuthRequest();

        $deferred = new Deferred();
        $deferred->setPayload($this->payload);
        $response = $deferred->deferredOrder();
        $this->assertArrayHasKey('response', $response);
        $this->assertArrayHasKey('success', $response);
        $this->assertArrayHasKey('amount', $response);
        $this->assertEquals(HttpResponse::HTTP_OK, $response['response']['statusCode']);
        $this->assertTrue($response['success']);
        $this->assertEquals(0, $response['amount']);
    }

    public function testErrorDeferredOrder(): void
    {
        $this->expectException(ValidationException::class);

        $this->mockErrorPreAuthRequest();
        $deferred = new Deferred();
        $payload = array_replace_recursive(
            $this->payload,
            ['card_details' => ['card_number' => '4111111111112111']]
        );
        $deferred->setPayload($payload);
        $response = $deferred->deferredOrder();

        $this->assertArrayHasKey('errorCode', $response);
        $this->assertArrayHasKey('message', $response);
        $this->assertEquals($response['success'], false);
        $this->assertEquals($response['cardholderName'], $this->payload['card_details']['cardholder_name']);
        $this->assertEquals($response['transactionType'], 'VERIFICATION');
    }

    public function testDeferredOrderWithAVSFail(): void
    {
        $this->mockAvsFailRequest();
        $this->payload['apply_avs_cvc_check'] = 'Force';

        $deferred = new Deferred();
        $deferred->setPayload($this->payload);
        $response = $deferred->deferredOrder();

        $this->assertArrayHasKey('response', $response);
        $this->assertArrayHasKey('success', $response);
        $this->assertArrayHasKey('amount', $response);
        $this->assertArrayHasKey('dvb_payment_response', $response);
        $this->assertFalse($response['success']);
        $this->assertTrue($response['dvb_payment_response']['avs_cvc_error']);
        $this->assertEquals(0, $response['amount']);
        $this->assertEquals('Transaction Rejected due to AVS', $response['message']);
    }

    public function testDeferredOrderWithAVSSuccess(): void
    {
        $this->mockAvsSuccessRequest();
        $this->payload['apply_avs_cvc_check'] = 'Force';
        $this->payload['billing_address']['postal_code'] = '10';
        $this->payload['billing_address']['address1'] = '100 ';
        $this->payload['card_details']['security_code'] = '111 ';

        $deferred = new Deferred();
        $deferred->setPayload($this->payload);
        $response = $deferred->deferredOrder();

        $this->assertArrayHasKey('response', $response);
        $this->assertArrayHasKey('success', $response);
        $this->assertArrayHasKey('amount', $response);
        $this->assertArrayHasKey('dvb_payment_response', $response);
        $this->assertTrue($response['success']);
        $this->assertFalse($response['dvb_payment_response']['avs_cvc_error']);
        $this->assertEquals('Matched', $response['avsHouseNumberResult']);
        $this->assertEquals('Matched', $response['avsPostcodeResult']);
        $this->assertEquals('Matched', $response['cscResult']);
    }

    /**
     * Test Defer payment with AVS/CSC DB Override values
     *
     * @dataProvider avsCscOverrideValues
     * @return  void
     */
    public function testAvsCscMatrixDatabaseOverride($postCodeArray, $houseNumberArray, $cscArray): void
    {
        //Arrange
        factory(Settings::class)->create($postCodeArray);
        factory(Settings::class)->create($houseNumberArray);
        factory(Settings::class)->create($cscArray);
        
        //Act
        $deferred = new Deferred();
        $response = $this->getArrayFromClassObject($deferred->setPayload($this->payload));

        //Assetion
        $this->assertArrayHasKey('payload', $response);
        $this->assertArrayHasKey('billing_address', $response['payload']);
        $this->assertArrayHasKey('card_details', $response['payload']);
        $this->assertArrayHasKey('address1', $response['payload']['billing_address']);
        $this->assertArrayHasKey('postal_code', $response['payload']['billing_address']);
        $this->assertArrayHasKey('security_code', $response['payload']['card_details']);

        $this->assertEquals($postCodeArray['value'], $response['payload']['billing_address']['postal_code']);
        $this->assertEquals($houseNumberArray['value'], $response['payload']['billing_address']['address1']);
        $this->assertEquals($cscArray['value'], $response['payload']['card_details']['security_code']);
    }

    /**
     * Get AVS and CSC parameter with value
     *
     * @return  array
     */
    public function avsCscOverrideValues(): array
    {
        return [
            [
                [
                    'key' => 'dna_postcode_override',
                    'value' => '10',
                    'active' => 1,
                ],
                [
                    'key' => 'dna_house_number_override',
                    'value' => '100',
                    'active' => 1,
                ],
                [
                    'key' => 'dna_csc_override',
                    'value' => '111',
                    'active' => 1,
                ],
            ],
        ];
    }

    /**
     * Get an array from class object
     *
     * @param  $object
     *
     * @return  array
     */
    public function getArrayFromClassObject($object): array
    {
        $reflectionClass = new \ReflectionClass(get_class($object));
        $array = [];
        foreach ($reflectionClass->getProperties() as $property) {
            $property->setAccessible(true);
            $array[$property->getName()] = $property->getValue($object);
            $property->setAccessible(false);
        }

        return $array;
    }
}
