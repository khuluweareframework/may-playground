<?php
namespace Modules\Payment\Tests\Unit\Gateway\Dna;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Illuminate\Validation\ValidationException;
use Modules\Payment\Entities\Settings;
use Modules\Payment\Exceptions\DNAException;
use Modules\Payment\Gateway\Dna\Payment;
use Modules\Payment\Gateway\Dna\Repeat;
use Modules\Payment\Tests\Unit\DnaPaymentMockers;
use Modules\Payment\Tests\Unit\PaymentPayload;
use Ramsey\Uuid\Uuid;
use SettingServiceClient;
use Tests\TestCase;

class PaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, DnaPaymentMockers;

    /**
     * Valid payload for payment request
     *
     * @var array
     */
    protected $validPayload;

    /**
     * Invalid payload for payment request
     *
     * @var array
     */
    protected $invalidPayload;

    /**
     * Invoice ID
     *
     * @var string
     */
    protected $invoiceId;

    /**
     * Setup payment payload
     *
     * @return  void
     */
    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'dna');
        $this->invoiceId = "DNA-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '";
        $this->validPayload = $this->payloadPaymentByCardIdentifierDna($this->invoiceId);
        $this->invalidPayload = $this->invalidPayloadPaymentByCardIdentifierDna($this->invoiceId);
    }

    public function testMakePayment(): void
    {
        $this->mockGetSettings();
        $this->mockMakePaymentRequest();
        $payment = new Payment();
        $payment->setPayload($this->validPayload);
        $response = $payment->paymentOrder();

        self::assertArrayHasKey('cardTokenId', $response);
        self::assertArrayHasKey('cardSchemeName', $response);
        self::assertEquals($response['success'], true);
        self::assertEquals($response['invoiceId'], $this->validPayload['vendor_tx_code']);
        self::assertEquals($response['cardTokenId'], $this->validPayload['card_details']['card_identifier']);
        self::assertEquals($response['transactionType'], 'SALE');
    }

    public function testInvalidCardToken(): void
    {
        $this->expectException(ValidationException::class);

        $payload = array_replace_recursive(
            $this->validPayload,
            ['card_details' => ['card_identifier' => Uuid::uuid4()->toString()]]
        );

        $this->mockGetSettings();
        $this->mockInvalidCardToken();
        $payment = new Payment();
        $payment->setPayload($payload);
        $response = $payment->paymentOrder();

        self::assertArrayHasKey('errorCode', $response);
        self::assertArrayHasKey('message', $response);
        self::assertEquals($response['success'], false);
        self::assertEquals($response['invoiceId'], $this->validPayload['vendor_tx_code']);
        self::assertEquals($response['transactionType'], 'SALE');
        self::assertEquals($response['message'], 'Card token not found');
    }

    public function testInvalidPayload(): void
    {
        $this->expectException(ValidationException::class);

        $this->mockGetSettings();
        $this->mockInvalidPayloadRequest();

        $payment = new Payment();
        $payment->setPayload($this->invalidPayload);
        $response = $payment->paymentOrder();
        self::assertArrayHasKey('message', $response);
        self::assertEquals($response['message'], "The value of 'customerDetails -> billingAddress -> firstName' (string, max 32 chars) is invalid or empty");
    }

    public function testRepeatPayment(): void
    {
        $this->expectException(ValidationException::class);

        $this->mockInvalidRepeatPaymentRequestWithExeption();
        $this->mockGetSettings();

        $payment = new Repeat();

        $repeatTransactionPayload = [
            'parentTransactionId' => 'foo',
            'transactionType' => 'SALE',
            'transaction' => [
                'transaction_id' => 'foo',
            ],
            'amount' => 0,
            'sequenceType' => 'recurring',
            'periodicType' => 'ucof',
            'invoiceId' => 'RECCCC_0001_rec_01',
        ];

        $payment->setPayload(array_merge($repeatTransactionPayload, $this->invalidPayload));
        $response = $payment->repeatOrder();

        self::assertArrayHasKey('message', $response);
        self::assertEquals($response['message'], 'Incorrect state of the parent transaction to perform the operation. Please check input');
    }

    public function testMakePaymentWithAVSFail(): void
    {
        $this->mockAvsFailRequest();
        $this->validPayload['apply_avs_cvc_check'] = 'Force';
        $payment = new Payment();
        $payment->setPayload($this->validPayload);
        $response = $payment->paymentOrder();

        $this->assertArrayHasKey('response', $response);
        $this->assertArrayHasKey('success', $response);
        $this->assertArrayHasKey('amount', $response);
        $this->assertArrayHasKey('dvb_payment_response', $response);
        $this->assertFalse($response['success']);
        $this->assertTrue($response['dvb_payment_response']['avs_cvc_error']);
        $this->assertEquals('Transaction Rejected due to AVS', $response['message']);
        $this->assertArrayHasKey('payment_information_uuid', $response['dvb_payment_response']);
        $this->assertArrayHasKey('customer_uuid', $response['dvb_payment_response']);
    }

    public function testMakePaymentWithAVSSuccess(): void
    {
        $this->mockAvsSuccessRequest();
        $this->validPayload['apply_avs_cvc_check'] = 'Force';
        $this->validPayload['billing_address']['postal_code'] = '10';
        $this->validPayload['billing_address']['address1'] = '100 ';

        $payment = new Payment();
        $payment->setPayload($this->validPayload);
        $response = $payment->paymentOrder();

        $this->assertArrayHasKey('response', $response);
        $this->assertArrayHasKey('success', $response);
        $this->assertArrayHasKey('amount', $response);
        $this->assertArrayHasKey('dvb_payment_response', $response);
        $this->assertTrue($response['success']);
        $this->assertFalse($response['dvb_payment_response']['avs_cvc_error']);
        $this->assertEquals('Matched', $response['avsHouseNumberResult']);
        $this->assertEquals('Matched', $response['avsPostcodeResult']);
    }

    /**
     * Test Secure(3DS Version 1) Payment request
     * @dataProvider getActiveFlagFor3dsVersion
     * @return  void
     */
    public function test3dsV1Payment($activeFlag): void
    {
        //Arrange
        if ($activeFlag) {
            factory(Settings::class)->create([
                'key' => '3ds_version',
                'value' => '1',
                'active' => $activeFlag,
            ]);
        } else {
            Config::set('payment.3ds_version', '1');
        }

        $this->mockGetSettings();
        $this->mockSecureV1PayemntRequest();
        $this->validPayload['card_details']['card_identifier'] = 'rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==';
        
        //Act
        $payment = new Payment();
        $payment->setPayload($this->validPayload);
        $response = $payment->paymentOrder();

        //Assertion
        $this->assertArrayHasKey('cardTokenId', $response);
        $this->assertArrayHasKey('cardSchemeName', $response);
        $this->assertEquals($response['success'], true);
        $this->assertEquals($response['cardTokenId'], $this->validPayload['card_details']['card_identifier']);
        $this->assertArrayHasKey('dvb_payment_response', $response);
        $this->assertArrayHasKey('transaction_type', $response['dvb_payment_response']);
        $this->assertArrayHasKey('is_3ds_initiated', $response['dvb_payment_response']);
        $this->assertArrayHasKey('3d_secure', $response['dvb_payment_response']);
        $this->assertArrayHasKey('pa_req', $response['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('acs_url', $response['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('term_url', $response['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('version', $response['dvb_payment_response']['3d_secure']);
        $this->assertEquals('1', $response['dvb_payment_response']['3d_secure']['version']);
        $this->assertArrayHasKey('md', $response['dvb_payment_response']['3d_secure']);
    }

    /**
     * Test Secure(3DS Version 2) Payment Request
     * @dataProvider getActiveFlagFor3dsVersion
     * @return  void
     */
    public function test3dsV2Payment($activeFlag): void
    {
        //Arrange
        if ($activeFlag) {
            factory(Settings::class)->create([
                'key' => '3ds_version',
                'value' => '2',
                'active' => $activeFlag,
            ]);
        } else {
            Config::set('payment.3ds_version', '2');
            Config::set('payment.3ds_notification_url', 'http://v4checkout-local.dividebuy.co.uk/sagePayRedirect.php');
        }

        $this->mockGetSettings();
        $this->mockSecureV2PayemntRequest();
        $this->validPayload['card_details']['card_identifier'] = 'rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==';
         
        //Act
        $payment = new Payment();
        $payment->setPayload($this->validPayload);
        $response = $payment->paymentOrder();
 
        //Assertion
        $this->assertArrayHasKey('cardTokenId', $response);
        $this->assertArrayHasKey('cardSchemeName', $response);
        $this->assertEquals($response['success'], true);
        $this->assertEquals($response['cardTokenId'], $this->validPayload['card_details']['card_identifier']);
        $this->assertArrayHasKey('dvb_payment_response', $response);
        $this->assertArrayHasKey('is_3ds_initiated', $response['dvb_payment_response']);
        $this->assertArrayHasKey('transaction_type', $response['dvb_payment_response']);
        $this->assertArrayHasKey('3d_secure', $response['dvb_payment_response']);
        $this->assertArrayHasKey('creq', $response['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('threeDS_session_data', $response['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('acs_url', $response['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('version', $response['dvb_payment_response']['3d_secure']);
        $this->assertEquals('2', $response['dvb_payment_response']['3d_secure']['version']);
    }

    public function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }

    /**
     * Get active flag for checking 3ds version override or not
     *
     * @return  array
     */
    public function getActiveFlagFor3dsVersion(): array
    {
        return [
            [
                'active' => 1,
            ],
            [
                'active' => 0,
            ],
        ];
    }
}
