<?php
namespace Modules\Payment\Tests\Unit\Gateway\Dna;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Response as HttpResponse;
use Illuminate\Support\Facades\Config;
use Illuminate\Validation\ValidationException;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Gateway\Dna\Repeat;
use Modules\Payment\Tests\Unit\DnaPaymentMockers;
use Modules\Payment\Tests\Unit\PaymentPayload;
use function PHPUnit\Framework\returnValue;
use SettingServiceClient;

use Tests\TestCase;

class RepeatPaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, DnaPaymentMockers;

    /**
     * Valid payload for payment request
     *
     * @var array
     */
    protected $validPayload;

    /**
     * Invalid payload for payment request
     *
     * @var array
     */
    protected $invalidPayload;

    /**
     * Invoice ID
     *
     * @var string
     */
    protected $invoiceId;

    /**
     * Setup payment payload
     *
     * @return  void
     */
    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'dna');

        $this->seed(AccountTypesTableSeeder::class);

        $this->invoiceId = "DNA-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '";
        $this->invalidPayload = $this->invalidPayloadPaymentByCardIdentifierDna($this->invoiceId);
    }

    public function test_should_return_validation_error_for_repeat_payment(): void
    {
        $this->expectException(ValidationException::class);

        $this->mockInvalidRepeatPaymentRequestWithExeption();
        $this->mockGetSettings();

        $payment = new Repeat();

        $repeatTransactionPayload = [
            'parentTransactionId' => 'foo',
            'transactionType' => 'SALE',
            'transaction' => [
                'transaction_id' => 'foo',
            ],
            'amount' => 0,
            'sequenceType' => 'recurring',
            'periodicType' => 'ucof',
            'invoiceId' => 'RECCCC_0001_rec_01',
        ];

        $payment->setPayload(array_merge($repeatTransactionPayload, $this->invalidPayload));
        $response = $payment->repeatOrder();

        self::assertArrayHasKey('message', $response);
        self::assertEquals($response['message'], 'Incorrect state of the parent transaction to perform the operation. Please check input');
    }

    public function callDeferredTransaction()
    {
        $this->mockSuccessPreAuthRequest();
        $response = $this->postJson('/api/payments/defer', $this->payloadDeferDna());

        $result = $response->decodeResponseJson();

        $response->assertStatus(HttpResponse::HTTP_OK);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);

        return $result;
    }

    public function testMakeRepeat(): void
    {
        $this->mockGetSettings();
        // Here only defer transaction is considered as parent transactio for repeat
        $deferResult = $this->callDeferredTransaction();

        $this->mockValidRepeatPaymentResponse();

        $repeat = new Repeat();
        $repeatPayload = array_merge($this->getRepeatPayload(), [
            'reference_transaction_uuid' => $deferResult['data']['uuid'],
            'transaction' => Transaction::uuid($deferResult['data']['uuid']),
            'vendor_tx_code' => $this->invoiceId,
        ]);
        $repeat->setPayload($repeatPayload);
        $response = $repeat->repeatOrder();

        $this->assertEquals($response['success'], true);
        $this->assertEquals($response['invoiceId'], $repeatPayload['vendor_tx_code']);
        $this->assertEquals($response['transactionType'], 'SALE');
        $this->assertArrayHasKey('parentTransactionId', $response);
    }

    public function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
