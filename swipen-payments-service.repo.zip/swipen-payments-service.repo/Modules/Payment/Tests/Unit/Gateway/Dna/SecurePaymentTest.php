<?php

namespace Modules\Payment\Tests\Unit\Gateway\Dna;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Config;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Tests\Unit\DnaPaymentMockers;
use Modules\Payment\Tests\Unit\PaymentPayload;
use Symfony\Component\HttpFoundation\Response as HttpFoundationResponse;
use Tests\TestCase;

class SecurePaymentTest extends TestCase
{
    use PaymentPayload, WithFaker, RefreshDatabase, DnaPaymentMockers;

    /**
     * Valid payload for payment request
     *
     * @var array
     */
    protected $payload;

    /**
     * Invoice ID
     *
     * @var string
     */
    protected $invoiceId;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'dna');
        $this->invoiceId = 'DNA-' . time();
        $this->payload = $this->payloadPaymentByCardIdentifierDna($this->invoiceId);
    }

    public function test3dsV1SecurePayment(): void
    {
        //Create Payment Request
        $this->mockSecureV1PayemntRequest();
        $payload = $this->payload;
        $payload['card_details']['card_identifier'] = 'rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==';
 
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();

        $response->assertStatus(HttpFoundationResponse::HTTP_OK);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('uuid', $result['data']);
        $this->assertEquals($payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('transaction_id', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('is_3ds_initiated', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('3d_secure', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('pa_req', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('acs_url', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('term_url', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('version', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']);
        $this->assertEquals('1', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']['version']);

        //Call Secure Payment API with valid transacion id
        $this->mockSecureV1PaymentConfirmationRequest();
        $payload = array_merge($this->get3dsV1Payload(), [
            'transaction_uuid' =>  $result['data']['uuid'],
        ]);


        $response = $this->postJson('/api/payments/secure-payment', $payload);
        $securePaymentResult = $response->decodeResponseJson();
        $response->assertStatus(HttpFoundationResponse::HTTP_OK);

        $this->assertArrayHasKey('transaction_response', $securePaymentResult['data']);
        $this->assertArrayHasKey('order_uuid', $securePaymentResult['data']);
        $this->assertArrayHasKey('vendor_tx_code', $securePaymentResult['data']);
        $this->assertArrayHasKey('transaction_type', $securePaymentResult['data']);
        $this->assertArrayHasKey('is_3ds_completed', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('status', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('status_details', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertTrue($securePaymentResult['data']['transaction_response']['success']);
        $this->assertTrue($securePaymentResult['data']['transaction_response']['dvb_payment_response']['is_3ds_completed']);
        $this->assertArrayHasKey('card_identifier', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('card_type', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
    }

    public function test3dsV2SecurePayment(): void
    {
        //Create Payment Request
        $this->mockSecureV2PayemntRequest();
        $payload = $this->payload;
        $payload['card_details']['card_identifier'] = 'rvM6gPXB7SH6JB0ZAQ26pUX5ijTwN5OBSZ+SpO9znDQfMQ==';
 
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();

        $response->assertStatus(HttpFoundationResponse::HTTP_OK);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('uuid', $result['data']);
        $this->assertEquals($payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('transaction_id', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('is_3ds_initiated', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('3d_secure', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('creq', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('threeDS_session_data', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('acs_url', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']);
        $this->assertArrayHasKey('version', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']);
        $this->assertEquals('2', $result['data']['transaction_response']['dvb_payment_response']['3d_secure']['version']);

        //Call Secure Payment API with valid transacion id
        $this->mockSecureV2PaymentConfirmationRequest();
        $payload = array_merge($this->get3dsV2Payload(), [
            'transaction_uuid' =>  $result['data']['uuid'],
        ]);

        $response = $this->postJson('/api/payments/secure-payment', $payload);
        $securePaymentResult = $response->decodeResponseJson();
        $response->assertStatus(HttpFoundationResponse::HTTP_OK);

        $this->assertArrayHasKey('transaction_response', $securePaymentResult['data']);
        $this->assertArrayHasKey('order_uuid', $securePaymentResult['data']);
        $this->assertArrayHasKey('vendor_tx_code', $securePaymentResult['data']);
        $this->assertArrayHasKey('transaction_type', $securePaymentResult['data']);
        $this->assertArrayHasKey('is_3ds_completed', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('status', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('status_details', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertTrue($securePaymentResult['data']['transaction_response']['success']);
        $this->assertTrue($securePaymentResult['data']['transaction_response']['dvb_payment_response']['is_3ds_completed']);
        $this->assertArrayHasKey('card_identifier', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
    }

    public function testInvalidTransactionIdForSecurePayment(): void
    {
        $this->mockSecureInvalidaTransactionRequest();
        $transaction = factory(Transaction::class)->create();

        $payload = array_merge($this->get3dsV1Payload(), [
            'transaction_uuid' => $transaction->uuid,
        ]);

        $response = $this->postJson('/api/payments/secure-payment', $payload);
        $result = $response->decodeResponseJson();

        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('success', $result['data']['transaction_response']);
        $this->assertArrayHasKey('message', $result['data']['transaction_response']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertFalse($result['data']['transaction_response']['success']);
        $this->assertEquals('Cannot find the transaction', $result['data']['transaction_response']['message']);
        $this->assertFalse($result['data']['transaction_response']['dvb_payment_response']['is_3ds_completed']);
    }

    public function testPaResOrCresValidation(): void
    {
        $transaction = factory(Transaction::class)->create();

        $payload = [
            'transaction_uuid' => $transaction->uuid,
            'customer_uuid' => $this->faker->uuid,
        ];
        
        $response = $this->postJson('/api/payments/secure-payment', $payload);
        $result = $response->decodeResponseJson();
        
        $response->assertStatus(HttpFoundationResponse::HTTP_UNPROCESSABLE_ENTITY);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('pa_res', $result['errors']);
        $this->assertArrayHasKey('cres', $result['errors']);
        $this->assertIsArray($result['errors']['pa_res']);
        $this->assertIsArray($result['errors']['cres']);
        $this->assertEquals('The pa res field is required when cres is not present.', $result['errors']['pa_res'][0]);
        $this->assertEquals('The cres field is required when pa res is not present.', $result['errors']['cres'][0]);
    }

    private function get3dsV1Payload()
    {
        return [
            'customer_uuid' => $this->faker->uuid,
            'transaction_uuid' => $this->faker->uuid,
            'pa_res' => base64_encode(implode('-', $this->faker->words())),
        ];
    }

    private function get3dsV2Payload()
    {
        return [
            'customer_uuid' => $this->faker->uuid,
            'transaction_uuid' => $this->faker->uuid,
            'cres' => base64_encode(implode('-', $this->faker->words())),
        ];
    }
}
