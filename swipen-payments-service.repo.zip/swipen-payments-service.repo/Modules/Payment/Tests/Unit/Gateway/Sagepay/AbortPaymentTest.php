<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Config;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Tests\Unit\PaymentAssertConfig;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class AbortPaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, WithFaker, PaymentAssertConfig;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->paymentAssertConfig = $this->getPaymentChannelConfig($this->paymentChannel);
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function test_should_be_able_to_make_payment_and_abort_generated_transaction()
    {
        $deferPayload = $this->payloadDeferForTelePhoneOrder();
        $deferPayload['apply_avs_cvc_check'] = 'Disable';
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/defer', $deferPayload);

        $result = $response->json();

        $transactionId = $result['data']['uuid'];

        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);
        $this->assertEquals('The Authorisation was Successful.', $result['data']['transaction_response']['statusDetail']);

        $response = $this->postJson('/api/payments/abort', [
            'customer_uuid' => $this->faker->uuid,
            'transaction_uuid' => $transactionId,
        ]);

        $result = $response->json();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('parent_uuid', $result['data']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('instructionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('date', $result['data']['transaction_response']);
        $this->assertArrayHasKey('is_successful', $result['data']);
        $this->assertEquals('abort', $result['data']['transaction_response']['instructionType']);
        $this->assertEquals($transactionId, $result['data']['parent_uuid']);
        $this->assertEquals($deferPayload['order_uuid'], $result['data']['order_uuid']);
    }

    public function test_should_error_on_multiple_abort()
    {
        $payload = $this->payloadDeferForTelePhoneOrder();
        $payload['apply_avs_cvc_check'] = 'Disable';
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/defer', $payload);

        $result = $response->json();

        $transactionId = $result['data']['uuid'];

        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);

        $response = $this->postJson('/api/payments/abort', [
            'customer_uuid' => $this->faker->uuid,
            'transaction_uuid' => $transactionId,
        ]);

        $response->assertStatus(201);

        $response = $this->postJson('/api/payments/abort', [
            'customer_uuid' => $this->faker->uuid,
            'transaction_uuid' => $transactionId,
        ]);

        $result = $response->json();

        // Sagepay throwing either a 403 or 404 :(
        $this->assertTrue($response->isClientError());
        $this->assertArrayHasKey('message', $result);
        $this->assertContains($result['message'], [
            'Transaction status not applicable',
            'Transaction not found',
        ]);
    }

    public function test_should_404_on_invalid_transaction_id()
    {
        $transaction = factory(Transaction::class)->create();

        $payload = array_merge($this->getPayload(), [
            'transaction_uuid' => $transaction->uuid,
        ]);

        $response = $this->postJson('/api/payments/abort', $payload);

        $result = $response->json();

        $response->assertStatus(404);
        $this->assertArrayHasKey('message', $result);
        $this->assertEquals('Transaction not found', $result['message']);
        $this->assertDatabaseHas('transaction_error_logs', [
            'transaction_type'       => 'Abort',
            'error_description' =>  'Transaction not found',
        ]);
    }

    /**
     * @dataProvider abortPaymentRequestProvider
     */
    public function test_should_return_validation_errors_on_invalid_data($exceptionMessage, $dataCallback)
    {
        $transaction = factory(Transaction::class)->create();

        $payload = $dataCallback($this->getPayload());

        // An existing uuid is required so inject it if key present
        if (isset($payload['transaction_uuid'])) {
            $payload = array_merge($payload, [
                'transaction_uuid' => $transaction->uuid,
            ]);
        }

        $response = $this->postJson('/api/payments/abort', $payload);

        $result = $response->json();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals($exceptionMessage, $result['message']);
    }

    /**
     * @return array
     */
    public function abortPaymentRequestProvider()
    {
        return [
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['transaction_uuid']);

                return $payload;
            }],
        ];
    }

    /**
     * Get payload.
     *
     * @return array
     */
    private function getPayload()
    {
        return [
            'customer_uuid' => $this->faker->uuid,
            'transaction_uuid' => $this->faker->uuid,
        ];
    }

    public function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
