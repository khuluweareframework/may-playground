<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Modules\Payment\Tests\Unit\PaymentAssertConfig;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class CardAuthorizationTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, PaymentAssertConfig;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->paymentAssertConfig = $this->getPaymentChannelConfig($this->paymentChannel);
    }

    public function test_should_receive_card_identifier(): void
    {
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/card-identifier', $this->cardDetailsPayload());

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('cardIdentifier', $result['data']);
        $this->assertArrayHasKey('expiry', $result['data']);
        $this->assertArrayHasKey('cardType', $result['data']);

        $this->assertDatabaseHas('stored_events', [
            'event_class' => \Modules\Payment\Events\CardIdentifierCreated::class,
        ]);
    }

    public function test_should_error_on_invalid_card(): void
    {
        $this->mockGetSettings();
        $payload = array_replace_recursive(
            $this->cardDetailsPayload(),
            ['card_details' => ['card_number' => '4462000000000000']]
        );

        $response = $this->postJson('/api/payments/card-identifier', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
    }

    /**
     * @dataProvider cardAuthorizationRequestProvider
     */
    public function test_should_return_validation_errors_on_invalid_data($exceptionMessage, $dataCallback): void
    {
        $payload = $dataCallback($this->cardDetailsPayload());
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/card-identifier', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals($exceptionMessage, $result['message']);
    }

    /**
     * @return array
     */
    public function cardAuthorizationRequestProvider()
    {
        return [
            ['The given data was invalid.', function ($payload) {
                unset($payload['card_details']['cardholder_name']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['card_details']['card_number']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['card_details']['expiry_date']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['card_details']['security_code']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['cardholder_name' => '']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['expiry_date' => '']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['security_code' => '']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['cardholder_name' => 'This name is going to be more than 45 characters long']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '49290000000064929000000006']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['expiry_date' => '07200720']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['security_code' => '9999']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '4917300000000000']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '5404000000000000']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '4462000000000000']]);
            }],
            ['The given data was invalid.', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '5404000000000040']]);
            }],
        ];
    }

    /**
     * @dataProvider sagePayTestCardsProvider
     */
    public function test_should_return_response_on_valid_card_numbers($message, $dataCallback): void
    {
        $payload = $dataCallback($this->cardDetailsPayload());
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/card-identifier', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
    }

    /**
     * @return array
     */
    public function sagePayTestCardsProvider()
    {
        return [
            ['Created', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '4929000005559']]);
            }],
            ['Created', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '4929000000014']]);
            }],
            ['Created', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '4929000000022']]);
            }],
            ['Created', function ($payload) {
                return array_replace_recursive($payload, ['card_details' => ['card_number' => '4484000000002']]);
            }],
        ];
    }

    public function test_should_receive_sagepay_error_on_invalid_expiry_date(): void
    {
        $payload = array_replace_recursive(
            $this->cardDetailsPayload(),
            ['card_details' => ['expiry_date' => '0710']]
        );

        $response = $this->postJson('/api/payments/card-identifier', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals('The given data was invalid.', $result['message']);
        $this->assertContains('The card details.expiry date must be in the future.', $result['errors']['card_details.expiry_date']);
    }

    public function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
