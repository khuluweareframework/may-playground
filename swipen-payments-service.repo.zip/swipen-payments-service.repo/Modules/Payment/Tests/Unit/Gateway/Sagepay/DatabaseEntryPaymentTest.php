<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class DatabaseEntryPaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase;

    protected $payload;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
        $this->payload = $this->payloadPayment();
        $this->mockGetSettings();
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function test_should_be_able_to_add_payment_to_database()
    {
        $postData = $this->payload['apply_3d_secure'] == 'Disable' ? array_merge([   'account_type_uuid' => 'c427c6c3-82c5-4d31-8152-b36507db3352'], $this->payload) : $this->payload;
        $response = $this->postJson('/api/payments/pay', $postData);
       
        $response->assertStatus(201)
            ->assertJsonStructure([
                'data',
                'links',
            ]);
    }

    private function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
