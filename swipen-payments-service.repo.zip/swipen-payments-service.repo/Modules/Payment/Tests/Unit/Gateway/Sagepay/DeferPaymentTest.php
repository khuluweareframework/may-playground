<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Mockery;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Database\Seeders\PaymentServiceSettingsSeeder;
use Modules\Payment\Entities\AccountType;
use Modules\Payment\Entities\Settings;
use Modules\Payment\Http\Requests\ClientRequestHandler;
use Modules\Payment\Tests\Unit\PaymentAssertConfig;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class DeferPaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, PaymentAssertConfig;

    protected $payload;

    protected $paymentChannel;
   
    protected $paymentAssertConfig;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->paymentAssertConfig = $this->getPaymentChannelConfig($this->paymentChannel);
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function test_should_be_able_to_make_payment(): void
    {
        $this->mockGetSettings();
        $this->payloadDeferForTelePhoneOrder['apply_avs_cvc_check'] = 'Disable';
        
        $response = $this->postJson('/api/payments/defer', $this->payloadDeferForTelePhoneOrder);

        $result = $response->decodeResponseJson();

        $assertConfig = $this->paymentAssertConfig;
        $response->assertStatus($assertConfig['defer']['success_code']);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payloadDeferForTelePhoneOrder['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payloadDeferForTelePhoneOrder['vendor_tx_code'], $result['data']['vendor_tx_code']);
        
        $dvb_payment_response = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('transaction_type', $dvb_payment_response);
        $this->assertArrayHasKey('status_details', $dvb_payment_response);
        $this->assertEquals($assertConfig['defer']['transaction_type'], $dvb_payment_response['transaction_type']);
        $this->assertEquals($assertConfig['defer']['success_description'], $dvb_payment_response['status_details']);
        $this->assertFalse($dvb_payment_response['is_3ds_initiated']);
    }

    public function test_should_be_able_to_make_secure_defer_payment(): void
    {
        $this->mockGetSettings();
        $payload = array_replace_recursive(
            $this->payload,
            ['apply_3d_secure' => 'Force']
        );

        $response = $this->postJson('/api/payments/defer', $payload);
        $result = $response->decodeResponseJson();
        
        $assertConfig = $this->paymentAssertConfig;
        $response->assertStatus($assertConfig['defer']['secure_success_code']);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);

        $dvb_payment_response = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('transactionId', $result['data']['transaction_response']);
        $this->assertArrayHasKey('status', $result['data']['transaction_response']);
        $this->assertEquals($assertConfig['defer']['secure_success_description'], $dvb_payment_response['status_details']);
        $this->assertEquals($assertConfig['defer']['secure_status'], $dvb_payment_response['status']);
    }

    public function test_should_error_on_duplicate_tx_code(): void
    {
        $this->payloadDeferForTelePhoneOrder['apply_avs_cvc_check'] = 'Disable';
        $this->mockGetSettings();
        $vendor_tx_code = 'SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999);
        $payload = array_replace_recursive(
            $this->payloadDeferForTelePhoneOrder,
            ['vendor_tx_code' => $vendor_tx_code]
        );

        $this->postJson('/api/payments/defer', $payload);

        $response = $this->postJson('/api/payments/defer', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('vendor_tx_code', $result['errors']);
        $this->assertContains('The VendorTxCode has been used before.  All VendorTxCodes should be unique.', $result['errors']['vendor_tx_code']);
    }

    public function test_should_be_able_to_error_on_zero_payment(): void
    {
        $this->mockGetSettings();
        $payload = array_merge($this->payloadDeferForTelePhoneOrder, [
            'amount' => 0,
        ]);

        $response = $this->postJson('/api/payments/defer', $payload);

        $result = $response->decodeResponseJson();
        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('amount', $result['errors']);
        $this->assertContains('The Amount including surcharge is outside the allowed range.', $result['errors']['amount']);
    }

    public function test_should_error_on_invalid_card(): void
    {
        $this->mockGetSettings();
        $payload = array_replace_recursive(
            $this->payload,
            ['card_details' => ['security_code' => '12x']]
        );

        $response = $this->postJson('/api/payments/defer', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('card_details.security_code', $result['errors']);
        $this->assertContains('The security code must contain only digits', $result['errors']['card_details.security_code']);
    }

    /**
     * @dataProvider deferPaymentRequestProvider
     */
    public function test_should_return_validation_errors_on_invalid_data($exceptionMessage, $dataCallback): void
    {
        $payload = $dataCallback($this->payload);

        $response = $this->postJson('/api/payments/defer', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals($exceptionMessage, $result['message']);
    }

    public function test_payment_with_account_type_uuid()
    {
        $acountType = AccountType::whereCode('M')->first();
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/defer', array_merge($this->payload, [
            'account_type_uuid' => $acountType->uuid,
        ]));

        $response
            ->assertCreated()
            ->assertJson([
                'data' => [
                    'account_type_uuid' => $acountType->uuid,
                ],
            ]);
    }

    public function test_able_to_defer_payment_with_3d_secure_disabled()
    {
        $assertConfig = $this->paymentAssertConfig;
        $this->seed(PaymentServiceSettingsSeeder::class);
        // Assuming the settings is activated
        Settings::where('key', 'apply_3d_secure')
                ->update(['active' => 1, 'value' => 'Force']);
       
        $payload = array_replace_recursive(
            $this->payload,
            ['apply_3d_secure' => 'Force']
        );
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/defer', $payload);

        $result = $response->decodeResponseJson();
        $response->assertStatus($assertConfig['defer']['secure_success_code']);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);

        $dvb_payment_response = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('transaction_type', $dvb_payment_response);
        $this->assertArrayHasKey('transaction_id', $dvb_payment_response);
        $this->assertArrayHasKey('status', $dvb_payment_response);
        $this->assertEquals($assertConfig['defer']['secure_success_description'], $dvb_payment_response['status_details']);
        $this->assertEquals($assertConfig['defer']['secure_status'], $dvb_payment_response['status']);
    }

    public function test_should_be_able_to_fail_avs_defer_payment(): void
    {
        $this->mockGetSettings();
        $payload = array_replace_recursive(
            $this->payloadDeferForTelePhoneOrder,
            ['apply_avs_cvc_check' => 'Force']
        );

        $response = $this->postJson('/api/payments/defer', $payload);
        $result = $response->decodeResponseJson();
        $assertConfig = $this->paymentAssertConfig;
        $response->assertStatus($assertConfig['defer']['success_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('avs_cvc_error', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertEquals($result['data']['is_successful'], false);
        $this->assertTrue($result['data']['transaction_response']['dvb_payment_response']['avs_cvc_error']);
    }

    public function test_should_be_able_to_make_payment_with_long_address1(): void
    {
        $this->mockGetSettings();
        $this->payloadDeferForTelePhoneOrder['apply_avs_cvc_check'] = 'Disable';
        $this->payloadDeferForTelePhoneOrder['billing_address']['address1'] = 'FLAT 20 Donegal House, Cambridge Heath Road, LONDON, GREATER LONDON';
        $response = $this->postJson('/api/payments/defer', $this->payloadDeferForTelePhoneOrder);

        $result = $response->decodeResponseJson();

        $assertConfig = $this->paymentAssertConfig;
        $response->assertStatus($assertConfig['defer']['success_code']);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payloadDeferForTelePhoneOrder['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payloadDeferForTelePhoneOrder['vendor_tx_code'], $result['data']['vendor_tx_code']);
        
        $dvb_payment_response = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('transaction_type', $dvb_payment_response);
        $this->assertArrayHasKey('status_details', $dvb_payment_response);
        $this->assertEquals($assertConfig['defer']['transaction_type'], $dvb_payment_response['transaction_type']);
        $this->assertEquals($assertConfig['defer']['success_description'], $dvb_payment_response['status_details']);
    }

    public function test_able_to_defer_payment_with_3ds2(): void
    {
        $payload = array_merge($this->payload, [
            'custom_user_settings' => [
                'browser_ip' => $this->faker->ipv4,
                'website' => $this->faker->url,
            ],
        ]);
        $payload = array_replace_recursive(
            $payload,
            ['apply_3d_secure' => 'Force']
        );
        Config::set('payment.3ds_version', '2');
        Config::set('payment.3ds_notification_url', 'http://v4checkout-local.dividebuy.co.uk/sagePayRedirect.php');

        // Mock call
        $this->mockGetSettings();
        $this->mock3dSecureV2PaymentIntiated();
        
        $response = $this->postJson('/api/payments/defer', $payload);
        $result = $response->decodeResponseJson();
      
        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);

        $dvb_payment_response = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('status', $dvb_payment_response);
        $this->assertArrayHasKey('transaction_id', $dvb_payment_response);
        $this->assertArrayHasKey('status_details', $dvb_payment_response);
        $this->assertEquals('Please redirect your customer to the ACSURL to complete the 3DS Transaction', $dvb_payment_response['status_details']);
        $this->assertEquals('3DAuth', $dvb_payment_response['status']);
        $this->assertArrayHasKey('is_3ds_initiated', $dvb_payment_response);
        $this->assertArrayHasKey('3d_secure', $dvb_payment_response);
        $threeDS = $dvb_payment_response['3d_secure'];
        $this->assertArrayHasKey('creq', $threeDS);
        $this->assertArrayHasKey('threeDS_session_data', $threeDS);
        $this->assertArrayHasKey('acs_url', $threeDS);
        $this->assertArrayHasKey('version', $threeDS);
        $this->assertEquals('2', $threeDS['version']);
    }

    /**
     * Test Payment with AVS/CSC DB Override values
     *
     * @dataProvider avsCscOverrideValues
     * @return  void
     */
    public function test_should_be_able_to_success_avs_payment($postCode, $houseNumber, $csc): void
    {
        factory(Settings::class)->create($postCode);
        factory(Settings::class)->create($houseNumber);
        factory(Settings::class)->create($csc);

        $this->mockGetSettings();
        $payload = array_replace_recursive(
            $this->payloadDeferForTelePhoneOrder,
            [
                'apply_avs_cvc_check' => 'Force',
            ]
        );
        
        $response = $this->postJson('/api/payments/defer', $payload);
        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payloadDeferForTelePhoneOrder['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payloadDeferForTelePhoneOrder['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('avs_cvc_error', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertFalse($result['data']['transaction_response']['dvb_payment_response']['avs_cvc_error']);
        $this->assertArrayHasKey('avsCvcCheck', $result['data']['transaction_response']);
        $this->assertArrayHasKey('address', $result['data']['transaction_response']['avsCvcCheck']);
        $this->assertArrayHasKey('postalCode', $result['data']['transaction_response']['avsCvcCheck']);
        $this->assertArrayHasKey('securityCode', $result['data']['transaction_response']['avsCvcCheck']);

        if ($postCode['value'] === '412') {
            $this->assertEquals('Matched', $result['data']['transaction_response']['avsCvcCheck']['postalCode']);
        }
        if ($houseNumber['value'] === '88') {
            $this->assertEquals('Matched', $result['data']['transaction_response']['avsCvcCheck']['address']);
        }
        if ($houseNumber['value'] === '123') {
            $this->assertEquals('Matched', $result['data']['transaction_response']['avsCvcCheck']['securityCode']);
        }
    }

    /**
     * @dataProvider threeeDsOverrideValues
     * @return  void
     */
    public function test_should_be_able_oveeride_3ds_value_from_database($data): void
    {
        factory(Settings::class)->create($data);

        $this->mockGetSettings();
        $postData = $data['value'] == 'Disable' ? $this->payloadDeferForTelePhoneOrder : $this->payload;

        $response = $this->postJson('/api/payments/defer', $postData);
        $result = $response->decodeResponseJson();

        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($postData['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($postData['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('status', $result['data']['transaction_response']);
        $this->assertDatabaseHas('settings', $data);
        
        //Assetion for disable
        if ($data['value'] === 'Disable') {
            $this->assertArrayHasKey('3DSecure', $result['data']['transaction_response']);
            $this->assertArrayHasKey('status', $result['data']['transaction_response']['3DSecure']);
            $this->assertEquals('NotChecked', $result['data']['transaction_response']['3DSecure']['status']);
        }

        //Assertion for enabled
        if ($data['value'] === 'Force') {
            $this->assertEquals('3DAuth', $result['data']['transaction_response']['status']);
            $this->assertArrayHasKey('is_3ds_initiated', $result['data']['transaction_response']['dvb_payment_response']);
        }
    }

    public function test_should_be_able_to_check_skip_deferred(): void
    {
        factory(Settings::class)->create([
            'key' => 'skip_deferred',
            'value' => 'ENABLE',
            'active' => 1,
        ]);
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/defer', $this->payload);
        $result = $response->decodeResponseJson();
        
        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('cardIdentifier', $result['data']);
        $this->assertArrayHasKey('expiry', $result['data']);
        $this->assertArrayHasKey('cardType', $result['data']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);

        $dvbResponse = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('card_identifier', $dvbResponse);
        $this->assertArrayHasKey('card_type', $dvbResponse);
        $this->assertArrayHasKey('merchant_session_key', $dvbResponse);
        $this->assertArrayHasKey('merchant_session_expiry', $dvbResponse);
        $this->assertArrayHasKey('skip_deferred', $dvbResponse);

        $this->assertDatabaseHas('stored_events', [
            'event_class' => \Modules\Payment\Events\CardIdentifierCreated::class,
        ]);
    }

    /**
     * Test to check that 3ds defer is initiated
     * on 'Enable' skip defer
     */
    public function test_should_initiate_3ds_defer_on_skip_defer(): void
    {
        factory(Settings::class)->create([
            'key' => 'skip_deferred',
            'value' => 'ENABLE',
            'active' => 1,
        ]);

        Config::set('payment.3ds_version', '2');
        Config::set('payment.3ds_notification_url', 'http://v4checkout-local.dividebuy.co.uk/sagePayRedirect.php');

        $payload = array_merge($this->payload, [
            'custom_user_settings' => [
                'browser_ip' => $this->faker->ipv4,
                'website' => $this->faker->url,
                'is_force_deferred' => true,
            ],
        ]);

        // Mock call
        $this->mockGetSettings();
        $this->mock3dSecureV2PaymentIntiated();
        
        $response = $this->postJson('/api/payments/defer', $payload);
        $result = $response->decodeResponseJson();

        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);

        $dvb_payment_response = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('status', $dvb_payment_response);
        $this->assertArrayHasKey('transaction_id', $dvb_payment_response);
        $this->assertArrayHasKey('status_details', $dvb_payment_response);
        $this->assertEquals('Please redirect your customer to the ACSURL to complete the 3DS Transaction', $dvb_payment_response['status_details']);
        $this->assertEquals('3DAuth', $dvb_payment_response['status']);
        $this->assertArrayHasKey('is_3ds_initiated', $dvb_payment_response);
        $this->assertArrayHasKey('3d_secure', $dvb_payment_response);
        $threeDS = $dvb_payment_response['3d_secure'];
        $this->assertArrayHasKey('creq', $threeDS);
        $this->assertArrayHasKey('threeDS_session_data', $threeDS);
        $this->assertArrayHasKey('acs_url', $threeDS);
        $this->assertArrayHasKey('version', $threeDS);
        $this->assertEquals('2', $threeDS['version']);
    }

    /**
     * @return array
     */
    public function deferPaymentRequestProvider()
    {
        return [
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['card_details']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['vendor_tx_code']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['amount']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['currency']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['description']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['apply_3d_secure']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['apply_avs_cvc_check']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_first_name']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_last_name']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['billing_address']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['account_type_uuid'] = 'xxx';

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['description'] = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.';

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['customer_first_name'] = 'Hubert Blaine Wolfeschlegelsteinhausenbergerdorff Sr.';

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['customer_last_name'] = 'Hubert Blaine Wolfeschlegelsteinhausenbergerdorff Sr.';

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['customer_email'] = 'HuberBlaineWolfLorem Ipsum is simply dummy text of the printing and typesetting industry.';

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['customer_phone'] = '798659631254789548562';

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['billing_address']['city'] = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.';

                return $payload;
            }],
        ];
    }

    public function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }

    /**
     * Get AVS and CSC parameter with value
     *
     * @return  array
     */
    public function avsCscOverrideValues(): array
    {
        return [
            [
                [
                    'key' => 'sagepay_postcode_override',
                    'value' => '412',
                    'active' => 1,
                ],
                [
                    'key' => 'sagepay_house_number_override',
                    'value' => '88',
                    'active' => 1,
                ],
                [
                    'key' => 'sagepay_csc_override',
                    'value' => '123',
                    'active' => 1,
                ],
            ],
        ];
    }

    /**
     * @return  array
     */
    public function threeeDsOverrideValues(): array
    {
        return [
            [
                [
                    'key' => 'apply_3d_secure',
                    'value' => 'Disable',
                    'active' => 1,
                ],
            ],
            [
                [
                    'key' => 'apply_3d_secure',
                    'value' => 'Force',
                    'active' => 1,
                ],
            ],
        ];
    }
    
    public function mock3dSecureV2PaymentIntiated()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);
            $this->mockCardIdentifierRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) {
                        return isset($argument['strongCustomerAuthentication']) && isset($argument['credentialType']);
                    })
                )
                ->andReturn(new Response(202, [], '{
                    "cReq": "ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICI0ODNhNzljNy04YjcyLTQwY2MtYWVhMy01NDAxOTY5ZWFhNzAiLAogICJhY3NUcmFuc0lEIiA6ICJjNjk2YTAzYy03NDUxLTQxY2YtYTQyNC1jMWY4N2I3YWJmNjEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwMiIKfQ",
                    "acsUrl": "https://test.sagepay.com/3ds-simulator/html_challenge",
                    "status": "3DAuth",
                    "response": {
                        "statusCode": 202
                    },
                    "dsTransId": "953fe05a-0564-4ecb-b4d2-c5a98cd87b9d",
                    "acsTransId": "c696a03c-7451-41cf-a424-c1f87b7abf61",
                    "statusCode": "2021",
                    "statusDetail": "Please redirect your customer to the ACSURL to complete the 3DS Transaction",
                    "transactionId": "099FFD93-F059-6DEE-FE5E-04ABCE95FEAF",
                    "dvb_payment_response": {
                        "status": "3DAuth",
                        "success": true,
                        "3d_secure": {
                            "creq": "ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICI0ODNhNzljNy04YjcyLTQwY2MtYWVhMy01NDAxOTY5ZWFhNzAiLAogICJhY3NUcmFuc0lEIiA6ICJjNjk2YTAzYy03NDUxLTQxY2YtYTQyNC1jMWY4N2I3YWJmNjEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwMiIKfQ",
                            "acs_url": "https://test.sagepay.com/3ds-simulator/html_challenge",
                            "version": "2",
                            "threeDS_session_data": "MDk5RkZEOTMtRjA1OS02REVFLUZFNUUtMDRBQkNFOTVGRUFG"
                        },
                        "card_type": null,
                        "avs_cvc_error": false,
                        "status_details": "Please redirect your customer to the ACSURL to complete the 3DS Transaction",
                        "transaction_id": "099FFD93-F059-6DEE-FE5E-04ABCE95FEAF",
                        "card_identifier": null,
                        "payment_channel": "sagepay",
                        "is_3ds_initiated": true,
                        "transaction_type": "Defer-3dSecure"
                    }
                }'));
        }));
    }

    private function mockAuthRequest($mock)
    {
        $mock->shouldReceive('makeRequest')
            ->andReturn(new Response(200, [], '{"expiry":"2022-01-21T08:36:34.425Z","merchantSessionKey":"7C26D5E2-5B1E-43AE-AC5D-283357FE2CCB"}'))->byDefault();
    }

    private function mockCardIdentifierRequest($mock)
    {
        $mock->shouldReceive('processRequest')
            ->andReturn(new Response(200, [], '{"cardIdentifier":"1C387A00-B226-408B-825A-EBEC610CB022","expiry":"2022-01-21T08:45:30.197Z","cardType":"Visa"}'));
    }
}
