<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Mockery;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Entities\AccountType;
use Modules\Payment\Entities\Settings;
use Modules\Payment\Http\Requests\ClientRequestHandler;
use Modules\Payment\Tests\Unit\PaymentAssertConfig;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class PaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, PaymentAssertConfig;

    protected $payload;

    protected $securePayload;

    protected $payloadInvalidPreDefinedValues;

    protected $duplicateTxCodePayload;

    protected $paymentByCardIdentifier;

    protected $cardIdentifier;

    protected function setUp(): void
    {
        parent::setUp();

        $this->payload = $this->payloadPayment();
        $this->duplicateTxCodePayload = $this->duplicateTxCodePayload();
        $this->payloadInvalidPreDefinedValues = $this->payloadPaymentInvalidPredefinedValues();
        $this->securePayload = $this->securePayloadPayment();
        $this->paymentByCardIdentifier = $this->payloadPaymentByCardIdentifier();
        $this->mockGetSettings();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->paymentAssertConfig = $this->getPaymentChannelConfig($this->paymentChannel);
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function test_should_be_able_to_make_payment(): void
    {
        $this->mockGetSettings();

        $postData = $this->payload['apply_3d_secure'] == 'Disable' ? array_merge([   'account_type_uuid' => 'c427c6c3-82c5-4d31-8152-b36507db3352'], $this->payload) : $this->payload;

        $response = $this->postJson('/api/payments/pay', $postData);

        $result = $response->decodeResponseJson();
        $this->cardIdentifier = $result['data']['transaction_response']['paymentMethod']['card']['cardIdentifier'];

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertFalse($result['data']['transaction_response']['dvb_payment_response']['is_3ds_initiated']);
        $this->assertArrayHasKey('skip_deferred', $result['data']['transaction_response']['dvb_payment_response']);
    }

    public function test_should_error_on_duplicate_tx_code(): void
    {
        $this->mockGetSettings();
        $postData = $this->payload['apply_3d_secure'] == 'Disable' ? array_merge([   'account_type_uuid' => 'c427c6c3-82c5-4d31-8152-b36507db3352'], $this->duplicateTxCodePayload) : $this->duplicateTxCodePayload;

        $this->postJson('/api/payments/pay', $postData);

        $response = $this->postJson('/api/payments/pay', $postData);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('vendor_tx_code', $result['errors']);
        $this->assertContains('The VendorTxCode has been used before.  All VendorTxCodes should be unique.', $result['errors']['vendor_tx_code']);
        $this->assertDatabaseHas('transaction_error_logs', [
            'error_description' => 'The VendorTxCode has been used before.  All VendorTxCodes should be unique.',
        ]);
    }

    public function test_should_error_on_invalid_card(): void
    {
        $payload = array_replace_recursive(
            $this->payload,
            ['card_details' => ['security_code' => '12x']]
        );
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/pay', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('card_details.security_code', $result['errors']);
        $this->assertContains('The security code must contain only digits', $result['errors']['card_details.security_code']);
        $this->assertDatabaseHas('transaction_error_logs', [
            'error_description' => 'The security code must contain only digits',
        ]);
    }

    public function test_should_be_able_to_make_secure_payment(): void
    {
        Config::set('payment.3ds_version', '1');
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/pay', $this->securePayload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('transactionId', $result['data']['transaction_response']);
        $this->assertArrayHasKey('status', $result['data']['transaction_response']);
        $this->assertArrayHasKey('acsUrl', $result['data']['transaction_response']);
        $this->assertArrayHasKey('paReq', $result['data']['transaction_response']);
        $this->assertEquals('Please redirect your customer to the ACSURL to complete the 3DS Transaction', $result['data']['transaction_response']['statusDetail']);
        $this->assertEquals('3DAuth', $result['data']['transaction_response']['status']);
        $this->assertArrayHasKey('transaction_type', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('is_3ds_initiated', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('3d_secure', $result['data']['transaction_response']['dvb_payment_response']);
        $threeDS = $result['data']['transaction_response']['dvb_payment_response']['3d_secure'];
        $this->assertArrayHasKey('pa_req', $threeDS);
        $this->assertArrayHasKey('acs_url', $threeDS);
        $this->assertArrayHasKey('md', $threeDS);
        $this->assertArrayHasKey('version', $threeDS);
        $this->assertEquals('1', $threeDS['version']);
    }

    /**
     * @dataProvider payPaymentRequestProvider
     */
    public function test_should_return_validation_errors_on_invalid_data($exceptionMessage, $dataCallback): void
    {
        $payload = $dataCallback($this->payload);

        $response = $this->postJson('/api/payments/pay', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals($exceptionMessage, $result['message']);
    }

    public function test_should_be_able_to_make_payment_by_card_identifier(): void
    {
        Config::set('payment.3ds_version', '1');
        $this->mockGetSettings();
        $postData = $this->paymentByCardIdentifier['apply_3d_secure'] == 'Disable' ? array_merge(['account_type_uuid' => 'c427c6c3-82c5-4d31-8152-b36507db3351'], $this->paymentByCardIdentifier) : $this->paymentByCardIdentifier;
        $this->mock3dSecureV1PaymentIntiated();
        
        $response = $this->postJson('/api/payments/pay', $postData);

        $result = $response->decodeResponseJson();

        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
    }

    public function test_makes_payment_with_account_type_uuid()
    {
        $acountType = AccountType::whereCode('M')->first();

        $this->mock(ClientRequestHandler::class, function ($mock) use ($acountType) {
            $mock
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) use ($acountType) {
                        return $argument['entryMethod'] === $acountType->entry_method;
                    })
                )
                ->andReturn(new Response(201, [], '{"statusCode":"0000","statusDetail":"The Authorisation was Successful.","transactionId":"87BE5864-E70C-8BA8-BAD7-C71E2BB83F62","transactionType":"Payment","retrievalReference":9285285,"bankResponseCode":"00","bankAuthorisationCode":"999777","paymentMethod":{"card":{"cardType":"Visa","lastFourDigits":"0014","expiryDate":"0421","cardIdentifier":"F50FD7FE-7E42-444B-868B-730575CAED6C","reusable":true}},"amount":{"totalAmount":1000,"saleAmount":1000,"surchargeAmount":0},"currency":"GBP","status":"Ok","avsCvcCheck":{"status":"NotChecked","address":"NotProvided","postalCode":"NotProvided","securityCode":"NotProvided"},"3DSecure":{"status":"IssuerNotEnrolled"}}'));
        });

        $response = $this->postJson('/api/payments/pay', array_merge($this->paymentByCardIdentifier, [
            'account_type_uuid' => $acountType->uuid,
        ]));

        $response
            ->assertCreated()
            ->assertJson([
                'data' => [
                    'account_type_uuid' => $acountType->uuid,
                ],
            ]);
    }

    public function test_makes_payment_with_entry_method()
    {
        $this->mock(ClientRequestHandler::class, function ($mock) {
            $mock
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) {
                        return $argument['entryMethod'] === 'TelephoneOrder';
                    })
                )
                ->andReturn(new Response(201, [], '{"statusCode":"0000","statusDetail":"The Authorisation was Successful.","transactionId":"87BE5864-E70C-8BA8-BAD7-C71E2BB83F62","transactionType":"Payment","retrievalReference":9285285,"bankResponseCode":"00","bankAuthorisationCode":"999777","paymentMethod":{"card":{"cardType":"Visa","lastFourDigits":"0014","expiryDate":"0421","cardIdentifier":"F50FD7FE-7E42-444B-868B-730575CAED6C","reusable":true}},"amount":{"totalAmount":1000,"saleAmount":1000,"surchargeAmount":0},"currency":"GBP","status":"Ok","avsCvcCheck":{"status":"NotChecked","address":"NotProvided","postalCode":"NotProvided","securityCode":"NotProvided"},"3DSecure":{"status":"IssuerNotEnrolled"}}'));
        });

        $response = $this->postJson('/api/payments/pay', array_merge($this->paymentByCardIdentifier, [
            'entry_method' => 'TelephoneOrder',
        ]));

        $response
            ->assertCreated()
            ->assertJson([
                'data' => [
                    'account_type_uuid' => null,
                ],
            ]);
    }

    public function test_makes_payment_with_default_entry_method()
    {
        $this->mock(ClientRequestHandler::class, function ($mock) {
            $mock
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) {
                        return $argument['entryMethod'] === 'Ecommerce';
                    })
                )
                ->andReturn(new Response(201, [], '{"statusCode":"0000","statusDetail":"The Authorisation was Successful.","transactionId":"87BE5864-E70C-8BA8-BAD7-C71E2BB83F62","transactionType":"Payment","retrievalReference":9285285,"bankResponseCode":"00","bankAuthorisationCode":"999777","paymentMethod":{"card":{"cardType":"Visa","lastFourDigits":"0014","expiryDate":"0421","cardIdentifier":"F50FD7FE-7E42-444B-868B-730575CAED6C","reusable":true}},"amount":{"totalAmount":1000,"saleAmount":1000,"surchargeAmount":0},"currency":"GBP","status":"Ok","avsCvcCheck":{"status":"NotChecked","address":"NotProvided","postalCode":"NotProvided","securityCode":"NotProvided"},"3DSecure":{"status":"IssuerNotEnrolled"}}'));
        });

        $response = $this->postJson('/api/payments/pay', $this->paymentByCardIdentifier);

        $response
            ->assertCreated()
            ->assertJson([
                'data' => [
                    'account_type_uuid' => null,
                ],
            ]);
    }

    public function test_should_be_able_to_make_secure_payment_with_3ds2_with_cardinfo(): void
    {
        $payload = $this->securePayload;
        Config::set('payment.3ds_version', '2');
        Config::set('payment.3ds_notification_url', 'http://v4checkout-local.dividebuy.co.uk/sagePayRedirect.php');

        // Mock call
        $this->mockGetSettings();
        $this->mock3dSecureV2PaymentIntiated();
        
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();
      
        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);

        $dvb_payment_response = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('status', $dvb_payment_response);
        $this->assertArrayHasKey('transaction_id', $dvb_payment_response);
        $this->assertArrayHasKey('status_details', $dvb_payment_response);
        $this->assertEquals('Please redirect your customer to the ACSURL to complete the 3DS Transaction', $dvb_payment_response['status_details']);
        $this->assertEquals('3DAuth', $dvb_payment_response['status']);
        $this->assertArrayHasKey('is_3ds_initiated', $dvb_payment_response);
        $this->assertArrayHasKey('3d_secure', $dvb_payment_response);
        $threeDS = $dvb_payment_response['3d_secure'];
        $this->assertArrayHasKey('creq', $threeDS);
        $this->assertArrayHasKey('threeDS_session_data', $threeDS);
        $this->assertArrayHasKey('acs_url', $threeDS);
        $this->assertArrayHasKey('version', $threeDS);
        $this->assertEquals('2', $threeDS['version']);
    }

    public function test_should_be_able_to_make_secure_payment_with_3ds2_without_cardinfo(): void
    {
        $payload = $this->paymentByCardIdentifier;
        $payload['apply_3d_secure'] = 'Force';
        
        Config::set('payment.3ds_version', '2');
        Config::set('payment.3ds_notification_url', 'http://v4checkout-local.dividebuy.co.uk/sagePayRedirect.php');

        // Mock call
        $this->mockGetSettings();
        $this->mock3dSecureV2PaymentIntiated();
        
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();
      
        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);

        $dvb_payment_response = $result['data']['transaction_response']['dvb_payment_response'];
        $this->assertArrayHasKey('status', $dvb_payment_response);
        $this->assertArrayHasKey('transaction_id', $dvb_payment_response);
        $this->assertArrayHasKey('status_details', $dvb_payment_response);
        $this->assertEquals('Please redirect your customer to the ACSURL to complete the 3DS Transaction', $dvb_payment_response['status_details']);
        $this->assertEquals('3DAuth', $dvb_payment_response['status']);
        $this->assertArrayHasKey('is_3ds_initiated', $dvb_payment_response);
        $this->assertArrayHasKey('3d_secure', $dvb_payment_response);
        $threeDS = $dvb_payment_response['3d_secure'];
        $this->assertArrayHasKey('creq', $threeDS);
        $this->assertArrayHasKey('threeDS_session_data', $threeDS);
        $this->assertArrayHasKey('acs_url', $threeDS);
        $this->assertArrayHasKey('version', $threeDS);
        $this->assertEquals('2', $threeDS['version']);
    }

    public function test_should_be_able_to_fail_avs_payment(): void
    {
        $this->mockGetSettings();
        $this->mockFailAvs();
        $payload = array_replace_recursive(
            $this->payload,
            [
                'apply_avs_cvc_check' => 'Force',
            ]
        );
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();
        
        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('avs_cvc_error', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertTrue($result['data']['transaction_response']['dvb_payment_response']['avs_cvc_error']);
        $this->assertEquals($result['data']['is_successful'], false);
        $this->assertArrayHasKey('payment_information_uuid', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('customer_uuid', $result['data']['transaction_response']['dvb_payment_response']);
    }

    public function test_should_be_able_to_fail_avs_payment_with_link_card(): void
    {
        $this->mockGetSettings();
        $this->mockFailAvs();
        $payload = array_replace_recursive(
            $this->payload,
            [
                'apply_avs_cvc_check' => 'Force',
                'card_details' => [
                    'card_identifier' => '249E48C0-9DDF-47D3-9BF9-471A6642B970',
                    'security_code' => '123',
                ],
            ]
        );

        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();
        
        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('avs_cvc_error', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertTrue($result['data']['transaction_response']['dvb_payment_response']['avs_cvc_error']);
        $this->assertArrayHasKey('payment_information_uuid', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('customer_uuid', $result['data']['transaction_response']['dvb_payment_response']);
    }

    /**
     * Test Payment with AVS/CSC DB Override values
     *
     * @dataProvider avsCscOverrideValues
     * @return  void
     */
    public function test_should_be_able_to_success_avs_payment($postCode, $houseNumber, $csc): void
    {
        factory(Settings::class)->create($postCode);
        factory(Settings::class)->create($houseNumber);
        factory(Settings::class)->create($csc);

        $this->mockGetSettings();
        $this->mockSuccessAvs();
        $payload = array_replace_recursive(
            $this->payload,
            [
                'apply_avs_cvc_check' => 'Force',
            ]
        );
        
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('avs_cvc_error', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertFalse($result['data']['transaction_response']['dvb_payment_response']['avs_cvc_error']);
        $this->assertArrayHasKey('payment_information_uuid', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('customer_uuid', $result['data']['transaction_response']['dvb_payment_response']);
    }

    /**
     * @return  void
     */
    public function test_should_be_able_to_make_payment_with_disable_avs(): void
    {
        factory(Settings::class)->create([
            'key' => 'apply_avs_cvc_check',
            'value' => 'Disable',
            'active' => 1,
        ]);
        
        $this->mockGetSettings();
        
        $postData = $this->payload['apply_3d_secure'] == 'Disable' ? array_merge([   'account_type_uuid' => 'c427c6c3-82c5-4d31-8152-b36507db3352'], $this->payload) : $this->payload;
        $response = $this->postJson('/api/payments/pay', $postData);
        $result = $response->decodeResponseJson();
       
        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('avs_cvc_error', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertFalse($result['data']['transaction_response']['dvb_payment_response']['avs_cvc_error']);
        $this->assertArrayHasKey('payment_information_uuid', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('customer_uuid', $result['data']['transaction_response']['dvb_payment_response']);
    }

    /**
     * @dataProvider threeeDsOverrideValues
     * @return  void
     */
    public function test_should_be_able_oveeride_3ds_value_from_database($data): void
    {
        factory(Settings::class)->create($data);

        $this->mockGetSettings();
        
        $postData = $this->payload['apply_3d_secure'] == 'Disable' ? array_merge([   'account_type_uuid' => 'c427c6c3-82c5-4d31-8152-b36507db3352'], $this->payload) : $this->payload;
        
        $response = $this->postJson('/api/payments/pay', $postData);
        $result = $response->decodeResponseJson();

        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertDatabaseHas('settings', $data);
    }

    public function test_should_be_able_to_make_payment_with_account_type_repeat(): void
    {
        Config::set('payment.3ds_version', '2');
        Config::set('payment.3ds_notification_url', 'http://v4checkout-local.dividebuy.co.uk/sagePayRedirect.php');
            
        $this->mockGetSettings();
        $payPayload = array_merge($this->payloadDeferForTelePhoneOrder(), [
            'apply_avs_cvc_check' => 'Disable',
        ]);
           
        ;
        $paymentResponse = $this->postJson('/api/payments/pay', $payPayload);
        $paymentDecode = $paymentResponse->decodeResponseJson()['data'];
        $dvbResponse = $paymentDecode['transaction_response']['dvb_payment_response'];
 
        $payPayload['vendor_tx_code'] = 'SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999);
       
        $payPayload['card_details'] = [
            'card_identifier' => $dvbResponse ['card_identifier'],
            'security_code' => '123',
        ];
        $payPayload['account_type_uuid'] = AccountType::REPEAT;
        
        $response = $this->postJson('/api/payments/pay', $payPayload);
        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($payPayload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($payPayload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('account_type_uuid', $result['data']);
        $this->assertEquals($payPayload['account_type_uuid'], $result['data']['account_type_uuid']);
    }

    /**
     * @dataProvider getAccountTypeUuid
     * @return  void
     */
    public function test_should_be_able_to_make_payment_with_skip_defer($accountTypeUuid, $statusCode): void
    {
        factory(Settings::class)->create([
            'key' => 'skip_deferred',
            'value' => 'ENABLE',
            'active' => 1,
        ]);
        $this->mockGetSettings();

        $this->payload['apply_3d_secure'] = 'Force';
        $this->payload['account_type_uuid'] = $accountTypeUuid;
        $response = $this->postJson('/api/payments/pay', $this->payload);
        $result = $response->decodeResponseJson();

        $response->assertStatus($statusCode);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('skip_deferred', $result['data']['transaction_response']['dvb_payment_response']);
    }

    public function test_should_be_able_to_check_avs_rejected_status_code(): void
    {
        factory(Settings::class)->create([
            'key' => 'skip_deferred',
            'value' => 'ENABLE',
            'active' => 1,
        ]);

        $this->mockGetSettings();
        $payload = array_replace_recursive(
            $this->payload,
            [
                'apply_avs_cvc_check' => 'Force',
                'account_type_uuid' => AccountType::CCE,
            ]
        );
        
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();
       
        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertEquals($this->payload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($this->payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('dvb_payment_response', $result['data']['transaction_response']);
        $this->assertArrayHasKey('statusCode', $result['data']['transaction_response']);
        $this->assertEquals('2001', $result['data']['transaction_response']['statusCode']);
        $this->assertArrayHasKey('avs_cvc_error', $result['data']['transaction_response']['dvb_payment_response']);
        $this->assertTrue($result['data']['transaction_response']['dvb_payment_response']['avs_cvc_error']);
    }

    public function getAccountTypeUuid()
    {
        return [
            [
                'accountTypeUuid' => AccountType::ECOMMERCE,
                'statusCode' => 202,
            ],
            [
                'accountTypeUuid' => AccountType::CCE,
                'statusCode' => 201,
            ],
        ];
    }

    /**
     * @return array
     */
    public function payPaymentRequestProvider()
    {
        return [
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['card_details']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['vendor_tx_code']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['amount']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['currency']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['description']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['apply_3d_secure']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['apply_avs_cvc_check']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_first_name']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_last_name']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['billing_address']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['account_type_uuid'] = 'xxx';

                return $payload;
            }],
        ];
    }

    public function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }

    public function mock3dSecureV2PaymentIntiated()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);
            $this->mockCardIdentifierRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) {
                        return $argument['entryMethod'] === 'Ecommerce' && isset($argument['strongCustomerAuthentication']) && isset($argument['credentialType']);
                    })
                )
                ->andReturn(new Response(202, [], '{
                    "cReq": "ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICI0ODNhNzljNy04YjcyLTQwY2MtYWVhMy01NDAxOTY5ZWFhNzAiLAogICJhY3NUcmFuc0lEIiA6ICJjNjk2YTAzYy03NDUxLTQxY2YtYTQyNC1jMWY4N2I3YWJmNjEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwMiIKfQ",
                    "acsUrl": "https://test.sagepay.com/3ds-simulator/html_challenge",
                    "status": "3DAuth",
                    "response": {
                        "statusCode": 202
                    },
                    "dsTransId": "953fe05a-0564-4ecb-b4d2-c5a98cd87b9d",
                    "acsTransId": "c696a03c-7451-41cf-a424-c1f87b7abf61",
                    "statusCode": "2021",
                    "statusDetail": "Please redirect your customer to the ACSURL to complete the 3DS Transaction",
                    "transactionId": "099FFD93-F059-6DEE-FE5E-04ABCE95FEAF",
                    "dvb_payment_response": {
                        "status": "3DAuth",
                        "success": true,
                        "3d_secure": {
                            "creq": "ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICI0ODNhNzljNy04YjcyLTQwY2MtYWVhMy01NDAxOTY5ZWFhNzAiLAogICJhY3NUcmFuc0lEIiA6ICJjNjk2YTAzYy03NDUxLTQxY2YtYTQyNC1jMWY4N2I3YWJmNjEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwMiIKfQ",
                            "acs_url": "https://test.sagepay.com/3ds-simulator/html_challenge",
                            "version": "2",
                            "threeDS_session_data": "MDk5RkZEOTMtRjA1OS02REVFLUZFNUUtMDRBQkNFOTVGRUFG"
                        },
                        "card_type": null,
                        "avs_cvc_error": false,
                        "status_details": "Please redirect your customer to the ACSURL to complete the 3DS Transaction",
                        "transaction_id": "099FFD93-F059-6DEE-FE5E-04ABCE95FEAF",
                        "card_identifier": null,
                        "payment_channel": "sagepay",
                        "is_3ds_initiated": true,
                        "transaction_type": "Payment-3dSecure"
                    }
                }'));
        }));
    }

    public function mock3dSecureV1PaymentIntiated()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);
            $this->mockCardIdentifierRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) {
                        return $argument['entryMethod'] === 'Ecommerce' && ! isset($argument['strongCustomerAuthentication']) && ! isset($argument['credentialType']);
                    })
                )
                ->andReturn(new Response(202, [], '{"paReq": "eJxVUctuwjAQvPcronxA/AiPGC1GFCqBVCoePbRHy1mVtCSAk5SkX187JIX6NDNez3pnYVKlB+8bTZ4cs7HPAupP5AO87g3ifIe6NChhhXmuPtBL4rHPKRv0+ICHfTGMQhYyEfoS1tMtniW0PtLaBAxIR62B0XuVFRKUPj8uX2RPcEEpkJZCimY5lyHlUTig3QFylSFTKcotpqrQ+5nBOCmeixhII4M+lllhahnxAZCOQGkO8nK5BO7fJ1UH+hiUX0CcDOT2nXXpUG5tqiSW1Zt4ijbp+w/d1mG5j7lZDaPFJ9ebyxiIq4BYFSg55TYGJjxOR0yM+kMgjQ4qdf0lE4Lb2a4ETq7H9P7mXgEbscFMdwN0DLA6HTO0FfbBH4YYcy13bhlrVXur9dK2dhKQ2yizhctZFzY65iJukPNLbDK8R1lj6AgQV0va7ZF2zxb92/8v6uayrQ==", "acsUrl": "https://test.sagepay.com/mpitools/accesscontroler?action=pareq", "status": "3DAuth", "response": {"statusCode": 202}, "statusCode": "2007", "statusDetail": "Please redirect your customer to the ACSURL to complete the 3DS Transaction", "transactionId": "BC89AD91-EE89-CB97-A51F-152C3E903704", "dvb_payment_response": {"status": "3DAuth", "success": true, "card_type": null, "avs_cvc_error": false, "status_details": "Please redirect your customer to the ACSURL to complete the 3DS Transaction", "transaction_id": "BC89AD91-EE89-CB97-A51F-152C3E903704", "card_identifier": null, "payment_channel": "sagepay", "transaction_type": "Payment"}}'));
        }));
    }

    private function mockAuthRequest($mock)
    {
        $mock->shouldReceive('makeRequest')
            ->andReturn(new Response(200, [], '{"expiry":"2022-01-21T08:36:34.425Z","merchantSessionKey":"7C26D5E2-5B1E-43AE-AC5D-283357FE2CCB"}'))->byDefault();
    }

    private function mockCardIdentifierRequest($mock)
    {
        $mock->shouldReceive('processRequest')
            ->andReturn(new Response(200, [], '{"cardIdentifier":"1C387A00-B226-408B-825A-EBEC610CB022","expiry":"2022-01-21T08:45:30.197Z","cardType":"Visa"}'));
    }

    private function mockSuccessfulPayment()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) {
                        return $argument['entryMethod'] === 'Ecommerce';
                    })
                )
                ->andReturn(new Response(201, [], '{"statusCode":"0000","statusDetail":"The Authorisation was Successful.","transactionId":"87BE5864-E70C-8BA8-BAD7-C71E2BB83F62","transactionType":"Payment","retrievalReference":9285285,"bankResponseCode":"00","bankAuthorisationCode":"999777","paymentMethod":{"card":{"cardType":"Visa","lastFourDigits":"0014","expiryDate":"0421","cardIdentifier":"F50FD7FE-7E42-444B-868B-730575CAED6C","reusable":true}},"amount":{"totalAmount":1000,"saleAmount":1000,"surchargeAmount":0},"currency":"GBP","status":"Ok","avsCvcCheck":{"status":"NotChecked","address":"NotProvided","postalCode":"NotProvided","securityCode":"NotProvided"},"3DSecure":{"status":"IssuerNotEnrolled"}}'));
        }));
    }

    public function mockFailAvs()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);
            $this->mockCardIdentifierRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) {
                        return $argument['entryMethod'] === 'Ecommerce' && isset($argument['transactionType']);
                    })
                )
                ->andReturn(new Response(201, [], '{
                    "statusCode": "0000",
                    "statusDetail": "The Authorisation was Successful.",
                    "transactionId": "45FCA62F-63AF-E639-0D9C-EE16CE34B1EC",
                    "transactionType": "Payment",
                    "retrievalReference": 12782159,
                    "bankResponseCode": "00",
                    "bankAuthorisationCode": "999777",
                    "paymentMethod": {
                      "card": {
                        "cardType": "Visa",
                        "lastFourDigits": "0006",
                        "expiryDate": "1222",
                        "cardIdentifier": "4A4683C2-46F1-43E1-A79F-1F1F8B846A41",
                        "reusable": true
                      }
                    },
                    "amount": {
                      "totalAmount": 206306,
                      "saleAmount": 206306,
                      "surchargeAmount": 0
                    },
                    "currency": "GBP",
                    "status": "Ok",
                    "avsCvcCheck": {
                      "status": "SecurityCodeMatchOnly",
                      "address": "NotMatched",
                      "postalCode": "NotMatched",
                      "securityCode": "Matched",
                      "apply": "Force"
                    },
                    "3DSecure": {
                      "status": "NotChecked"
                    }
                  }'));
        }));
    }

    /**
     * Get AVS and CSC parameter with value
     *
     * @return  array
     */
    public function avsCscOverrideValues(): array
    {
        return [
            [
                [
                    'key' => 'sagepay_postcode_override',
                    'value' => '412',
                    'active' => 1,
                ],
                [
                    'key' => 'sagepay_house_number_override',
                    'value' => '88',
                    'active' => 1,
                ],
                [
                    'key' => 'sagepay_csc_override',
                    'value' => '123',
                    'active' => 1,
                ],
            ],
        ];
    }

    /**
     * @return  array
     */
    public function threeeDsOverrideValues(): array
    {
        return [
            [
                [
                    'key' => 'apply_3d_secure',
                    'value' => 'Disable',
                    'active' => 1,
                ],
            ],
            [
                [
                    'key' => 'apply_3d_secure',
                    'value' => 'Force',
                    'active' => 1,
                ],
            ],
        ];
    }

    public function mockSuccessAvs()
    {
        $this->instance(ClientRequestHandler::class, Mockery::mock(ClientRequestHandler::class, function ($mock) {
            $this->mockAuthRequest($mock);
            $this->mockCardIdentifierRequest($mock);

            $mock->makePartial()
                ->shouldReceive('makeRequest')
                ->once()
                ->with(
                    config('payment.base_url') . 'transactions',
                    'post',
                    \Mockery::on(function ($argument) {
                        return $argument['entryMethod'] === 'Ecommerce' && isset($argument['transactionType']);
                    })
                )
                ->andReturn(new Response(201, [], '{
                    "statusCode": "0000",
                    "statusDetail": "The Authorisation was Successful.",
                    "transactionId": "501A724F-E183-2C0C-B63C-70F0723366EB",
                    "transactionType": "Payment",
                    "retrievalReference": 12816125,
                    "bankResponseCode": "00",
                    "bankAuthorisationCode": "999777",
                    "paymentMethod": {
                      "card": {
                        "cardType": "Visa",
                        "lastFourDigits": "0006",
                        "expiryDate": "1222",
                        "cardIdentifier": "D86F54D0-0438-4E23-B904-049E8A7686E5",
                        "reusable": true
                      }
                    },
                    "amount": {
                      "totalAmount": 239109,
                      "saleAmount": 239109,
                      "surchargeAmount": 0
                    },
                    "currency": "GBP",
                    "status": "Ok",
                    "avsCvcCheck": {
                      "status": "AllMatched",
                      "address": "Matched",
                      "postalCode": "Matched",
                      "securityCode": "Matched",
                      "apply": "Forced"
                    },
                    "3DSecure": {
                      "status": "NotChecked"
                    }
                  }'));
        }));
    }
}
