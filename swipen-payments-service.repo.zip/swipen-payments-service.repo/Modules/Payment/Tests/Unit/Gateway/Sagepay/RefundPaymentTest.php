<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Str;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Tests\Unit\PaymentAssertConfig;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class RefundPaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, WithFaker, PaymentAssertConfig;

    protected function setUp(): void
    {
        parent::setUp();
        $this->mockGetSettings();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->paymentAssertConfig = $this->getPaymentChannelConfig($this->paymentChannel);
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function test_should_be_able_to_make_partial_refund_payment(): void
    {
        $payPayload = $this->payloadPaymentForTelePhoneOrder();
        $payPayload['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $payPayload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transactionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);
        $this->assertEquals('Payment', $result['data']['transaction_response']['transactionType']);

        $transactionId = $result['data']['uuid'];
        $amount = (int) (round($result['data']['transaction_response']['amount']['totalAmount'] / 2));

        $payload = $this->refundPayload($transactionId, $amount);
        $response = $this->postJson('/api/payments/refund', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('parent_uuid', $result['data']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertArrayHasKey('transactionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('is_successful', $result['data']);
        $this->assertArrayHasKey('amount', $result['data']['transaction_response']);
        $this->assertEquals($transactionId, $result['data']['parent_uuid']);
        $this->assertEquals('Refund', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals($amount, $result['data']['transaction_response']['amount']['totalAmount']);
        $this->assertEquals($payPayload['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
    }

    public function test_should_be_able_to_make_full_refund_payment(): void
    {
        $payload = $this->payloadPaymentForTelePhoneOrder();
        $payload['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transactionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);
        $this->assertEquals('Payment', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals('The Authorisation was Successful.', $result['data']['transaction_response']['statusDetail']);

        $transactionId = $result['data']['uuid'];
        $amount = (int) (round($result['data']['transaction_response']['amount']['totalAmount'] / 2));

        $response = $this->postJson('/api/payments/refund', $this->refundPayload($transactionId, $amount));

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('parent_uuid', $result['data']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('transactionType', $response['data']['transaction_response']);
        $this->assertArrayHasKey('amount', $response['data']['transaction_response']);
        $this->assertEquals($transactionId, $result['data']['parent_uuid']);
        $this->assertEquals('Refund', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals($amount, $result['data']['transaction_response']['amount']['totalAmount']);
    }

    public function test_sagepay_error_on_zero_amount_refund(): void
    {
        $payload = $this->payloadPaymentForTelePhoneOrder();
        $payload['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transactionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);
        $this->assertEquals('Payment', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals('The Authorisation was Successful.', $result['data']['transaction_response']['statusDetail']);

        $transactionId = $result['data']['uuid'];

        $response = $this->postJson('/api/payments/refund', $this->refundPayload($transactionId, 0));

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('amount', $result['errors']);
        $this->assertContains('The Amount including surcharge is outside the allowed range.', $result['errors']['amount']);
    }

    public function test_sagepay_error_on_double_amount_refund(): void
    {
        $payload = $this->payloadPaymentForTelePhoneOrder();
        $payload['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transactionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);
        $this->assertEquals('Payment', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals('The Authorisation was Successful.', $result['data']['transaction_response']['statusDetail']);

        $transactionId = $result['data']['uuid'];
        $amount = (int) (round($result['data']['transaction_response']['amount']['totalAmount']) * 2);

        $response = $this->postJson('/api/payments/refund', $this->refundPayload($transactionId, $amount));

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('amount', $result['errors']);
        $this->assertContains('This refund amount will exceed the amount of the original transaction', $result['errors']['amount']);

        $this->assertDatabaseHas('transaction_error_logs', [
            'error_description' => 'This refund amount will exceed the amount of the original transaction',
        ]);
    }

    public function test_should_404_on_invalid_transaction_id(): void
    {
        $transaction = factory(Transaction::class)->create();

        $payload = array_merge($this->getPayload(), [
            'reference_transaction_uuid' => $transaction->uuid,
        ]);

        $response = $this->postJson('/api/payments/refund', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(404);
        $this->assertArrayHasKey('message', $result);
        $this->assertEquals('Transaction not found', $result['message']);
    }

    /**
     * @dataProvider refundPaymentRequestProvider
     */
    public function test_should_return_validation_errors_on_invalid_data($exceptionMessage, $dataCallback): void
    {
        $transaction = factory(Transaction::class)->create();

        $payload = $dataCallback($this->getPayload());

        // An existing uuid is required so inject it if key present
        if (isset($payload['reference_transaction_uuid'])) {
            $payload = array_merge($payload, [
                'reference_transaction_uuid' => $transaction->uuid,
            ]);
        }

        $response = $this->postJson('/api/payments/refund', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals($exceptionMessage, $result['message']);
    }

    /**
     * @return array
     */
    public function refundPaymentRequestProvider()
    {
        return [
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['reference_transaction_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                return array_merge($payload, ['customer_uuid' => Str::random(255)]);
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['vendor_tx_code']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                return array_merge($payload, ['vendor_tx_code' => Str::random(255)]);
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['amount']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                return array_merge($payload, ['amount' => 'xxx']);
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['description']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                $payload['description'] = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.';

                return $payload;
            }],
        ];
    }

    /**
     * Get payload.
     *
     * @return array
     */
    private function getPayload()
    {
        return [
            'customer_uuid' => $this->faker->uuid,
            'reference_transaction_uuid' => $this->faker->uuid,
            'vendor_tx_code' => implode('-', $this->faker->words()),
            'amount' => $this->faker->numberBetween(50, 100),
            'description' => $this->faker->sentence,
        ];
    }

    private function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
