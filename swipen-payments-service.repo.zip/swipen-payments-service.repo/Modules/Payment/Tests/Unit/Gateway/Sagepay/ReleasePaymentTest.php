<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Str;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Tests\Unit\PaymentAssertConfig;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class ReleasePaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, WithFaker, PaymentAssertConfig;

    protected $payload;

    protected function setUp(): void
    {
        parent::setUp();

        $this->payload = $this->payloadDefer();
        $this->mockGetSettings();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->paymentAssertConfig = $this->getPaymentChannelConfig($this->paymentChannel);
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function test_release_transaction(): void
    {
        $this->payloadDeferForTelePhoneOrder['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/defer', $this->payloadDeferForTelePhoneOrder);

        $deferResult = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $deferResult);
        $this->assertArrayHasKey('links', $deferResult);
        $this->assertArrayHasKey('transaction_response', $deferResult['data']);
        $this->assertArrayHasKey('is_successful', $deferResult['data']);
        $this->assertArrayHasKey('transactionType', $deferResult['data']['transaction_response']);
        $this->assertArrayHasKey('statusDetail', $deferResult['data']['transaction_response']);
        $this->assertEquals('Deferred', $deferResult['data']['transaction_response']['transactionType']);
        $this->assertEquals('The Authorisation was Successful.', $deferResult['data']['transaction_response']['statusDetail']);

        // Use transaction id and amount from initial defer payment
        $payload = array_merge($this->payloadDeferForTelePhoneOrder, [
            'transaction_uuid' => $deferResult['data']['uuid'],
            'amount' => $deferResult['data']['transaction_response']['amount']['totalAmount'],
        ]);

        $response = $this->postJson('/api/payments/release', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('parent_uuid', $result['data']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('instructionType', $result['data']['transaction_response']);
        $this->assertEquals($deferResult['data']['uuid'], $result['data']['parent_uuid']);
        $this->assertEquals('release', $result['data']['transaction_response']['instructionType']);
        $this->assertEquals($this->payloadDeferForTelePhoneOrder['order_uuid'], $result['data']['order_uuid']);
    }

    public function test_release_with_zero_amount_transaction(): void
    {
        $this->payloadDeferForTelePhoneOrder['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/defer', $this->payloadDeferForTelePhoneOrder);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('transactionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);
        $this->assertEquals('Deferred', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals('The Authorisation was Successful.', $result['data']['transaction_response']['statusDetail']);

        $payload = array_merge($this->getPayload(), [
            'transaction_uuid' => $result['data']['uuid'],
            'amount' => 0,
        ]);

        $response = $this->postJson('/api/payments/release', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('amount', $result['errors']);
        $this->assertContains('Contains invalid value', $result['errors']['amount']);
    }

    public function test_should_404_on_invalid_transaction_id(): void
    {
        $transaction = factory(Transaction::class)->create();

        $payload = array_merge($this->getPayload(), [
            'transaction_uuid' => $transaction->uuid,
        ]);

        $response = $this->postJson('/api/payments/release', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(404);
        $this->assertArrayHasKey('message', $result);
        $this->assertEquals('Transaction not found', $result['message']);
    }

    /**
     * @dataProvider releasePaymentRequestProvider
     */
    public function test_should_return_validation_errors_on_invalid_data($exceptionMessage, $dataCallback): void
    {
        $payload = $dataCallback($this->getPayload());

        $response = $this->postJson('/api/payments/release', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals($exceptionMessage, $result['message']);
    }

    /**
     * @return array
     */
    public function releasePaymentRequestProvider()
    {
        return [
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['transaction_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                return array_merge($payload, ['customer_uuid' => Str::random(255)]);
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['amount']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                return array_merge($payload, ['amount' => 'xxx']);
            }],
        ];
    }

    /**
     * Get payload.
     *
     * @return array
     */
    private function getPayload()
    {
        return [
            'customer_uuid' => $this->faker->uuid,
            'transaction_uuid' => $this->faker->uuid,
            'amount' => $this->faker->numberBetween(50, 100),
        ];
    }

    private function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
