<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Str;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Entities\AccountType;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class RepeatPaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, WithFaker;

    protected $paymentPayload;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentPayload = $this->payloadPayment();
        $this->payloadPaymentForTelePhoneOrder = $this->payloadPaymentForTelePhoneOrder();
        $this->seed(AccountTypesTableSeeder::class);
        $this->mockGetSettings();
    }

    public function test_should_be_able_to_make_repeat_payment(): void
    {
        $this->payloadPaymentForTelePhoneOrder['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $this->payloadPaymentForTelePhoneOrder);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);

        $payload = array_merge($this->getPayload(), [
            'reference_transaction_uuid' => $result['data']['uuid'],
        ]);

        $response = $this->postJson('/api/payments/repeat', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('parent_uuid', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertArrayHasKey('account_type_uuid', $result['data']);
        $this->assertArrayHasKey('is_successful', $result['data']);
        $this->assertEquals($payload['reference_transaction_uuid'], $result['data']['parent_uuid']);
        $this->assertEquals('Repeat', $result['data']['transaction_type']);
        $this->assertEquals('Repeat', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals($this->payloadPaymentForTelePhoneOrder['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertEquals($payload['account_type_uuid'], $result['data']['account_type_uuid']);
    }

    public function test_should_error_when_making_repeat_with_zero_payment(): void
    {
        $this->payloadPaymentForTelePhoneOrder['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $this->payloadPaymentForTelePhoneOrder);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);

        $payload = array_merge($this->getPayload(), [
            'reference_transaction_uuid' => $result['data']['uuid'],
            'amount' => 0,
        ]);

        $response = $this->postJson('/api/payments/repeat', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('amount', $result['errors']);
        $this->assertContains('The Amount including surcharge is outside the allowed range.', $result['errors']['amount']);
        $this->assertDatabaseHas('transaction_error_logs', [
            'error_description' => 'The Amount including surcharge is outside the allowed range.',
        ]);
    }

    public function test_should_404_on_invalid_transaction_id(): void
    {
        $transaction = factory(Transaction::class)->create();

        $payload = array_merge($this->getPayload(), [
            'reference_transaction_uuid' => $transaction->uuid,
        ]);

        $response = $this->postJson('/api/payments/repeat', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(404);
        $this->assertArrayHasKey('message', $result);
        $this->assertEquals('Transaction not found', $result['message']);
    }

    /**
     * @dataProvider repeatPaymentRequestProvider
     */
    public function test_should_return_validation_errors_on_invalid_data($exceptionMessage, $dataCallback): void
    {
        $transaction = factory(Transaction::class)->create();

        $payload = $dataCallback($this->getPayload());

        // An existing uuid is required so inject it if key present
        if (isset($payload['reference_transaction_uuid'])) {
            $payload = array_merge($payload, [
                'reference_transaction_uuid' => $transaction->uuid,
            ]);
        }

        $response = $this->postJson('/api/payments/repeat', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals($exceptionMessage, $result['message']);
    }

    public function test_makes_repeat_payment_with_account_type_uuid()
    {
        $this->payloadPaymentForTelePhoneOrder['apply_avs_cvc_check'] = 'Disable';
        $acountType = AccountType::whereCode('M')->first();

        $response = $this->postJson('/api/payments/pay', $this->payloadPaymentForTelePhoneOrder);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);

        $payload = array_merge($this->getPayload(), [
            'reference_transaction_uuid' => $result['data']['uuid'],
            'account_type_uuid' => $acountType->uuid,
        ]);

        $response = $this->postJson('/api/payments/repeat', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('parent_uuid', $result['data']);
        $this->assertArrayHasKey('order_uuid', $result['data']);
        $this->assertArrayHasKey('vendor_tx_code', $result['data']);
        $this->assertArrayHasKey('account_type_uuid', $result['data']);
        $this->assertEquals($payload['reference_transaction_uuid'], $result['data']['parent_uuid']);
        $this->assertEquals('Repeat', $result['data']['transaction_type']);
        $this->assertEquals('Repeat', $result['data']['transaction_response']['transactionType']);
        $this->assertEquals($this->payloadPaymentForTelePhoneOrder['order_uuid'], $result['data']['order_uuid']);
        $this->assertEquals($payload['vendor_tx_code'], $result['data']['vendor_tx_code']);
        $this->assertEquals($payload['account_type_uuid'], $result['data']['account_type_uuid']);
    }

    /**
     * @return array
     */
    public function repeatPaymentRequestProvider()
    {
        return [
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['reference_transaction_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['vendor_tx_code']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['amount']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['currency']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['description']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['shipping_address']['recipient_first_name']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['shipping_address']['recipient_last_name']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['shipping_address']['address1']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['shipping_address']['city']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['shipping_address']['postal_code']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['shipping_address']['country']);

                return $payload;
            }],
        ];
    }

    /**
     * Get payload.
     *
     * @return array
     */
    private function getPayload()
    {
        return [
            'customer_uuid' => $this->faker->uuid,
            'reference_transaction_uuid' => $this->faker->uuid,
            'account_type_uuid' => AccountType::REPEAT,
            'vendor_tx_code' => Str::limit('REPEAT-' . time() . '-' . implode('-', $this->faker->words()), 40, ''),
            'amount' => $this->faker->numberBetween(50, 100),
            'currency' => $this->faker->randomElement(['GBP']),
            'description' => $this->faker->sentence,
            'shipping_address' => [
                'recipient_first_name' => $this->faker->firstName,
                'recipient_last_name' => $this->faker->lastName,
                'address1' => $this->faker->streetAddress,
                'city' => $this->faker->city,
                'postal_code' => $this->faker->postcode,
                'country' => 'GB',
            ],
        ];
    }

    private function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
