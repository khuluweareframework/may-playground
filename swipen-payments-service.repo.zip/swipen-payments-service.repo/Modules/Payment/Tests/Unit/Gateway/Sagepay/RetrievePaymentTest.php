<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Modules\Payment\Database\Seeders\AccountTypesTableSeeder;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Tests\Unit\PaymentAssertConfig;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class RetrievePaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase, PaymentAssertConfig;

    protected $payload;

    protected function setUp(): void
    {
        parent::setUp();

        $this->payload = $this->payloadPayment();
        Config::set('payment.payment_channel', 'sagepay');
        $this->paymentChannel = config('payment.payment_channel');
        $this->paymentAssertConfig = $this->getPaymentChannelConfig($this->paymentChannel);
        $this->seed(AccountTypesTableSeeder::class);
    }

    public function test_should_be_able_to_make_payment_and_retrieve_generated_transaction()
    {
        $this->mockGetSettings();
        $payload = $this->payloadPaymentForTelePhoneOrder();
        $payload['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $payload);
        $result = $response->decodeResponseJson();
        
        $response
            ->assertStatus(201)
            ->assertJsonStructure([
                'data' => [
                    'id',
                    'uuid',
                    'customer_uuid',
                    'order_uuid',
                    'transaction_id',
                    'transaction_type',
                    'transaction_amount',
                    'transaction_response' => [
                        'statusCode',
                    ],
                    'created_at',
                    'updated_at',
                ],
                'links' => [
                    'self',
                ],
            ]);

       
        $transactionId = $result['data']['uuid'];

        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('statusDetail', $result['data']['transaction_response']);
        $this->assertEquals('The Authorisation was Successful.', $result['data']['transaction_response']['statusDetail']);

        $response = $this->getJson('/api/transactions/' . $result['data']['uuid']);

        $result = $response->decodeResponseJson();

        $response->assertStatus(200);

        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('statusDetail', $result['data']['sagepay_transaction']);
        $this->assertEquals($transactionId, $result['data']['uuid']);

        $this->assertDatabaseHas('stored_events', [
            'event_class' => \Modules\Payment\Events\TransactionReadSingle::class,
        ]);
    }

    public function test_should_404_on_invalid_transaction_id()
    {
        $response = $this->getJson('/api/transactions/invalid-transaction-id');

        $result = $response->decodeResponseJson();

        $response->assertStatus(404);

        $this->assertArrayHasKey('message', $result);
    }

    public function test_should_404_on_invalid_sagepay_transaction_id()
    {
        $transaction = factory(Transaction::class)->create();

        $response = $this->getJson('/api/transactions/' . $transaction->uuid);

        $result = $response->decodeResponseJson();

        $response->assertStatus(404);

        $this->assertArrayHasKey('message', $result);
    }

    private function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }
}
