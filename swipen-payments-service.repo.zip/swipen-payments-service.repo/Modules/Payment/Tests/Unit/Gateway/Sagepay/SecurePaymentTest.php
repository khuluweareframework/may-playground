<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use DivideBuy\ServiceClient\Http\JsonResponse;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Config;
use Modules\Payment\Entities\Transaction;
use Modules\Payment\Tests\Unit\PaymentPayload;
use SettingServiceClient;
use Tests\TestCase;

class SecurePaymentTest extends TestCase
{
    use PaymentPayload, WithFaker, RefreshDatabase;

    protected $securePayload;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
        $this->securePayload = $this->securePayloadPayment();
        $this->mockGetSettings();
    }

    /**
     * Test to secure payment using 3dsv1
     */
    public function test_should_be_able_to_make_secure_payment_v1(): void
    {
        Config::set('payment.3ds_version', '1');
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/pay', $this->securePayload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('is_successful', $result['data']);
        $this->assertArrayHasKey('transactionId', $result['data']['transaction_response']);
        $this->assertArrayHasKey('status', $result['data']['transaction_response']);
        $this->assertArrayHasKey('acsUrl', $result['data']['transaction_response']);
        $this->assertArrayHasKey('paReq', $result['data']['transaction_response']);
        $this->assertEquals('Please redirect your customer to the ACSURL to complete the 3DS Transaction', $result['data']['transaction_response']['statusDetail']);
        $this->assertEquals('3DAuth', $result['data']['transaction_response']['status']);
        $this->assertDatabaseHas('stored_events', [
            'event_class' => \Modules\Payment\Events\PaymentTransactionCreated::class,
        ]);

        // Get a valid PaRes
        $paResInputValue = $this->getPaResFromAcsUrl($result);

        // Finalise payment using our api call
        $payload = array_merge($this->getPayload(), [
            'transaction_uuid' => $result['data']['uuid'],
            'pa_res' => $paResInputValue,
        ]);

        $response = $this->postJson('/api/payments/secure-payment', $payload);

        $securePaymentResult = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $securePaymentResult);
        $this->assertArrayHasKey('links', $securePaymentResult);
        $this->assertArrayHasKey('parent_uuid', $securePaymentResult['data']);
        $this->assertArrayHasKey('transaction_response', $securePaymentResult['data']);
        $this->assertArrayHasKey('status', $securePaymentResult['data']['transaction_response']);
        $this->assertArrayHasKey('order_uuid', $securePaymentResult['data']);
        $this->assertArrayHasKey('vendor_tx_code', $securePaymentResult['data']);
        $this->assertEquals('Authenticated', $securePaymentResult['data']['transaction_response']['status']);
        $this->assertEquals($payload['transaction_uuid'], $securePaymentResult['data']['parent_uuid']);
        $this->assertEquals($result['data']['transaction_id'], $securePaymentResult['data']['transaction_id']);
        $this->assertEquals($this->securePayload['order_uuid'], $securePaymentResult['data']['order_uuid']);
        $this->assertEquals($this->securePayload['vendor_tx_code'], $securePaymentResult['data']['vendor_tx_code']);
        $this->assertDatabaseHas('stored_events', [
            'event_class' => \Modules\Payment\Events\PaymentTransactionFinalised::class,
        ]);
        $this->assertArrayHasKey('is_3ds_completed', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('status', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('status_details', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertTrue($securePaymentResult['data']['transaction_response']['dvb_payment_response']['is_3ds_completed']);
        $this->assertArrayHasKey('card_identifier', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('card_type', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('transaction_type', $securePaymentResult['data']);
        $this->assertEquals('Payment-Complete', $securePaymentResult['data']['transaction_type']);
        $this->assertArrayHasKey('skip_deferred', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
    }

    public function test_should_be_able_to_void_a_secure_payment_v1()
    {
        Config::set('payment.3ds_version', '1');
        $this->mockGetSettings();
        $this->securePayload['apply_avs_cvc_check'] = 'Disable';
        $response = $this->postJson('/api/payments/pay', $this->securePayload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('transactionId', $result['data']['transaction_response']);
        $this->assertArrayHasKey('status', $result['data']['transaction_response']);
        $this->assertArrayHasKey('acsUrl', $result['data']['transaction_response']);
        $this->assertArrayHasKey('paReq', $result['data']['transaction_response']);
        $this->assertEquals('Please redirect your customer to the ACSURL to complete the 3DS Transaction', $result['data']['transaction_response']['statusDetail']);
        $this->assertEquals('3DAuth', $result['data']['transaction_response']['status']);
        $this->assertDatabaseHas('stored_events', [
            'event_class' => \Modules\Payment\Events\PaymentTransactionCreated::class,
        ]);

        // Get a valid PaRes
        $paResInputValue = $this->getPaResFromAcsUrl($result);

        // Finalise payment using our api call
        $payload = array_merge($this->getPayload(), [
            'transaction_uuid' => $result['data']['uuid'],
            'pa_res' => $paResInputValue,
        ]);

        $response = $this->postJson('/api/payments/secure-payment', $payload);

        $result = $response->decodeResponseJson();

        $transactionId = $result['data']['uuid'];

        $response = $this->postJson('/api/payments/void', [
            'customer_uuid' => $result['data']['customer_uuid'],
            'transaction_uuid' => $result['data']['uuid'],
        ]);

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('parent_uuid', $result['data']);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('instructionType', $result['data']['transaction_response']);
        $this->assertArrayHasKey('date', $result['data']['transaction_response']);
        $this->assertEquals('void', $result['data']['transaction_response']['instructionType']);
        $this->assertEquals($transactionId, $result['data']['parent_uuid']);
    }

    public function test_should_receive_sagepay_error_on_invalid_pa_res(): void
    {
        Config::set('payment.3ds_version', '1');
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/pay', $this->securePayload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(202);

        // Get a valid PaRes
        $paResInputValue = $this->getPaResFromAcsUrl($result);

        // Finalise payment using our api call
        $payload = array_merge($this->getPayload(), [
            'transaction_uuid' => $result['data']['uuid'],
            'pa_res' => $paResInputValue . 'x',
        ]);

        $response = $this->postJson('/api/payments/secure-payment', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertArrayHasKey('pa_res', $result['errors']);
        $this->assertContains('Contains invalid characters', $result['errors']['pa_res']);
        $this->assertDatabaseHas('transaction_error_logs', [
            'error_description' => 'Contains invalid characters',
        ]);
    }

    public function test_should_404_on_invalid_transaction_id(): void
    {
        $transaction = factory(Transaction::class)->create();

        $payload = array_merge($this->getPayload(), [
            'transaction_uuid' => $transaction->uuid,
        ]);

        $response = $this->postJson('/api/payments/secure-payment', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(404);
        $this->assertArrayHasKey('message', $result);
        $this->assertEquals('Transaction not found', $result['message']);
        $this->assertDatabaseHas('transaction_error_logs', [
            'error_description' =>  'Transaction not found',
        ]);
    }

    /**
     * @dataProvider securePaymentRequestProvider
     */
    public function test_should_return_validation_errors_on_invalid_data($exceptionMessage, $dataCallback): void
    {
        $payload = $dataCallback($this->getPayload());

        $response = $this->postJson('/api/payments/secure-payment', $payload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(422);
        $this->assertArrayHasKey('message', $result);
        $this->assertArrayHasKey('errors', $result);
        $this->assertEquals($exceptionMessage, $result['message']);
    }

    /**
     * @return array
     */
    public function securePaymentRequestProvider()
    {
        return [
            ['The given data was invalid.', function ($payload) {
                unset($payload['customer_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['transaction_uuid']);

                return $payload;
            }],
            ['The given data was invalid.', function ($payload) {
                unset($payload['pa_res']);

                return $payload;
            }],
        ];
    }

    /**
     * Post to Sagepay's acs url then to the 3-D secure auth url to get
     * a valid PaRes value which can be used to finalise the payment.
     *
     * @param array $securePayloadResult
     */
    private function getPaResFromAcsUrl($securePayloadResult): string
    {
        $client = new Client();

        $acsUrlResponse = $client->request('POST', $securePayloadResult['data']['transaction_response']['acsUrl'], [
            'form_params' => [
                'PaReq' => $securePayloadResult['data']['transaction_response']['paReq'],
                'TermUrl' => url('/'),
                'MD' => $securePayloadResult['data']['transaction_response']['transactionId'],
            ],
        ]);

        // Parse response HTML to get 3-D secure auth form action
        $doc = new \DOMDocument();
        $doc->loadHtml((string) $acsUrlResponse->getBody());

        $selector = new \DOMXpath($doc);
        $queryResult = $selector->query('//form');
        $form = $queryResult->item(0);
        $secureFormAction = $form->getAttribute('action');

        // Post to 3-D secure auth form
        $threeDSecureResponse = $client->request('POST', 'https://test.sagepay.com' . $secureFormAction, [
            'form_params' => [
                'password' => 'password',
            ],
        ]);

        // Parse response HTML to get PaRes
        $doc = new \DOMDocument();
        $doc->loadHtml((string) $threeDSecureResponse->getBody());

        $selector = new \DOMXpath($doc);
        $queryResult = $selector->query('//input[@name="PaRes"]');
        $input = $queryResult->item(0);

        return $input->getAttribute('value');
    }

    /**
     * Get payload.
     *
     * @return array
     */
    private function getPayload()
    {
        return [
            'customer_uuid' => $this->faker->uuid,
            'transaction_uuid' => $this->faker->uuid,
            'pa_res' => base64_encode(implode('-', $this->faker->words())),
        ];
    }

    private function mockGetSettings()
    {
        SettingServiceClient::shouldReceive('getSettings')
        ->andReturn(new JsonResponse(json_decode('{"message":"Settings transaction listing","data":[]}', true), new Response));
    }

    /**
     * Test to secure payment using 3dsv1
     */
    public function test_should_be_able_to_make_secure_payment_with_defer_request(): void
    {
        Config::set('payment.3ds_version', '1');
        $this->mockGetSettings();
        $response = $this->postJson('/api/payments/defer', $this->securePayload);

        $result = $response->decodeResponseJson();

        $response->assertStatus(202);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('links', $result);
        $this->assertArrayHasKey('transaction_response', $result['data']);
        $this->assertArrayHasKey('transactionId', $result['data']['transaction_response']);
        $this->assertArrayHasKey('status', $result['data']['transaction_response']);
        $this->assertArrayHasKey('acsUrl', $result['data']['transaction_response']);
        $this->assertArrayHasKey('paReq', $result['data']['transaction_response']);
        $this->assertEquals('Please redirect your customer to the ACSURL to complete the 3DS Transaction', $result['data']['transaction_response']['statusDetail']);
        $this->assertEquals('3DAuth', $result['data']['transaction_response']['status']);
        $this->assertDatabaseHas('stored_events', [
            'event_class' => \Modules\Payment\Events\DeferTransactionCreated::class,
        ]);

        // Get a valid PaRes
        $paResInputValue = $this->getPaResFromAcsUrl($result);

        // Finalise payment using our api call
        $payload = array_merge($this->getPayload(), [
            'transaction_uuid' => $result['data']['uuid'],
            'pa_res' => $paResInputValue,
        ]);

        $response = $this->postJson('/api/payments/secure-payment', $payload);

        $securePaymentResult = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $securePaymentResult);
        $this->assertArrayHasKey('links', $securePaymentResult);
        $this->assertArrayHasKey('parent_uuid', $securePaymentResult['data']);
        $this->assertArrayHasKey('transaction_response', $securePaymentResult['data']);
        $this->assertArrayHasKey('status', $securePaymentResult['data']['transaction_response']);
        $this->assertArrayHasKey('order_uuid', $securePaymentResult['data']);
        $this->assertArrayHasKey('vendor_tx_code', $securePaymentResult['data']);
        $this->assertEquals('Authenticated', $securePaymentResult['data']['transaction_response']['status']);
        $this->assertEquals($payload['transaction_uuid'], $securePaymentResult['data']['parent_uuid']);
        $this->assertEquals($result['data']['transaction_id'], $securePaymentResult['data']['transaction_id']);
        $this->assertEquals($this->securePayload['order_uuid'], $securePaymentResult['data']['order_uuid']);
        $this->assertEquals($this->securePayload['vendor_tx_code'], $securePaymentResult['data']['vendor_tx_code']);
        $this->assertDatabaseHas('stored_events', [
            'event_class' => \Modules\Payment\Events\PaymentTransactionFinalised::class,
        ]);
        $this->assertArrayHasKey('is_3ds_completed', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('status', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('status_details', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertTrue($securePaymentResult['data']['transaction_response']['dvb_payment_response']['is_3ds_completed']);
        $this->assertArrayHasKey('card_identifier', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('card_type', $securePaymentResult['data']['transaction_response']['dvb_payment_response']);
        $this->assertArrayHasKey('transaction_type', $securePaymentResult['data']);
        $this->assertEquals('Deferred-Complete', $securePaymentResult['data']['transaction_type']);
    }
}
