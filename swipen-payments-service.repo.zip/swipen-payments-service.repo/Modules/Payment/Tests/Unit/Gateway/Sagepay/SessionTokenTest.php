<?php

namespace Modules\Payment\Tests\Unit\Gateway\Sagepay;

use Illuminate\Support\Facades\Config;
use Modules\Payment\Tests\Unit\PaymentPayload;
use Tests\TestCase;

class SessionTokenTest extends TestCase
{
    use PaymentPayload;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.payment_channel', 'sagepay');
    }

    public function test_should_be_able_to_generate_session_token(): void
    {
        $response = $this->postJson('/api/payments/session-token');

        $result = $response->decodeResponseJson();

        $response->assertStatus(201);
        $this->assertArrayHasKey('data', $result);
        $this->assertArrayHasKey('response', $result['data']);
        $this->assertArrayHasKey('merchantSessionKey', $result['data']['response']);
        $this->assertIsString($result['data']['response']['merchantSessionKey']);
    }

    public function test_should_error_on_invalid_sagepay_vendor(): void
    {
        $this->app['config']->set('payment.vendor_name', 'xxx');

        $response = $this->postJson('/api/payments/session-token');

        $result = $response->decodeResponseJson();

        $response->assertStatus(401);
        $this->assertArrayHasKey('message', $result);
        $this->assertEquals('Authentication failed', $result['message']);
    }
}
