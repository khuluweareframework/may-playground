<?php

namespace Modules\Payment\Tests\Unit;

use Illuminate\Http\Response as HttpResponse;

trait PaymentAssertConfig
{
    protected function getPaymentChannelConfig($paymentChannel)
    {
        switch ($paymentChannel) {
            case 'sagepay':
                $this->payload = $this->payloadDefer();
                $this->payloadDeferForTelePhoneOrder = $this->payloadDeferForTelePhoneOrder();

                return $this->getSagepayAssertConfig();
                break;
            
            case 'dna':
                $this->payload = $this->payloadDeferDna();

                return $this->getDnaAssertConfig();
                break;
            
            default:
                break;
        }
    }

    protected function getSagepayAssertConfig()
    {
        return [
            'defer' => [
                'success_code' => HttpResponse::HTTP_CREATED,
                'success_description' => 'The Authorisation was Successful.',
                'transaction_type' => 'Deferred',
                'secure_success_code' => HttpResponse::HTTP_ACCEPTED,
                'secure_success_description' => 'Please redirect your customer to the ACSURL to complete the 3DS Transaction',
                'secure_status' => '3DAuth',
            ],
        ];
    }

    protected function getDnaAssertConfig()
    {
        return [
                'defer' => [
                    'success_code' => HttpResponse::HTTP_OK,
                    'success_description' => 'Frictionless Flow - Authorized',
                    'transaction_type' => 'VERIFICATION',
                    'secure_success_code' => HttpResponse::HTTP_OK,
                    'secure_success_description' => 'Frictionless Flow - Authorized',
                    'secure_status' => 'succeeded',
                ],
        ];
    }
}
