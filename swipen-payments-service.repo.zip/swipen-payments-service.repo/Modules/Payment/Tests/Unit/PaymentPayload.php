<?php

namespace Modules\Payment\Tests\Unit;

use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Str;
use Modules\Payment\Entities\AccountType;
use Ramsey\Uuid\Uuid;

trait PaymentPayload
{
    use WithFaker;

    public function uuid()
    {
        return (string) Uuid::uuid4()->toString();
    }

    public function payloadPayment()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{
                        "cardholder_name": "Bruce Grobbler",
                        "card_number": "4929000000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    },
                    "custom_user_settings": {
                        "browser_ip": "159.242.115.2",
                        "website": "https://accounts.dividebuyqa.co.uk"
                    }
                  }',
            true
        );
    }

    public function payloadPaymentForTelePhoneOrder()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "account_type_uuid": "c427c6c3-82c5-4d31-8152-b36507db3352",
                    "card_details":{
                        "cardholder_name": "Bruce Grobbler",
                        "card_number": "4929000000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    },
                    "custom_user_settings": {
                        "browser_ip": "159.242.115.2",
                        "website": "https://accounts.dividebuyqa.co.uk"
                    }
                  }',
            true
        );
    }

    public function duplicateTxCodePayload()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{
                        "cardholder_name": "Bruce Grobbler",
                        "card_number": "4929000000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "DUPLICATE-123-ORDER-CANDACE",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    },
                    "custom_user_settings": {
                        "browser_ip": "159.242.115.2",
                        "website": "https://accounts.dividebuyqa.co.uk"
                    }
                  }',
            true
        );
    }

    public function payloadPaymentInvalidPredefinedValues()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{
                        "cardholder_name": "Bruce Grobbler",
                        "card_number": "4929000000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "False",
                    "apply_avs_cvc_check": "Disable",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    }
                  }',
            true
        );
    }

    public function payloadPaymentBk()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "transaction_type": "Payment",
                    "transaction_id": "A66F7DC8-705F-0512-C149-62AB40304FD8",
                    "card_details":{
                        "cardholder_name": "Bruce Grobbler",
                        "card_number": "4929000000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply3DSecure": "UseMSPSetting",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_firstname": "Bruce",
                    "customer_lastname": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    }
                  }',
            true
        );
    }

    public function securePayloadPayment()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "transaction_type": "Payment",
                    "card_details":{
                        "cardholder_name": "Bruce Grobbler",
                        "card_number": "4929000000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Force",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    },
                    "custom_user_settings": {
                        "browser_ip":"10.0.0.1",
                        "website":"https://www.abczyx.com"
                    }
                    }',
            true
        );
    }

    public function payloadDefer()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{
                        "cardholder_name": "Fong Kong",
                        "card_number": "4929000000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    },
                    "custom_user_settings": {
                        "browser_ip": "159.242.115.2",
                        "website": "https://accounts.dividebuyqa.co.uk"
                    }
                  }',
            true
        );
    }

    public function payloadDeferForTelePhoneOrder()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "account_type_uuid": "' . AccountType::CCE . '",
                    "card_details":{
                        "cardholder_name": "Fong Kong",
                        "card_number": "4929000000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    },
                    "custom_user_settings": {
                        "browser_ip": "159.242.115.2",
                        "website": "https://accounts.dividebuyqa.co.uk"
                    }
                  }',
            true
        );
    }

    public function payloadDeferDna()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{
                        "cardholder_name": "John Doe",
                        "card_number": "5224999999999909",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "000"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": 0,
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "Disable",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "billing_address": {
                        "address1": "10 St. John Street",
                        "city": "London",
                        "postal_code": "TN27 8QJ",
                        "country": "GB"
                    }
                  }',
            true
        );
    }

    public function payloadDeferBlockCard()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "order_uuid": "' . Uuid::uuid4()->toString() . '",
                    "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{
                        "cardholder_name": "Fong Kong",
                        "card_number": "5558980000006",
                        "expiry_date": "12' . date('y') . '",
                        "security_code": "123"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    }
                  }',
            true
        );
    }

    public function refundPayload($transactionId, $amount)
    {
        return json_decode(
            '{
                        "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                        "order_uuid": "' . Uuid::uuid4()->toString() . '",
                        "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
                        "reference_transaction_uuid": "' . $transactionId . '",
                        "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                        "amount": ' . $amount . ',
                        "description": "Demo transaction"
                    }',
            true
        );
    }

    public function voidPayload(): void
    {
    }

    public function cardDetailsPayload()
    {
        return json_decode(
            '{
                    "card_details":{
                        "cardholder_name": "Bruce Grobbler",
                        "card_number": "4929000000006",
                        "expiry_date": "0722",
                        "security_code": "123"
                        }
                    }',
            true
        );
    }

    public function cardDetailsPayloadErr()
    {
        return json_decode(
            '{
                    "card_details":{
                        "cardholder_name": "Bruce Grobbler",
                        "card_number": "4929000000006",
                        "expiry_date": "0710",
                        "security_code": "123"
                        }
                    }',
            true
        );
    }

    /**
     * "key": "dzlSN2ZSOWYxenhnYXNTNWVjNDZia05vaTFsekFDNGlrV1pxa2gxZnFFa1Z6RkxsS0M6enVBRnVpckM1UEc0bEoyMlQzcmxCdDRXY1NmcTRpOWdyblJOcWpHWktYVGhDOFMwVmkwakt3V21tMHc2RGhZd2Q=",
     * "vendorName": "rematchtest",
     * "baseUrl": "https://pi-test.sagepay.com/api/v1/".
     */

    /**
     * @throws \Exception
     */
    public function mockCustomerApiRequestData()
    {
        $data = '
        {
            "customer_uuid": "' . Uuid::uuid4()->toString() . '",
            "order_uuid": "' . Uuid::uuid4()->toString() . '",
            "payment_information_uuid": "' . Uuid::uuid4()->toString() . '",
            "id": "5dfcc6dca56a7ae6eedece07",
            "uuid": "3d02087d-7280-404a-bac0-b4699503f8cf",
            "title": "Mrs",
            "first_name": "Ellis",
            "last_name": "Singleton",
            "email": "singletoncline@honotron.com",
            "phone": "+44 (947) 409-2017",
            "billing_address": {
              "uuid": "684b3a35-c0d6-4307-b7b2-792770b67a56",
              "house_name": "",
              "house_number": 465,
              "address_1": "Billings Place",
              "town": "Florence",
              "post_code": "FM2 8BI"
            },
            "order": {
              "id": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
              "amount": 363875,
              "description": "Fixed Term Product",
              "card_details": {
                "cardholder_name": "Ms Lora Washington",
                "card_number": 4929000000006,
                "expiry_date": 1223,
                "security_code": 400
              }
            }
        }';

        return json_decode($data);
    }

    public function payloadPaymentByCardIdentifier()
    {
        return json_decode(
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{
                        "card_identifier": "249E48C0-9DDF-47D3-9BF9-471A6642B970",
                        "payment_channel": "sagepay"
                    },
                    "vendor_tx_code": "SPRINGBEE-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '",
                    "amount": ' . mt_rand(50000, 500000) . ',
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    },
                    "custom_user_settings": {
                        "browser_ip": "159.242.115.2",
                        "website": "https://accounts.dividebuyqa.co.uk"
                    }
                  }',
            true
        );
    }

    public function payloadPaymentByCardIdentifierDna($invoiceId = null)
    {
        $vendorTxCode = $invoiceId ?? "DNA-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '";
        $data =
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{

                        "card_identifier": "71ab5d9a-a100-474e-bff5-56baa26eb2e4",
                        "security_code": "111",
                        "payment_channel": "dna"
                    },
                    "vendor_tx_code": "' . $vendorTxCode . '",
                    "amount": 1,
                    "currency": "GBP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "Bruce",
                    "customer_last_name": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    }
                  }';

        return json_decode($data, true);
    }

    public function invalidPayloadPaymentByCardIdentifierDna($invoiceId = null)
    {
        $vendorTxCode = $invoiceId ?? "DNA-' . time() . '-ORDER-CANDACE' . mt_rand(1000, 9999) . '";
        $data =
            '{
                    "customer_uuid": "' . Uuid::uuid4()->toString() . '",
                    "card_details":{

                        "card_identifier": "71ab5d9a-a100-474e-bff5-56baa26eb2e4",
                        "security_code": "111",
                        "payment_channel": "dna"
                    },
                    "vendor_tx_code": "' . $vendorTxCode . '",
                    "amount": 1,
                    "currency": "GdP",
                    "description": "Demo transaction",
                    "apply_3d_secure": "Disable",
                    "apply_avs_cvc_check": "UseMSPSetting",
                    "customer_first_name": "verylooooooooooooooooooooooooooooooooooooooooooooooongname",
                    "customer_last_name": "Lee",
                    "customer_email": "sam@johns.co.uk",
                    "billing_address": {
                        "address1": "407 St. John Street",
                        "city": "London",
                        "postal_code": "EC1V 4AB",
                        "country": "GB"
                    }
                  }';

        return json_decode($data, true);
    }

    /**
     * Get payload.
     *
     * @return array
     */
    private function getRepeatPayload()
    {
        return [
            'customer_uuid' => $this->faker->uuid,
            'order_uuid' => $this->faker->uuid,
            'reference_transaction_uuid' => $this->faker->uuid,
            'account_type_uuid' => AccountType::REPEAT,
            'vendor_tx_code' => 'REPEAT-' . time() . '-' . $this->faker->numberBetween(500, 70000),
            'amount' => $this->faker->numberBetween(50, 100),
            'currency' => $this->faker->randomElement(['GBP']),
            'description' => $this->faker->sentence,
            'shipping_address' => [
                'recipient_first_name' => $this->faker->firstName,
                'recipient_last_name' => $this->faker->lastName,
                'address1' => $this->faker->streetAddress,
                'city' => $this->faker->city,
                'postal_code' => $this->faker->postcode,
                'country' => 'GB',
            ],
        ];
    }
}
