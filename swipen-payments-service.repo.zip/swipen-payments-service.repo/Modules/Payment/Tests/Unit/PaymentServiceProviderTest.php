<?php

namespace Tests\CustomersService\Tests\Unit\Providers;

use Modules\Payment\Providers\PaymentServiceProvider;
use Tests\TestCase;

class PaymentServiceProviderTest extends TestCase
{
    public function test_register_translations(): void
    {
        $provider_array = app()->getProviders(PaymentServiceProvider::class);
        /** @var PaymentServiceProvider $provider */
        $provider = $provider_array[array_keys($provider_array)[0]];

        if (! is_dir(resource_path('lang/modules/payment'))) {
            // by default, our langpath does not exist,
            // so we should expect this to call the else clause of the if statement in registerTranslations
            $provider->registerTranslations();
            $this->assertTrue(true);
            // now we need to create the dir
            mkdir(resource_path('lang/modules/payment'), 0777, true);
            $provider->registerTranslations();
            // clean up by removing the dir
            rmdir(resource_path('lang/modules/payment'));
            $this->assertTrue(true);

            return;
        }
        // in the case where a resources/lang/modules/payment-sservice directory does exist, we need to run this test
        // by first asserting that we can load from it, then rename the directory, test without it, then rename it back
        $provider->registerTranslations();
        $this->assertTrue(true);
        rename(resource_path('lang/modules/payment'), resource_path('lang/modules/temp'));
        $provider->registerTranslations();
        $this->assertTrue(true);
        rename(resource_path('lang/modules/temp'), resource_path('lang/modules/payment'));
    }
}
