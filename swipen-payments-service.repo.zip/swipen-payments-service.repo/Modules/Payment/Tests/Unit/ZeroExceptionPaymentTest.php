<?php

namespace Modules\Payment\Tests\Unit;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ServerException;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Modules\Payment\Database\Seeders\PaymentDatabaseSeeder;
use Modules\Payment\Http\Requests\ClientRequestHandler;
use Tests\TestCase;

class ZeroExceptionPaymentTest extends TestCase
{
    use PaymentPayload, RefreshDatabase;

    protected $payload;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(PaymentDatabaseSeeder::class);

        $this->payload = $this->payloadPayment();
    }

    /*public function test_should_be_able_to_make_payment_and_retrieve_generated_transaction(): void
    {
        $response = $this->postJson('/api/payments/pay', $this->payload);

        $this->assertEquals('ErrorException', json_decode($response->content())->exception);
    }*/

    public function test_creates_server_error_response_exception(): void
    {
        $exception = RequestException::create(new Request('POST', '/api/payments/pay'), new Response(500));

        $this->assertStringContainsString('POST /', $exception->getMessage());
        $this->assertStringContainsString('500 Internal Server Error', $exception->getMessage());
        $this->assertInstanceOf(ServerException::class, $exception);
    }

    public function test_client_handler_value_refuses_bad_input(): void
    {
        $this->expectException(\Exception::class);

        $instance = new ClientRequestHandler();
        $client = new Client();
        $instance->processRequest('/', 'post', $client, []);
    }

    /*public function test_client_handler_get_token_mSK(): void
    {
        $headers = [
            'Authorization' => 'Basic '.config('payment.key'),
            'Content-Type' => 'application/json',
            'vendorName' => config('payment.vendor_name'),
        ];

        $request_object = $this->createRequest('post', null, '/api/payments/session-token', ['CONTENT_TYPE' => 'application/json'], $headers);
        $this->expectException(\InvalidArgumentException::class);
        $instance = new PaymentGateway($request_object);
        $instance->getToken();
    }*/

    /**
     * @param $method
     * @param $content
     * @param string $uri
     * @param array $server
     * @param array $parameters
     * @param array $cookies
     * @param array $files
     *
     * @return \Illuminate\Http\Request
     */
    protected function createRequest(
        $method,
        $content,
        $uri = '/test',
        $server = ['CONTENT_TYPE' => 'application/json'],
        $parameters = [],
        $cookies = [],
        $files = []
    ) {
        $request = new \Illuminate\Http\Request();

        return $request->createFromBase(
            \Symfony\Component\HttpFoundation\Request::create(
                $uri,
                $method,
                $parameters,
                $cookies,
                $files,
                $server,
                $content
            )
        );
    }
}
