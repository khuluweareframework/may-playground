# Payment Microservice
The DivideBuy Payment service provides a bridge between micro-services and Sage pay gateway. It functions to perform the following actions:

1. Create a merchantSessionKey, which expires after 400 seconds, that you can then use to authenticate your requests. 
2. Create cardIdentifier, which expires after 400 seconds, which will then be used in the 
3. Calculate the Score group for a user (Prime, Near-Prime, Sub-Prime etc)
4. Calculate Deposit and Instalment amounts based on groupings

This application has been built as a drop in contribution for the original DivideBuy backend service. 

## Contributing
**Ensure all code pushed into this repo is PSR-2 compliant.**

**Any changes that you make, ensure that you run PHPUnit before pushing.** Broken/Failing unit tests should not be merged into the master branches. Check your tests every time. Test Suites can be found in `~/tests`

**You'll also find a Postman JSON Collection that you can use to test routes directly.** Please modify it in postman to suite your route and naming conventions.

**Make sure that you check the config directory for values that already exist** and see where you can use them rather than create new values. Reduction of duplication is a key facet.

**Ensure that seeders are only run once.** This can be done by only seeding key information and by checking if it already exists in the database before reseeding. 

**Avoid "magic strings/numbers" where possible** for example:

```php
return $value == 8;
return $value == "some string";
```

These should be instead stored as config or constants in classes where appropriate.

**Prefer Assertion over Assumption.** E.g.

```php
//Don't do this
if($this->relationship != null) {}

//Do this instead
if($this->relationship instanceof SomeClass) {}
```

**Add any new configuration or env changes to this file.** By making sure the readme is kept up to date, everyone is aware of any new values that they may need to consider

**Update the Postman Collection when new routes or changes to route parameters are added.** This ensures that everyone has a Clear Descriptor of the Routes and an understanding of the params that should be passed. This will eventually be superceded by a RAML document.

## Setup
Clone the repository from the current pinned master version and that you have a database set up ready then run the following procedures.

1. Run `composer install` (add the `--no-dev` flag if you want to run it in production mode)
2. Set up your `.env` file with the correct configuration
3. Run `php artisan migrate` to create your database
4. Run `php artisan db:seed` to seed the options table

## Available Configuration
This section details all the needed configuration files that you can set. As long as you have a complete env file set up with a valid database connection the Appliction should work in staging or local mode with no problems.

### .env Configuration
There are only a handful of configuration items that need to be set in the env for this application to run. 

Any reference to `env()` in the appliction should specify a smart default value in the event that the env parameter is NOT set.

The table below covers the variables available and their content

### Important Note:
This application is designed around having the following environments:

- production =  The Live Version of the environment - Will make use of the Call Credit Live API
- staging = A fast random number version for the Sandbox, QA, UAT and Demo Environments
- local = the Local version of the application - Will make use of the Call Credit Test API

### .env Configuration Table

| env Var | usage | Required | Environments |
|---------|-------|----------|--------------|
| APP_NAME | The name of the application | yes | all |
| APP_ENV | The Environment to be running in | yes | all |
| APP_KEY | An application key to be used for encryption | yes | all |
| APP_DEBUG | Whether the application should be in debug mode or not | yes | all |
| APP_URL | The URL of the application used for Auto Link Generation | yes | all |
| APP_TIMEZONE | The Timezone the app should be running in | yes | all |
| LOG_CHANNEL | Where to pipe log files to | yes | all |
| DB_CONNECTION | What Database connection type to use | yes | all |
| DB_HOST | Location of the Database | yes | all |
| DB_PORT | Database Port | yes | all |
| DB_DATABASE | Name of the Database | yes | all |
| DB_USERNAME | Database Username | yes | all |
| DB_PASSWORD | Database Password | yes | all |
| CACHE_DRIVER | The cache driver to user | yes | all |
| QUEUE_CONNECTION | The Queue connector to use | yes | all |
| CALL_CREDIT_TEST | Whether to use the call credit test api | no | local |
| AFFORDABILITY_SEARCH_TEST | Whether to use the affordability test api | no | local |
| MAIL_DRIVER | The mail driver to use | yes | all |
| MAIL_HOST | The mail host to use | yes | all |
| MAIL_PORT | The mail port to use | yes | all |
| MAIL_USERNAME | The username for email account on host | yes | all |
| MAIL_PASSWORD | The password for email account on host | yes | all |
| SENDER_EMAIL | The password for email address to be shown as sender | yes | all |
| SENDER_NAME | The name to be shown as sender | yes | all |
| CORE_API | The URL for Core API | no | all |
| PORTAL_API | The URL for the Portal API | no | all |
| PORTAL | The URL for Portal Frontend | no | all |
| WEBSITE | The URL for the Main website | no | all |
| OI_SCORE | The default oi_score for affordabiltiy API | yes | all |
| CALL_VALIDATE_SEARCH_TEST | Whether to use the call validate(COSMOS) test api | no | local |
| SEND_ERROR_EMAIL | Send email if COSMOS API return any error | yes | all

### Database Configuration
The Application has an options table for values that shouldn't be coded into files. The below table has a current list of the available values and their usage. Please make sure that they are correctly set before using the application

| Option Name | Option Value |
|-------------|--------------|
| CallCreditApiCompany | The Company name configuration for CallCredit |
| CallCreditApiUsername | The Api Username for Call Credit |
| CallCreditApiPassword | The Call Credit API Password | 
| FaultNotificationEmails | Comma separated list of emails to send fault notification |
| AffordabilityApiCompany | The Company name configuration for Affordability(COSMOS) API |
| AffordabilityApiUsername | The Api Username for Affordability(COSMOS) API |
| AffordabilityApiPassword | The Affordability(COSMOS) API Password | 
| AffordabilitySearchExpiry | Call for new affordability search of the customer after these days | 
| PortalSystemUser | The Username/Email Required for the Portal API |
| PortalSystemPassword | The Password for the User for the Portal |
| PortalSystemPin | The Pin for the User for the Portal |
| DefaultOIScore | The default oi score which used in picklist scenario (0) |
| SUCCESS_MATCH_TYPE | Default success value for match_type (User will always get Normal flow) |
| FAILED_MATCH_TYPE | Default fail value for match_type (User will always get Refer flow) |
| INCOME_MAX | Default value for income max when it is not available in Cosmos API response |
| INCOME_CON | Default value for income confidence when it is not available in Cosmos API response |
| NUMALLLN | Default value for New loan accounts(In last 3 months) when it is not available in Cosmos API response |
| NUMNEW3ALL | Default value for New accounts opened when it is not available in Cosmos API response |
| AMTNEW3ALL | Default value for Balance increases(In last 3 months) when it is not available in Cosmos API response |
| NUMCSHADV3 | Default value for Cash advances (In last 3 months) when it is not available in Cosmos API response |
| CallValidateApiCompany | The Company name configuration for Affordability(COSMOS) API |
| CallValidateApiUsername | The Api Username for Call Validate(COSMOS) API |
| CallValidateApiPassword | The Call Validate(COSMOS) API Password | 
| CallValidateSearchExpiry | Call for new call validate search of the customer after these days | 

### Config file configuration
This section details all the currently available configuration params that can be set. Any reference to `config()` added to the appliction should specify a smart default value in the event that the config is NOT set. 

#### config/ipauth.php
Container for IP addresses related to auth access. Specify whitelist IP address to access the service

```php
return [
    'valid_ips' => [
        '127.0.0.1'
    ]
];
```

#### config/sandbox.php
Sandbox configuration for the staging environment. Contains the configuration on auto generated credit scores.

`credit_result` controls the automatically generated credit scores that are created.

```php
return [
    'credit_result' = [
        'credit_score' => 600,
        'age_flag' => 0
        'insolvency_type' => '', 
        'resident_match' => '3',
        'judgements' => null
    ]
];
```

#### config/mail.php
Configuration file for the mail setup.
```php
return [
    'driver' => env('MAIL_DRIVER', 'smtp'),
    'host' => env('MAIL_HOST', 'smtp.gmail.com'),
    'port' => env('MAIL_PORT', 587),
    'encryption' => env('MAIL_ENCRYPTION', 'tls'),
    'username' => env('MAIL_USERNAME'),
    'password' => env('MAIL_PASSWORD'),
    'sendmail' => '/usr/sbin/sendmail -bs',
    'pretend' => false,
];
```

#### config/sector.php
Contains the information on default sector assignments. 

```php
return [
    'default_id' => 1
];
```

#### config/searchconfig.php
Contains the information on search config 

```php
return [
    'maxsearches' => 3,
    'searchdays' => 90
];
```
