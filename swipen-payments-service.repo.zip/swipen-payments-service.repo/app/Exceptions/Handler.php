<?php

namespace App\Exceptions;

use DivideBuy\ServiceClient\Exceptions\RequestClientException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Support\Str;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Throwable  $exception
     * @return void
     *
     * @throws \Exception
     */
    public function report(Throwable $exception)
    {
        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Throwable  $exception
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @throws \Throwable
     */
    public function render($request, Throwable $exception)
    {
        return parent::render($request, $exception);
    }

    /**
     * Get the default exception context variables for logging.
     *
     * @param  \Throwable  $e
     * @return array
     */
    protected function exceptionContext(Throwable $e)
    {
        if ($e instanceof RequestClientException) {
            return $e->getResponseErrors();
        }

        return parent::exceptionContext($e);
    }

    /**
     * Get the default context variables for logging.
     *
     * @return array
     */
    protected function context()
    {
        $headers = $this->getDivideBuyRequestHeaders();

        try {
            $context = array_merge(parent::context(), [
                'request_fingerprint' => request()->fingerprint(),
            ], $headers);
        } catch (\RuntimeException $e) {
            $context = array_merge(parent::context(), $headers);
        }

        return $context;
    }

    public function getDivideBuyRequestHeaders(): array
    {
        return collect(request()->header())
            ->filter(function ($value, $key) {
                return stripos($key, 'dividebuy') === 0;
            })
            ->map(function ($item, $key) {
                return $item[0];
            })
            ->mapWithKeys(function ($value, $key) {
                return [Str::snake(Str::camel($key)) => $value];
            })
            ->all();
    }
}
