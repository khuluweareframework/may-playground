<?php

namespace App\Logging;

use Illuminate\Support\Str;

class DivideBuyFormatter
{
    /**
     * Customize the given logger instance.
     *
     * @param  \Illuminate\Log\Logger  $logger
     * @return void
     */
    public function __invoke($logger)
    {
        $headers = $this->getDivideBuyRequestHeaders();

        foreach ($logger->getHandlers() as $handler) {
            $handler->pushProcessor(function ($record) use ($headers) {
                foreach ($headers as $header => $value) {
                    $record['extra'][$header] = $value;
                }

                return $record;
            });
        }
    }

    public function getDivideBuyRequestHeaders(): array
    {
        return collect(request()->header())
            ->filter(function ($value, $key) {
                return stripos($key, 'dividebuy') === 0;
            })
            ->map(function ($item, $key) {
                return $item[0];
            })
            ->mapWithKeys(function ($value, $key) {
                return [Str::snake(Str::camel($key)) => $value];
            })
            ->all();
    }
}