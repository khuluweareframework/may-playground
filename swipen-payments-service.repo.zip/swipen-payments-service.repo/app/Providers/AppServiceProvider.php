<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Schema\Blueprint;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $this->setBlueprintMacro();
    }

    /**
     * Set Blueprint Macro
     *
     * @return void
     */
    private function setBlueprintMacro(): void
    {
        Blueprint::macro('timestampsWithAttributes', function () {
            $this->timestamp('created_at')
                ->default(\DB::raw('CURRENT_TIMESTAMP'));

            // Need to add condition as the ON UPDATE attribute is unique to MySQL
            if (config('database.default') == 'mysql') {
                $this->timestamp('updated_at')
                    ->default(\DB::raw('CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP'));
            } else {
                $this->timestamp('updated_at')->nullable();
            }
        });
    }
}
