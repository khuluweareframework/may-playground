<?php

namespace App\Providers;

use Illuminate\Foundation\Http\Events\RequestHandled;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Log;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        //
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        // Skip below logging for tests and console
        if ($this->app->runningUnitTests() || $this->app->runningInConsole()) {
            return;
        }

        DB::listen(function ($query) {
            Log::debug('[Query Time: ' . $query->time . '] '. $query->sql, array_filter([
                'bindings' => $query->bindings,
                'slow' => $query->time >= 0.9,
            ]));
        });

        // Taken from Telescope RequestWatcher
        Event::listen(RequestHandled::class, function ($event) {
            $startTime = defined('LARAVEL_START') ? LARAVEL_START : $event->request->server('REQUEST_TIME_FLOAT');

            $uri = str_replace($event->request->root(), '', $event->request->fullUrl()) ?: '/';
            $method = $event->request->method();
            $duration = $startTime ? floor((microtime(true) - $startTime) * 1000) : null;

            Log::debug('[Request Time: ' . $duration . '] '. $method . ' ' . $uri, array_filter([
                'response_status' => $event->response->getStatusCode(),
                'slow' => $duration >= 1000,
            ]));
        });
    }
}
