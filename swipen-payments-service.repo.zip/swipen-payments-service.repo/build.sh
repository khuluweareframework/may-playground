#!/bin/bash
APPLICATION_NAME=payments-service
BUILD_ENV=${1:-local}
BUILD_TARGET=${1:-local}
NEWRELIC_AGENT_VERSION=${2:-9.18.1.303}
NEWRELIC_LICENSE_KEY=sample-key

if [ "$BUILD_TARGET" == 'local' ]
then
    echo "BUILD TARGET: local"
else
    BUILD_TARGET="production"
    echo "BUILD_TARGET: $BUILD_TARGET"
fi
#
ssh-add ~/.ssh/id_rsa
echo "DOCKER_BUILDKIT=1 docker build -t $APPLICATION_NAME . --build-arg BUILD_ENV=$BUILD_ENV --build-arg NEWRELIC_AGENT_VERSION=$NEWRELIC_AGENT_VERSION --build-arg NEW_RELIC_APPNAME=$APPLICATION_NAME --target $BUILD_TARGET"
DOCKER_BUILDKIT=1 docker build --platform linux/x86_64 -t "$APPLICATION_NAME" . --build-arg BUILD_ENV="$BUILD_ENV" --build-arg NEWRELIC_AGENT_VERSION=$NEWRELIC_AGENT_VERSION --build-arg NEWRELIC_APPNAME=$APPLICATION_NAME --build-arg NEWRELIC_LICENSE_KEY=$NEWRELIC_LICENSE_KEY --target "$BUILD_TARGET" --ssh bitbucket=$SSH_AUTH_SOCK --progress=plain

if command -v microk8s.ctr >/dev/null; then
    docker save $APPLICATION_NAME > $APPLICATION_NAME.tar
    microk8s.ctr image import $APPLICATION_NAME.tar
fi
