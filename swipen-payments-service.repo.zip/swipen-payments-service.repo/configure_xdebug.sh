APPLICATION_NAME=payments-service

if command -v microk8s.config >/dev/null; then
    CLUSTER_IP=$(microk8s.config | grep server: | awk -F : '{print $3}' | tail -c +3)
    POD_NAME=$(microk8s.kubectl get pod | grep $APPLICATION_NAME | cut -d ' ' -f1 )

    sed -ie "s/host.docker.internal/$CLUSTER_IP/g" start.sh
    microk8s.kubectl delete pod $POD_NAME
fi
