#!/bin/bash
HELM=helm
KUBECTL=kubectl

HOSTS_FILE=/etc/hosts
IS_MICROSOFT=$(uname -a | grep -i "Microsoft" | wc -l)
PROJECT_PATH=$HOME

if [ $IS_MICROSOFT -gt 0 ]; then
    WINDOWS_USER=$(powershell.exe '$env:UserName' | sed -e 's/\r//g')
    PROJECT_PATH="/c/Users/$WINDOWS_USER"
    HOSTS_FILE="/c/Windows/System32/drivers/etc/hosts"
fi

if command -v microk8s.helm >/dev/null; then
    HELM=microk8s.helm
fi
if command -v microk8s.kubectl >/dev/null; then
    KUBECTL=microk8s.kubectl
fi
APPLICATION_NAME=payments-service
BUILD_ENV=${1:-local}
ARGS=("--install" $APPLICATION_NAME "--debug" "charts")

if [ "$BUILD_ENV" == "local" ]; then
    ARGS+=("--set projectPath=$PROJECT_PATH/projects")
fi

FILE=./charts/environments/values-$BUILD_ENV.yaml
if [ -f "$FILE" ]; then
    ARGS+=("--values $FILE")
else
    echo "Provided environment not recognised or not provided. Defaulting to local"
fi

echo "$HELM upgrade ${ARGS[@]}"
$HELM upgrade ${ARGS[@]}

if [ "$BUILD_ENV" == "local" ]; then
    DOCKER_CONTAINER="${APPLICATION_NAME}_local_mount"
    if [ $(docker ps | grep -c "${DOCKER_CONTAINER}") -lt 1 ]; then
        if [ $(docker ps --all | grep -c "${DOCKER_CONTAINER}") -ge 1 ]; then
            docker rm "${DOCKER_CONTAINER}"
        fi
        docker run -t -d --restart=always --name "${DOCKER_CONTAINER}" -v $(pwd):/project:delegated alpine sh
    fi

    ADDRESS=$($KUBECTL get ing -o custom-columns=NAME:.spec.rules..host | awk '/^'$APPLICATION_NAME'/ {print $1}')
    if [ $(grep -c "${ADDRESS}" $HOSTS_FILE) -lt 1 ]; then
        echo "127.0.0.1 ${ADDRESS}" | sudo tee -a  $HOSTS_FILE
    fi
fi
