APPLICATION_NAME=payments-service
COMMAND=${1}
KUBECTL=kubectl

if command -v microk8s.kubectl >/dev/null; then
    KUBECTL=microk8s.kubectl
fi
KUBE_POD_NAME=$($KUBECTL get po | grep $APPLICATION_NAME | cut -d' ' -f1)
$KUBECTL exec -it $KUBE_POD_NAME -c app -- $COMMAND
