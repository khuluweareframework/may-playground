{{-- Token not need so not using the Form::open option method --}}
<form id="pa-form" method="post" action="{{ $secureArray['acsUrl'] }}">
    <input type="text" name="PaReq" value="{{ $secureArray['paReq'] }}">
    <input type="text" name="TermUrl" value="{{ $secureArray['TermUrl'] }}">
    <input type="text" name="MD" value="{{ $secureArray['transactionId'] }}">
    <input type="text" name="transactionId" value="{{ $secureArray['transactionId'] }}">
    <input type="text" name="customerUuid" value="{{ \Ramsey\Uuid\Uuid::uuid4()->toString() }}">
</form>
<script>document.addEventListener("DOMContentLoaded",function(){var b=document.getElementById("pa-form");b&&b.submit()})</script>
