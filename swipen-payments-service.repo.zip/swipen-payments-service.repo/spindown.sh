#!/bin/bash 
HELM=helm 
 
if command -v microk8s.$HELM >/dev/null; then 
    HELM=microk8s.$HELM 
fi
APPLICATION_NAME=payments-service

echo "$HELM del $APPLICATION_NAME"

ADDRESS=$(kubectl get ing | awk '/^'$APPLICATION_NAME'/ {print $2}')
if [ $(grep -c "${ADDRESS}" /etc/hosts) -gt 0 ]; then
    sudo sed -ie "\|^127.0.0.1 $ADDRESS\$|d" /etc/hosts
fi

$HELM del $APPLICATION_NAME
docker rm -f  "${APPLICATION_NAME}_local_mount"
